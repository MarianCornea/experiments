# copilot-usage

See where a GitHub Copilot agent workflow spends its credits.

`copilot-usage` reads the session logs that VS Code Copilot Chat and the Copilot CLI already write on your
machine. It shows what each session cost, which agent, phase or model the credits went to, and why: fresh
input, cache reads, cache writes or output. It writes an HTML report per run and compares two runs.

It works offline, never changes Copilot's files, and never stores your prompts, files or tool output. Reports
hold numbers and names only (model, tool, agent, skill, session title, folder).

- [Install](#install)
- [Quick start](#quick-start)
- [Commands](#commands)
- [Track phases and budgets during a run](#track-phases-and-budgets-during-a-run)
- [Reading the report](#reading-the-report)
- [Comparing two runs](#comparing-two-runs)
- [Credits: billed and estimated](#credits-billed-and-estimated)
- [Checking against GitHub's bill](#checking-against-githubs-bill)
- [Where data lives](#where-data-lives)
- [Troubleshooting](#troubleshooting)

## Install

You need the [.NET 10 runtime](https://dotnet.microsoft.com/download) (the SDK to build from source).

```bash
dotnet publish src/CopilotUsage -c Release -r win-x64 --self-contained false -p:PublishSingleFile=true -o dist
```

This creates `dist\copilot-usage.exe` with `pricing.json` next to it. Put `dist` on your `PATH`, or call the
exe by its full path. The examples below write `copilot-usage` for short.

## Quick start

1. **Check that the tool finds your Copilot data.**

   ```bash
   copilot-usage doctor
   ```

   It lists both data sources (see [Sessions](#sessions)), how many sessions each has, and whether hooks are
   installed.

2. **List your sessions**, newest first:

   ```bash
   copilot-usage list
   ```

   ```
   #   Last activity     Started           Status  Harness  Calls   Credits  Folder                  Title
   1   2026-11-07 16:10  2026-11-07 16:07  idle    Copilot     10     1.08   …\experiments           call the agent as a subagent…
   2   2026-11-07 16:07  2026-11-07 15:43  idle    Copilot     25     4.65   …\experiments           Implement a review agent…
   ```

3. **Write a report** for one session and open it in your browser:

   ```bash
   copilot-usage report 1 --open
   ```

4. **Optional: install hooks** so sub-agent runs, phases and tool-result sizes are recorded while you work:

   ```bash
   copilot-usage hooks install --scope user --skill
   ```

   Reload the VS Code window (or start a new Copilot CLI session) afterwards so Copilot picks up the hooks.

### Sessions

Copilot keeps sessions in one of two places, called *harnesses* here:

| Harness | Where | When |
|---|---|---|
| **Copilot** | `~/.copilot/session-state/<id>/` | VS Code's agent host and the Copilot CLI. Always written. |
| **Local** | VS Code storage, `GitHub.copilot-chat/debug-logs/<id>/` | VS Code's built-in chat. Written only when the setting `github.copilot.chat.agentDebugLog.fileLogging.enabled` is on. |

For VS Code's built-in chat there is a fallback: the **chat transcript** VS Code keeps for every chat
(`chatSessions/<id>.jsonl`). It records Copilot's billed credits per request and per sub-agent run, but no
tokens per model call. The tool reads it when a chat's debug log is missing or has no model calls, so those
chats still get exact credit totals; `list` shows their calls as, say, `7+` (sub-agent calls are not
counted). Their reports leave out the context-per-call chart, context growth and the cost-by-cause split.
Chats saved in VS Code's older transcript format (`.json` files) have no usage data and cannot be analyzed.

The tool reads both. Wherever a command takes `<session>`, you can pass:

- a number from `list` (`1` = newest)
- `latest` (the default)
- the session ID or its first few characters (`5474`)
- a session folder, or a workspace folder (picks that folder's newest session)

`--root <vscode-user-dir>` or `--cli-root <copilot-home>` limits the search to one folder.

## Commands

Run `copilot-usage --help` for all commands, or `copilot-usage <command> --help` for one.

| Command | What it does |
|---|---|
| `doctor` | Where the tool looks, what it found, the debug-log setting, hook status. |
| `list` | Sessions with calls and credits. `--days <n>`, `--limit <n>`, `--folder <text>`, `--include-empty`. |
| `report [<session>]` | One HTML report for a session. `--out <file>`, `--open`, `--mcp-map <file>`. |
| `compare <A> <B>` | One HTML report explaining why B cost more or less than A. `--label-a`, `--label-b`, `--by agent\|phase\|skill\|model`, `--mcp-map <file>`. |
| `status` | Cost so far, for the agent to call during a run. `--budget <credits>`, `--json`. |
| `phase start\|end <name>` | Marks a phase boundary; `end` prints the phase's cost. |
| `hooks install\|remove` | Adds or removes the hook file. `--scope`, `--dir`, `--soft-budget`, `--hard-budget`, `--on-error`. |
| `probe [<session>]` | Checks a session's log format against what the tool expects. |
| `hook` | Called by Copilot through the hook file, not by people. |

Every report command accepts `--pricing <file>` to use a different price table.

## Track phases and budgets during a run

Without hooks, the tool still knows every model call, its agent and its cost. Hooks add what the logs alone
don't show: phase boundaries, precise sub-agent runs, tool-result sizes, and budget limits.

### Install hooks

```bash
copilot-usage hooks install --scope repo --skill
```

| Option | Effect |
|---|---|
| `--scope repo` (default) | Writes `.github/hooks/copilot-usage.json` in the repository. Commit it to share it. |
| `--scope user` | Writes `hooks/copilot-usage.json` in the Copilot home (`~/.copilot`), for every workspace. |
| `--dir <folder>` | Where to write: the repository (repo scope) or the Copilot home (user scope). Default: the git root of the current folder, or `~/.copilot`. |
| `--skill` | Also writes the `workflow-cost` skill, which teaches the agent when to call `phase` and `status`. |
| `--soft-budget <credits>` | Once the session total reaches it, blocks the next tool call once and tells the agent to wrap up. See [Budgets](#budgets). |
| `--hard-budget <credits>` | Once the session total reaches it, ends the session. |
| `--on-error open\|closed` | What a failed budget check does: `open` (default) lets the call through, `closed` stops the session. |
| `--tool-sizes` | Records the size of each tool result (never its content). |
| `--exe <path>` | The exe the hooks call; defaults to the one you run. |

For example, to install into another repository with both limits:

```bash
copilot-usage hooks install --dir C:\work\my-repo --soft-budget 20 --hard-budget 30 --skill
```

Remove them with `copilot-usage hooks remove --scope repo` (or `user`), with the same `--dir` if you used one.

### Phases

A phase is a named stretch of a workflow, like `requirements` or `implementation`. The agent marks it from its
terminal:

```bash
copilot-usage phase start requirements
copilot-usage phase end requirements
```

`phase end` prints what the phase cost: every call between start and end, across all agents. Use the same
phase names in every run so runs can be compared by phase. With `--skill` installed, the agent does this on
its own when your workflow lists phases.

### Status

```bash
copilot-usage status --budget 5
```

```
SESSION 5474bac9  1.08 credits (100% billed)  10 calls  2m 09s
context now 17K of 272K usable | peak 17K | long context: 0 | cached 79%
agent runs: general-purpose (16:08) 0.71 · main 0.37
cost by cause: output 39% · fresh input 25% · cache write 21% · cache read 15%
budget 5.00: 22% used
```

`status` and `phase end` print at most 12 lines, so they add little to the agent's context.

They find the current session on their own. If two sessions were active in the same folder at once, pass
`--session <id>`.

Exit codes for both: `0` ok, `2` budget exceeded, `3` session not identified, `4` no new log data yet.

### Budgets

The hooks check the session total before every tool call, against two optional limits:

- **Soft limit** (`--soft-budget`). The next tool call is blocked, once, with a message telling the agent to
  stop starting new work, summarize what is done and left, update its progress file, and ask you. Later tool
  calls are allowed, so it can save its progress. Raising the limit re-arms it.
- **Hard limit** (`--hard-budget`). The session is ended (`continue: false` with a stop reason) and every tool call
  is denied. It is the safety net for an agent that keeps working after the soft stop; it gives no wrap-up turn,
  so a progress file may stop mid-phase.
- **Error mode** (`--on-error open|closed`). If the budget check itself fails, `open` (the default) lets the call
  through, so a fault in the tool never stops your work; `closed` ends the session instead. Recording events
  always fails open.

The limits are stored as arguments on the hook command in the hook file, so they travel with the repository
and show up in code review. To continue after a stop, raise them with `hooks install` and resume.

Both limits overshoot slightly: the call in progress is already paid for, and the logs can lag a few seconds.

**How each harness reacts:** VS Code's built-in chat supports ending a session from a hook. The Copilot
runtime (agent host and Copilot CLI) has no such field in its hook protocol, so there the hard limit most
likely denies every tool call without ending the session. `copilot-usage probe` check P17 reads what really
happened after a stop in a session; test it once with tiny limits (`--soft-budget 0.01 --hard-budget 0.05`).
Every stop also appears as a finding in the session's report.

A third, softer check needs no hooks: `status --budget 10` and `phase end <name> --budget 10` warn and exit with
code 2 when the total reaches 10 credits; the agent decides what to do.

## Reading the report

`copilot-usage report` writes one HTML file. It needs no internet, works in light and dark mode, and is safe
to share: it has no prompt or file content. By default it goes to
`%LOCALAPPDATA%\copilot-usage\reports\`.

From top to bottom:

1. **Header**: session title, folder, harness, models, and the format check result.
2. **Headline**: total credits, calls, duration, peak context (and its share of the usable context), cached
   share, and how much is billed vs estimated.
3. **Findings**: the few sentences that matter most, ranked by credits at stake. For example: which agent or
   phase cost the most, the largest cost cause, which tool grew the context, and calls over the long-context
   threshold.
4. **Context per call**: one bar per model call, split into cache read, cache write and fresh input, with a
   strip showing which agent made it. A rising staircase means context is piling up.
5. **Cumulative credits**: spend over time; hover for any point.
6. **Breakdowns**: credits by agent run, agent, turn, skill, model, kind and cause.
7. **MCP servers**: each server's own cost account. See [MCP servers](#mcp-servers).
8. **Context growth by tool**: which tools added the most tokens to the context, and how many tokens their
   results were carried for in later calls.
9. **Detail**: the 20 most expensive calls, fixed overhead (system prompt and tool definitions), context
   headroom per agent run, cache expiries, and the full call log with every value behind the charts.

### Cost causes

Each call's credits are split into four causes:

| Cause | Meaning | If it's high |
|---|---|---|
| **Fresh input** | Input not served from the cache. | The start of the prompt changes between calls; keep instructions and file order stable. |
| **Cache read** | Input served from the cache, at a lower rate. | Normal for long sessions; it grows with context size. |
| **Cache write** | New context written to the cache. | A lot of new content entered the context, often large file reads. |
| **Output** | Tokens the model wrote. | Long answers, long reasoning, or large file edits. |

### Usable context

Copilot keeps room for the model's longest answer inside its context window: 128K tokens for most models. A
run can only fill the rest, for example 872K of GPT-6 Luna's 1M window, or 128K of MAI-Code-1.1-Flash's 256K.
The Copilot harness caps GPT models lower, at 272K, which is where their long-context price starts. Near that
limit Copilot compacts the conversation.

The reservation is not billed: only the output tokens a model actually writes are. The report shows each run's
peak against its usable context (the **Context headroom** table, and the peak tile), and a finding when a run
passes 80% of it. `status` shows it too.

### Cache lifetime

Copilot keeps a prompt cache for 30 minutes after the last call that used it, and every call restarts the 30
minutes, so an agent that keeps working keeps its cache. After a longer pause, for example while it waits for
you to approve a step, the next call sends its whole context again: a cache write (GPT-6 Luna: $0.125 per 1M
tokens) instead of a cache read ($0.01). The report flags such calls in a **Cache expiries** table and a finding
with the extra credits. It flags a pause only when the next call really read little from the cache.

Many models charge more once a call's context passes a threshold, 272K tokens for most of them (see
`pricing.json`). Such calls cost up to twice as much per token, and the report flags them as long-context
calls.

### MCP servers

An MCP server costs tokens in two ways: its tool definitions ride along in every call that loads it, and its
tool results stay in the context of every later call. For each server the report shows:

- tools used and loaded, with the unused ones listed by name
- the definitions' size per call, the tokens they added over the session, and what that cost: a range from
  all cached (low) to all fresh (high), plus a point estimate from each call's cached share
- calls, duration and failures per tool
- result tokens, and result tokens *carried*: each result's size times the later calls that still held it,
  up to the next drop in context (compaction)
- its share of all input tokens, and which agents load and call it

Findings point out servers whose tools are loaded but barely used, tools whose results are carried for a long
time, and servers loaded by every agent but called by one (restrict them with the custom agent's tools list).

Tools are matched to a server by name: `mcp_<server>_<tool>` (VS Code), `<server>-<tool>` (the Copilot runtime,
e.g. `github-mcp-server-get_issue`), or `mcp__<server>__<tool>`. When a server's tools have no prefix, or a
non-MCP tool looks like one, give a map:

```json
{ "search_code": "code-search", "jira_*": "jira", "github-pull-request_*": null }
```

```bash
copilot-usage report 1 --mcp-map mcp-map.json
```

`null` marks a tool as not MCP. The tool never reads your MCP configuration itself.

**What each source records:** VS Code's debug log lists every tool definition with its size and links each
call to the set it carried, so definition overhead is exact per server. The Copilot harness logs only the total
size of all tool definitions per call, so the report shows that total and cannot split it by server. Chat
transcripts record tool calls only.

## Comparing two runs

Run the same workflow twice, for example before and after changing an agent's instructions, then:

```bash
copilot-usage compare 3 1 --label-a "before" --label-b "after" --open
```

The numbers are positions from `list` (here #3 is the older run, #1 the newer); IDs work too. The output says
how much B saved or added and the largest reason:

```
Comparison: C:\Users\you\AppData\Local\copilot-usage\reports\compare-80fc1585-5474bac9-20261107-1630.html
  before 2.71 → after 1.08 credits (−1.62)
  after saved 1.62 (−60%). The largest step was sub-agent explore: 1.66 → 0, which ran only in before.
```

The comparison report has:

- **Credit bridges**: waterfalls from A's total to B's, one by agent (or `--by phase|skill|model`) and one by
  cause. The steps always add up exactly to the difference.
- **Context curves**: one small chart per agent, one line per run of that agent.
- **Headline changes, fixed overhead, tool usage, MCP servers** (tools used and loaded, definitions and results
  carried, per run), and every agent, phase, skill and model matched by name.
- **Warnings** when the runs aren't fully comparable: different models, Copilot versions or harnesses, agents
  that ran in only one of them, or a run still in progress.

Phases and skills are only comparable when both runs used the same names.

## Credits: billed and estimated

Every number in the tool is marked as **billed** or **estimated**.

- **Billed** credits come from Copilot itself: each model call's log entry carries what GitHub charged. One
  credit is one billion of Copilot's nano-AI-units, or $0.01. The Copilot harness logs this for every call.
- **Estimated** credits are computed from token counts and the prices in `pricing.json`. They are used only
  when a call has no billed amount. Reports mark them, and `list` adds `*` to such totals.

`pricing.json` sits next to the exe and holds every text model on GitHub's
[Models and pricing](https://docs.github.com/en/copilot/reference/copilot-billing/models-and-pricing) page,
with its normal and long-context tiers. Edit it when prices change; no rebuild is needed. Edit the copy next to
the exe, since that is the one the tool reads.

- Each model has `input`, `cached`, `output` and optionally `cacheWrite` prices in USD per 1M tokens. Without
  `cacheWrite`, a cache write costs 1.25 × input, which is what Copilot bills for every model that lists one.
- A model with two tiers has a long-context threshold; a model with one tier never counts as long context.
- For a model missing from the file, the tool uses the rates it sees in that session's own billing data.

## Checking against GitHub's bill

GitHub shows your credit use at **https://github.com/settings/billing** → **AI usage**, per model and per
billing cycle. You can also download a usage report from the billing settings.

To check the tool's numbers, add up the billed credits from `copilot-usage list --days <n>` for the same
period and models. Expect GitHub's total to be higher if you also used Copilot elsewhere: on github.com, on
another machine, through the coding agent, or in sessions whose logs are gone.

## Where data lives

The tool only **reads** Copilot's files. It never writes, moves or locks them.

It writes only to `%LOCALAPPDATA%\copilot-usage\` (override with the `COPILOT_USAGE_HOME` environment
variable):

| Folder | Contents |
|---|---|
| `reports\` | HTML reports. |
| `events\` | Hook events per session: event names, times, sizes. No content. |
| `checkpoints\` | Phase start and end marks. |
| `cache\` | Running totals that keep `status` and the budget check fast. |
| `hook-errors.log`, `in-session.log` | Diagnostics. |

Deleting the folder resets everything except Copilot's own logs.

## Troubleshooting

**`doctor` finds no sessions.** For the Local harness, turn on the setting
`github.copilot.chat.agentDebugLog.fileLogging.enabled` in VS Code; older chats have no logs. For the Copilot
harness, check that `~/.copilot/session-state` exists.

**A new Copilot version changed something.** Run `copilot-usage probe latest`. It checks the newest session
against the format the tool expects and lists what passes, warns or fails. It also writes a fingerprint file:
the log's structure with no content, safe to attach to a bug report.

**`status` says "session not identified" (exit 3).** More than one session was active in that folder. Pass
`--session <id>` with an ID from `list`.

**`status` says "no new log data yet" (exit 4).** Copilot hasn't written the latest calls yet. Try again in a
few seconds.

**A budget limit didn't stop the agent.** Run `copilot-usage probe <session>` and read check P17: it shows
whether a stop was given and what the session did afterwards. On the Copilot harness the hard limit denies tool
calls but may not end the session.

**Hooks don't seem to fire.** Run `copilot-usage doctor`: the Hooks section shows whether the hook file is
installed and whether any events were recorded. Reload the VS Code window after installing. Errors go to
`%LOCALAPPDATA%\copilot-usage\hook-errors.log`; the hook never interrupts the agent because of its own errors.

**A model shows as unpriced.** It isn't in `pricing.json` and the session had no billed calls for it to learn
from. Add its prices to `pricing.json`.
