// Regenerates the SQLite fixtures used by SqliteTests (needs Node 22.13+ for node:sqlite).
//   node tests/fixtures/make-sqlite-fixtures.mjs
// The test project reads the committed files; this script is only for regeneration.
import { DatabaseSync } from 'node:sqlite';
import { copyFileSync, rmSync, existsSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const schema = 'CREATE TABLE ItemTable (key TEXT UNIQUE ON CONFLICT REPLACE, value BLOB)';

function fresh(path) {
  for (const p of [path, path + '-wal', path + '-shm']) if (existsSync(p)) rmSync(p);
  mkdirSync(dirname(path), { recursive: true });
  const db = new DatabaseSync(path);
  db.exec('PRAGMA page_size = 4096');
  db.exec(schema);
  return db;
}

// 1. The workspace state.vscdb for the fixture session: 300 rows (interior pages),
//    one 20,000-char value (overflow pages) and the chat session index.
{
  const path = join(here, 'User/workspaceStorage/a1b2c3d4e5f60718293a4b5c6d7e8f90/state.vscdb');
  const db = fresh(path);
  const put = db.prepare('INSERT INTO ItemTable (key, value) VALUES (?, ?)');
  for (let i = 0; i < 300; i++) put.run(`fixture.key.${String(i).padStart(3, '0')}`, `value-${i}`);
  put.run('fixture.big', 'abcdefghij'.repeat(2000));
  put.run('chat.ChatSessionStore.index', JSON.stringify({
    version: 1,
    entries: {
      '11111111-1111-4111-8111-111111111111': {
        sessionId: '11111111-1111-4111-8111-111111111111', title: 'Generate PIL harness', lastMessageDate: 1794040045100,
      },
    },
  }));
  db.close();
}

// 2. A database whose newest values exist only in its -wal file.
{
  const path = join(here, 'sqlite/live.db');
  const tmp = join(here, 'sqlite/tmp-live.db');
  const db = fresh(tmp);
  db.exec('PRAGMA journal_mode = WAL');
  db.exec('PRAGMA wal_autocheckpoint = 0');
  const put = db.prepare('INSERT INTO ItemTable (key, value) VALUES (?, ?)');
  put.run('state', 'old');
  db.exec('PRAGMA wal_checkpoint(TRUNCATE)');
  put.run('state', 'new');
  put.run('only-in-wal', 'yes');
  // Copy while the connection is open, so the WAL is not checkpointed away.
  copyFileSync(tmp, path);
  copyFileSync(tmp + '-wal', path + '-wal');
  db.close();
  for (const p of [tmp, tmp + '-wal', tmp + '-shm']) if (existsSync(p)) rmSync(p);
}
console.log('SQLite fixtures written');
