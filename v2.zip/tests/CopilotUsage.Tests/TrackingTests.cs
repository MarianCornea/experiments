using System.Text.Json;
using System.Text.Json.Nodes;
using CopilotUsage.Analysis;
using CopilotUsage.Pricing;
using CopilotUsage.Storage;
using CopilotUsage.Tracking;

namespace CopilotUsage.Tests;

/// <summary>M2: hook recording, hooks install, spend cache, session identification, phases, status and phase commands.</summary>
public static class TrackingTests
{
    const string CliSessionId = "44444444-4444-4444-8444-444444444444";
    static string CliHome => Path.Combine(Fixtures.Root, "copilot");

    static (int Exit, string Out, string Err) Hook(string input, params string[] args)
    {
        var stdout = new StringWriter();
        var stderr = new StringWriter();
        int exit = Program.Run(["hook", .. args], stdout, stderr, new StringReader(input));
        return (exit, stdout.ToString(), stderr.ToString());
    }

    static (int Exit, string Out, string Err) Run(params string[] args)
    {
        var stdout = new StringWriter();
        var stderr = new StringWriter();
        return (Program.Run(args, stdout, stderr), stdout.ToString(), stderr.ToString());
    }

    static long NowMs => DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

    // ---------- hook ----------

    public static void Hook_RecordsNamesAndLengthsOnly()
    {
        var dir = Fixtures.EmptyDir();
        var input = $$"""{"sessionId":"S1","timestamp":{{NowMs}},"cwd":"C:/work/SECRET-DIR","toolName":"powershell","toolArgs":{"command":"copilot-usage status SECRET-ARG"},"prompt":"SECRET"}""";
        var (exit, output, _) = Hook(input, "--event", "preToolUse", "--events-dir", dir);
        Assert.Equal(0, exit);
        Assert.Equal("", output, "no output without a budget");
        var line = File.ReadAllText(Path.Combine(dir, "S1.jsonl"));
        Assert.DoesNotContain("SECRET", line, "event line");
        var e = HookEvent.Parse(line.Trim())!;
        Assert.Equal("preToolUse", e.Event);
        Assert.Equal("powershell", e.Tool);
        Assert.Equal(true, e.UsageCommand, "copilot-usage command flagged");
        Assert.Equal(6, e.PromptLength, "prompt reduced to its length");
        Assert.True(e.Cwd is null, "cwd only kept for sessionStart");
    }

    public static void Hook_SubagentEventsGoToTheRootSession()
    {
        var dir = Fixtures.EmptyDir();
        Hook($$"""{"sessionId":"ROOT","timestamp":{{NowMs}},"agentId":"AGENT-1","agentName":"explore"}""", "--event", "subagentStart", "--events-dir", dir);
        Hook($$"""{"sessionId":"AGENT-1","timestamp":{{NowMs}},"toolName":"view","toolArgs":{ } }""", "--event", "preToolUse", "--events-dir", dir);
        Assert.True(!File.Exists(Path.Combine(dir, "AGENT-1.jsonl")), "no separate file for the sub-agent");
        var events = HookEvents.Load("ROOT", dir);
        Assert.Equal(2, events.Count, "both events in the root file");
        Assert.Equal("AGENT-1", events[1].AgentId, "sub-agent kept as agentId");
    }

    public static void Hook_ReadsVsCodeSnakeCaseInput()
    {
        var dir = Fixtures.EmptyDir();
        Hook("""{"session_id":"S2","hook_event_name":"PostToolUse","tool_name":"read_file","tool_response":"0123456789"}""", "--events-dir", dir);
        var e = HookEvents.Load("S2", dir).Single();
        Assert.Equal("PostToolUse", e.Event, "event name from the input");
        Assert.Equal(10, e.ResponseLength);
        Assert.Equal("vscode", e.Format);
    }

    public static void UsageCommands_MatchOnlyRealInvocations()
    {
        Assert.True(UsageCommands.IsInvocation("copilot-usage status --json"), "plain");
        Assert.True(UsageCommands.IsInvocation(@"& 'C:\dev\copilot-usage\dist\copilot-usage.exe' phase start reqs"), "quoted path");
        Assert.True(UsageCommands.IsInvocation("/c/tools/copilot-usage.exe status"), "bash path");
        Assert.True(!UsageCommands.IsInvocation(@"Get-Content -Path '.github\hooks\copilot-usage.json'"), "reading the hook file");
        Assert.True(!UsageCommands.IsInvocation("cd C:/dev/copilot-usage && dotnet build"), "the repo folder name");
        Assert.True(!UsageCommands.IsInvocation(null), "no command");
    }

    public static void SkillInvoked_SetsTheSkillOfLaterCalls()
    {
        var home = Fixtures.EmptyDir();
        var dir = Path.Combine(home, "session-state", CliSessionId);
        Directory.CreateDirectory(dir);
        var lines = File.ReadAllLines(Path.Combine(CliHome, "session-state", CliSessionId, "events.jsonl")).ToList();
        // Loaded after the first call ended (13:00:05) and before the sub-agent's call.
        lines.Insert(6, """{"type":"skill.invoked","data":{"name":"workflow-cost","source":"project"},"id":"s1","timestamp":"2026-11-07T13:00:06.000Z"}""");
        File.WriteAllLines(Path.Combine(dir, "events.jsonl"), lines);
        var data = SessionLoader.Load(CliSessionCatalog.FromDir(dir), PricingTable.Load());
        Assert.Equal("review-reqs", data.Calls[0].Skill, "slash command before the first call");
        Assert.Equal("workflow-cost", data.Calls[1].Skill, "skill.invoked before the second");
        Assert.True(!data.Diagnostics.UnknownEventTypes.Contains("skill.invoked"), "known event type");
    }

    public static void Hook_AcceptsAByteOrderMark()
    {
        var dir = Fixtures.EmptyDir();
        Hook("﻿" + """{"sessionId":"S3","toolName":"view"}""", "--event", "preToolUse", "--events-dir", dir);
        Assert.Equal(1, HookEvents.Load("S3", dir).Count, "recorded despite the BOM");
    }

    public static void Hook_NeverFailsOnBadInput()
    {
        var dir = Fixtures.EmptyDir();
        foreach (var input in new[] { "not json", "", "[1,2]", """{"no":"session"}""" })
        {
            var (exit, output, err) = Hook(input, "--event", "preToolUse", "--events-dir", dir, "--budget", "1");
            Assert.Equal(0, exit, "exit for: " + input);
            Assert.Equal("", output + err, "silent for: " + input);
        }
        Assert.Equal(0, Directory.GetFiles(dir, "*.jsonl").Length, "nothing recorded");
    }

    public static void Hook_SoftBudgetBlocksOneToolCallSoTheAgentWrapsUp()
    {
        var dir = Fixtures.EmptyDir();
        var cache = Path.Combine(dir, "spend.json");
        string input = $$"""{"sessionId":"{{CliSessionId}}","timestamp":{{NowMs}},"toolName":"view","toolArgs":{ } }""";
        string[] Args(string soft) => ["--event", "preToolUse", "--soft-budget", soft, "--events-dir", dir, "--cli-root", CliHome, "--spend-cache", cache];
        // The fixture session has billed 0.224 credits.
        Assert.Equal("", Hook(input, Args("1")).Out, "under the soft limit: no decision");
        var over = Hook(input, Args("0.2"));
        Assert.Equal(0, over.Exit, "Copilot harness: exit 0 with a JSON decision");
        var decision = JsonNode.Parse(over.Out)!;
        Assert.Equal("deny", (string)decision["permissionDecision"]!);
        Assert.Contains("0.22 used", (string)decision["permissionDecisionReason"]!);
        Assert.Contains("update the progress file", (string)decision["permissionDecisionReason"]!);
        Assert.True(decision["continue"] is null, "the soft limit does not end the session");
        Assert.Equal("", Hook(input, Args("0.2")).Out, "given once: the agent may use tools to save its progress");
        Assert.Contains("deny", Hook(input, Args("0.21")).Out, "a higher soft limit re-arms the stop");
        var stops = HookEvents.Load(CliSessionId, dir).Where(e => e.Event == "budgetStop").ToList();
        Assert.Equal(2, stops.Count, "each stop is recorded");
        Assert.Equal("soft", stops[0].Budget);
        Assert.Equal(0.2, stops[0].Limit);

        var vscode = Hook($$"""{"session_id":"{{CliSessionId}}","hook_event_name":"PreToolUse","tool_name":"view"}""",
            "--budget", "0.2", "--events-dir", dir, "--cli-root", CliHome, "--spend-cache", Path.Combine(dir, "spend2.json"));
        Assert.Equal(ExitCodes.BudgetExceeded, vscode.Exit, "VS Code style: exit 2; --budget is the old name of --soft-budget");
        Assert.Contains("soft budget", vscode.Err, "reason on stderr");
    }

    public static void Hook_HardBudgetEndsTheSession()
    {
        var dir = Fixtures.EmptyDir();
        string input = $$"""{"sessionId":"{{CliSessionId}}","timestamp":{{NowMs}},"toolName":"view"}""";
        string[] args = ["--event", "preToolUse", "--soft-budget", "0.1", "--hard-budget", "0.2", "--events-dir", dir, "--cli-root", CliHome, "--spend-cache", Path.Combine(dir, "s.json")];
        for (int i = 0; i < 2; i++)
        {
            var r = Hook(input, args);
            Assert.Equal(0, r.Exit, "exit 0 with a JSON decision");
            var d = JsonNode.Parse(r.Out)!;
            Assert.Equal(false, (bool)d["continue"]!, "continue: false ends the session (VS Code)");
            Assert.Contains("hard budget of 0.20", (string)d["stopReason"]!);
            Assert.Equal("deny", (string)d["hookSpecificOutput"]!["permissionDecision"]!, "and the call is denied (Copilot runtime)");
        }
        Assert.Equal("hard", HookEvents.Load(CliSessionId, dir).First(e => e.Event == "budgetStop").Budget, "the hard limit wins over the soft one");
    }

    public static void Hook_OnErrorDecidesWhatAFailedCheckDoes()
    {
        var dir = Fixtures.EmptyDir();
        var open = Hook("not json", "--event", "preToolUse", "--hard-budget", "5", "--events-dir", dir);
        Assert.Equal("", open.Out + open.Err, "open (default): the call goes through");
        var closed = Hook("not json", "--event", "preToolUse", "--hard-budget", "5", "--on-error", "closed", "--events-dir", dir);
        Assert.Equal(0, closed.Exit);
        var d = JsonNode.Parse(closed.Out)!;
        Assert.Equal(false, (bool)d["continue"]!, "closed: a failed check ends the session");
        Assert.Contains("fail closed", (string)d["stopReason"]!);
        var other = Hook("not json", "--event", "postToolUse", "--hard-budget", "5", "--on-error", "closed", "--events-dir", dir);
        Assert.Equal("", other.Out, "recording always fails open; only the preToolUse budget check is closed");
    }

    public static void SpendCache_ReadsOnlyNewLines()
    {
        var home = Fixtures.EmptyDir();
        var dir = Path.Combine(home, "session-state", "77777777-7777-4777-8777-777777777777");
        Directory.CreateDirectory(dir);
        var events = Path.Combine(dir, "events.jsonl");
        File.Copy(Path.Combine(CliHome, "session-state", CliSessionId, "events.jsonl"), events);
        var cache = Path.Combine(Fixtures.EmptyDir(), "spend.json");
        var first = SpendCache.Update("77777777-7777-4777-8777-777777777777", home, [], cache);
        Assert.Equal(224_000_000L, first.NanoAiu, "first read");
        File.AppendAllText(events, """{"type":"session.usage_record","data":{"usage":{"model":"x","copilotUsage":{"totalNanoAiu":1000}}},"id":"n","timestamp":"2026-11-07T13:01:00Z"}""" + "\n");
        var second = SpendCache.Update("77777777-7777-4777-8777-777777777777", home, [], cache);
        Assert.Equal(224_001_000L, second.NanoAiu, "only the new line was added");
        Assert.Equal(3, second.Calls, "calls");
    }

    // ---------- hooks install ----------

    public static void HooksInstall_WritesCopilotFormatAndSkill()
    {
        var repo = Fixtures.EmptyDir();
        var (exit, output, err) = Run("hooks", "install", "--scope", "repo", "--dir", repo, "--exe", @"C:\Tools\copilot-usage.exe", "--soft-budget", "5", "--hard-budget", "8", "--on-error", "closed", "--skill", "--tool-sizes");
        Assert.Equal(0, exit, "exit; stderr: " + err);
        var file = Path.Combine(repo, ".github", "hooks", "copilot-usage.json");
        var json = JsonNode.Parse(File.ReadAllText(file))!;
        Assert.Equal(1, (int)json["version"]!);
        var pre = json["hooks"]!["preToolUse"]![0]!;
        Assert.Equal("command", (string)pre["type"]!);
        Assert.Equal(@"& 'C:\Tools\copilot-usage.exe' hook --event preToolUse --soft-budget 5 --hard-budget 8 --on-error closed", (string)pre["powershell"]!);
        Assert.Equal("/c/Tools/copilot-usage.exe hook --event preToolUse --soft-budget 5 --hard-budget 8 --on-error closed", (string)pre["bash"]!);
        Assert.Equal("/c/Tools/copilot-usage.exe hook --event subagentStart", (string)json["hooks"]!["subagentStart"]![0]!["bash"]!, "budget only on preToolUse");
        Assert.True(json["hooks"]!["postToolUse"] is not null, "--tool-sizes adds postToolUse");
        var skill = File.ReadAllText(Path.Combine(repo, ".github", "skills", "workflow-cost", "SKILL.md"));
        Assert.Contains("name: workflow-cost", skill);
        Assert.Contains(@"C:\Tools\copilot-usage.exe phase start <phase-name>", skill);
        Assert.Contains("Skill written", output);

        Run("hooks", "remove", "--scope", "repo", "--dir", repo);
        Assert.True(!File.Exists(file), "hook file removed");
        Assert.True(!Directory.Exists(Path.Combine(repo, ".github", "skills", "workflow-cost")), "skill removed");
    }

    public static void HooksInstall_UserScopeAndNoPreTool()
    {
        var home = Fixtures.EmptyDir();
        Run("hooks", "install", "--scope", "user", "--dir", home, "--exe", "copilot-usage", "--no-pre-tool");
        var json = JsonNode.Parse(File.ReadAllText(Path.Combine(home, "hooks", "copilot-usage.json")))!;
        Assert.True(json["hooks"]!["preToolUse"] is null, "--no-pre-tool drops preToolUse");
        Assert.Equal("copilot-usage hook --event agentStop", (string)json["hooks"]!["agentStop"]![0]!["bash"]!, "plain name on PATH");
    }

    // ---------- session identification ----------

    static CliSession Fake(string id, string? folder, DateTime lastWrite, string? dir = null) =>
        new(id, dir ?? Path.Combine(Fixtures.EmptyDir(), id), folder, null, null, true, lastWrite);

    public static void Identify_PrefersTheEnvironmentSessionId()
    {
        var now = DateTimeOffset.UtcNow;
        var sessions = new List<ChatSession> { Fake("aaaa", "C:/w", now.UtcDateTime), Fake("bbbb", "C:/w", now.UtcDateTime) };
        var id = new CurrentSession { Sessions = sessions, EnvironmentSessionId = "bbbb", EventsDir = Fixtures.EmptyDir(), WorkingDirectory = "C:/w", Now = now }.Identify(null);
        Assert.Equal("bbbb", id.Session.Id);
        Assert.Equal("COPILOT_AGENT_SESSION_ID", id.Method);
    }

    public static void Identify_UsesTheHookEventOfThisCommand()
    {
        var now = DateTimeOffset.UtcNow;
        var events = Fixtures.EmptyDir();
        File.WriteAllText(Path.Combine(events, "bbbb.jsonl"), new HookEvent { Event = "preToolUse", Ts = now.ToUnixTimeMilliseconds() - 1000, SessionId = "bbbb", UsageCommand = true }.ToJsonLine() + "\n");
        var sessions = new List<ChatSession> { Fake("aaaa", "C:/w", now.UtcDateTime), Fake("bbbb", "C:/w", now.UtcDateTime) };
        var id = new CurrentSession { Sessions = sessions, EnvironmentSessionId = null, EventsDir = events, WorkingDirectory = "C:/w", Now = now }.Identify(null);
        Assert.Equal("bbbb", id.Session.Id);
        Assert.Equal("hook event", id.Method);

        File.WriteAllText(Path.Combine(events, "aaaa.jsonl"), new HookEvent { Event = "preToolUse", Ts = now.ToUnixTimeMilliseconds() - 500, SessionId = "aaaa", UsageCommand = true }.ToJsonLine() + "\n");
        var e = Assert.Throws<CliException>(() => new CurrentSession { Sessions = sessions, EnvironmentSessionId = null, EventsDir = events, WorkingDirectory = "C:/w", Now = now }.Identify(null));
        Assert.Equal(ExitCodes.SessionNotIdentified, e.ExitCode, "two sessions: refuse to guess");
        Assert.Contains("more than one session", e.Message);
    }

    public static void Identify_FindsTheSessionRunningTheCommand()
    {
        var now = DateTimeOffset.UtcNow;
        var dir = Path.Combine(Fixtures.EmptyDir(), "cccc");
        Directory.CreateDirectory(dir);
        var stamp = now.AddSeconds(-2).ToString("o");
        File.WriteAllText(Path.Combine(dir, "events.jsonl"),
            $$"""{"type":"tool.execution_start","data":{"toolCallId":"t1","toolName":"powershell","arguments":{"command":"copilot-usage status"} },"id":"1","timestamp":"{{stamp}}"}""" + "\n");
        var sessions = new List<ChatSession> { Fake("cccc", "C:/w", now.UtcDateTime, dir), Fake("dddd", "C:/w", now.UtcDateTime) };
        var finder = new CurrentSession { Sessions = sessions, EnvironmentSessionId = null, EventsDir = Fixtures.EmptyDir(), WorkingDirectory = "C:/w", Now = now };
        Assert.Equal("cccc", finder.Identify(null).Session.Id, "running copilot-usage command");

        File.AppendAllText(Path.Combine(dir, "events.jsonl"), $$"""{"type":"tool.execution_complete","data":{"toolCallId":"t1","success":true },"id":"2","timestamp":"{{stamp}}"}""" + "\n");
        Assert.Throws<CliException>(() => finder.Identify(null)); // finished: falls through to two active sessions in the folder
    }

    public static void Identify_FolderFallbackRefusesTwoActiveSessions()
    {
        var now = DateTimeOffset.UtcNow;
        var old = now.UtcDateTime.AddHours(-2);
        var finder = (List<ChatSession> s) => new CurrentSession { Sessions = s, EnvironmentSessionId = null, EventsDir = Fixtures.EmptyDir(), WorkingDirectory = @"C:\w\sub", Now = now };
        Assert.Equal("new", finder([Fake("new", @"C:\w", now.UtcDateTime), Fake("old", @"C:\w", old)]).Identify(null).Session.Id, "one active session in the folder");
        var e = Assert.Throws<CliException>(() => finder([Fake("a", @"C:\w", now.UtcDateTime), Fake("b", @"C:\w", now.UtcDateTime)]).Identify(null));
        Assert.Contains("active in the last 10 minutes", e.Message);
        Assert.Equal(ExitCodes.SessionNotIdentified, Assert.Throws<CliException>(() => finder([Fake("x", @"D:\other", now.UtcDateTime)]).Identify(null)).ExitCode, "nothing fits");
    }

    // ---------- phases, turns and tool sizes ----------

    public static void Checkpoints_PairStartsWithEnds()
    {
        var t = DateTimeOffset.Parse("2026-11-07T10:00:00Z").ToUnixTimeMilliseconds();
        var spans = Checkpoints.Spans([
            new Checkpoint("reqs", "start", t), new Checkpoint("reqs", "end", t + 1000),
            new Checkpoint("reqs", "start", t + 2000), new Checkpoint("design", "start", t + 3000),
            new Checkpoint("reqs", "end", t + 4000),
        ]);
        Assert.Equal("reqs|reqs|design", string.Join("|", spans.Select(s => s.Name)), "a repeated phase gives two spans");
        Assert.True(spans[2].End is null, "design is still open");
    }

    public static void Phases_AreAppliedToCallsByTime()
    {
        var data = SessionLoader.Load(CliSessionCatalog.FindAll(CliHome).Single(), PricingTable.Load());
        var t0 = DateTimeOffset.Parse("2026-11-07T13:00:00Z");
        SessionLoader.ApplyPhases(data, [new PhaseSpan("reqs", t0, t0.AddSeconds(6)), new PhaseSpan("review", t0.AddSeconds(6), null)]);
        Assert.Equal("reqs", data.Calls[0].Phase, "first call starts at 13:00:01");
        Assert.Equal("review", data.Calls[1].Phase, "sub-agent call starts after 13:00:06");
        Assert.Equal("reqs|review", string.Join("|", Breakdown.By(data, Dimension.Phase).Select(r => r.Key).Order()));
    }

    public static void Turns_FollowUserPrompts()
    {
        var data = SessionLoader.Load(CliSessionCatalog.FindAll(CliHome).Single(), PricingTable.Load());
        Assert.True(data.Calls.All(c => c.Turn == 1), "both calls follow the one prompt");
        Assert.Contains("turn 1 (", Breakdown.By(data, Dimension.Turn).Single().Key);
    }

    public static void ToolSizes_ComeFromPostToolUseForLocalSessions()
    {
        var events = Fixtures.EmptyDir();
        var checkpoints = Fixtures.EmptyDir();
        File.WriteAllText(Path.Combine(events, Fixtures.WorkspaceSession + ".jsonl"),
            new HookEvent { Event = "postToolUse", Ts = 1794040006300, SessionId = Fixtures.WorkspaceSession, Tool = "read_file", ResponseLength = 4000 }.ToJsonLine() + "\n");
        var session = SessionCatalog.FindAll(StorageRoots.Find(Fixtures.UserDir)).Single(s => s.Id == Fixtures.WorkspaceSession);
        var data = SessionLoader.Load(session, PricingTable.Load(), tool: new ToolData(checkpoints, events));
        Assert.Equal(1000L, data.Tools.First(t => t.Name == "read_file").ResultTokens, "4,000 chars ≈ 1,000 tokens");
        Assert.True(data.Tools.Last(t => t.Name == "read_file").ResultTokens is null, "only the matching call");
    }

    // ---------- status and phase commands ----------

    public static void Status_PrintsAShortSummary()
    {
        var (exit, output, err) = Run("status", "--session", CliSessionId, "--cli-root", CliHome);
        Assert.Equal(0, exit, "exit; stderr: " + err);
        var lines = output.Split('\n', StringSplitOptions.RemoveEmptyEntries);
        Assert.True(lines.Length <= 12, $"at most 12 lines, got {lines.Length}");
        Assert.Contains("SESSION 44444444  0.22 credits (100% billed)  2 calls", lines[0]);
        Assert.Contains("agent runs: explore", output, "most expensive run first");
        Assert.Contains("long context: 0", output);
        Assert.DoesNotContain("SECRET", output);
    }

    public static void Status_BudgetAndJson()
    {
        var (exit, output, _) = Run("status", "--session", CliSessionId, "--cli-root", CliHome, "--budget", "0.1");
        Assert.Equal(ExitCodes.BudgetExceeded, exit);
        Assert.Contains("BUDGET EXCEEDED", output);
        var (jsonExit, json, _) = Run("status", "--session", CliSessionId, "--cli-root", CliHome, "--json", "--budget", "10");
        Assert.Equal(0, jsonExit);
        var doc = JsonNode.Parse(json)!;
        Assert.Equal(2, (int)doc["calls"]!);
        Assert.Equal(false, (bool)doc["budgetExceeded"]!);
        Assert.Equal("--session", (string)doc["identifiedBy"]!);
    }

    public static void Phase_EndSummarizesCallsSinceStart()
    {
        // The fixture's calls are in the past, so the start checkpoint is written directly, before them.
        Checkpoints.Add(CliSessionId, new Checkpoint("reqs", Checkpoint.Start, DateTimeOffset.Parse("2026-11-07T12:59:00Z").ToUnixTimeMilliseconds()));
        var (exit, output, err) = Run("phase", "end", "reqs", "--session", CliSessionId, "--cli-root", CliHome);
        Assert.Equal(0, exit, "exit; stderr: " + err);
        Assert.Contains("PHASE reqs  0.22 credits (100% billed)  2 calls", output);
        Assert.Contains("session so far: 0.22 credits", output);
        Assert.True(output.Split('\n', StringSplitOptions.RemoveEmptyEntries).Length <= 12, "at most 12 lines");
        Assert.Equal(2, Checkpoints.Load(CliSessionId).Count, "start and end saved");
    }

    public static void Phase_StartThenEndWithoutNewCallsExitsFour()
    {
        var (startExit, startOut, _) = Run("phase", "start", "design", "--session", CliSessionId, "--cli-root", CliHome);
        Assert.Equal(0, startExit);
        Assert.Contains("PHASE design started", startOut);
        Assert.Contains("(--session)", startOut, "says how the session was found");
        var (exit, output, _) = Run("phase", "end", "design", "--session", CliSessionId, "--cli-root", CliHome);
        Assert.Equal(ExitCodes.NoNewData, exit, "no calls since the start");
        Assert.Contains("no model calls logged", output);
    }

    public static void Phase_EndWithoutStartIsAnError()
    {
        var (exit, _, err) = Run("phase", "end", "never-started", "--session", CliSessionId, "--cli-root", CliHome);
        Assert.Equal(ExitCodes.Error, exit);
        Assert.Contains("was not started", err);
    }
}
