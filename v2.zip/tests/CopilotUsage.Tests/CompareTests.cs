using CopilotUsage.Analysis;
using CopilotUsage.Model;
using CopilotUsage.Pricing;
using CopilotUsage.Report;
using CopilotUsage.Storage;

namespace CopilotUsage.Tests;

/// <summary>M4: the two-run comparison (FR-11).</summary>
public static class CompareTests
{
    static readonly DateTimeOffset T0 = DateTimeOffset.Parse("2026-11-07T09:00:00Z");

    /// <summary>A billed session: (agent, run, input, cached, output, credits) per call.</summary>
    static SessionData Run(string id, params (string Agent, string RunId, long Input, long Cached, long Output, double Credits)[] calls)
    {
        var d = new SessionData { Session = new CliSession(id, id, null, "run " + id, null, false, DateTime.UtcNow.AddHours(-1)), CopilotVersion = "1.0.103" };
        d.SeeTimestamp(T0);
        for (int i = 0; i < calls.Length; i++)
        {
            var (agent, run, input, cached, output, credits) = calls[i];
            if (run != AgentRun.MainId && !d.Runs.ContainsKey(run)) d.Runs[run] = new AgentRun { Id = run, Name = agent };
            d.Calls.Add(new ModelCall
            {
                Agent = agent, AgentRunId = run, Model = "gpt-6.1-sol", Input = input, CacheRead = cached, Output = output,
                NanoAiu = (long)(credits * 1e9), Start = T0.AddSeconds(i * 10), End = T0.AddSeconds(i * 10 + 5),
            });
        }
        d.SeeTimestamp(T0.AddSeconds(calls.Length * 10));
        d.Finish();
        new CostEngine(PricingTable.Load()).Apply(d);
        return d;
    }

    static SessionData Baseline() => Run("aaaa",
        ("main", "main", 20_000, 10_000, 500, 1.0), ("main", "main", 30_000, 20_000, 500, 1.2),
        ("Reqs", "r1", 40_000, 10_000, 2_000, 3.0), ("Reqs", "r1", 60_000, 15_000, 2_000, 4.0));

    static SessionData Trimmed() => Run("bbbb",
        ("main", "main", 18_000, 12_000, 500, 0.9), ("main", "main", 25_000, 20_000, 500, 1.0),
        ("Reqs", "r1", 40_000, 34_000, 1_500, 1.5), ("Reqs", "r2", 30_000, 26_000, 1_000, 1.0));

    public static void Bridges_AddUpExactlyToTheDifference()
    {
        var c = Comparison.Build(Baseline(), Trimmed(), Dimension.Agent, "baseline", "trimmed");
        Assert.True(Math.Abs(c.BridgeByGroup.Sum(s => s.Delta) - c.Delta) < 1e-9, "agent bridge");
        Assert.True(Math.Abs(c.BridgeByCause.Sum(s => s.Delta) - c.Delta) < 1e-9, "cause bridge");
        Assert.True(Math.Abs(c.Delta - (4.4 - 9.2)) < 1e-9, "B − A");
    }

    public static void Agents_MatchByNameAndCountRuns()
    {
        var c = Comparison.Build(Baseline(), Trimmed(), Dimension.Agent);
        var reqs = c.Groups.Single(g => g.Name == "Reqs");
        Assert.Equal((1, 2), (reqs.RunsA, reqs.RunsB), "repeated runs compared as a total, run count shown");
        Assert.Equal("1 → 2 runs", c.BridgeByGroup.Single(s => s.Name == "Reqs").Note);
        Assert.Equal("Reqs", c.Groups[0].Name, "largest change first");
    }

    public static void Findings_NameTheLargestStepAndItsCache()
    {
        var c = Comparison.Build(Baseline(), Trimmed(), Dimension.Agent, "baseline", "trimmed");
        var top = c.ChangeFindings[0].Text;
        Assert.Contains("trimmed saved 4.80 (−52%)", top);
        Assert.Contains("The largest step was sub-agent Reqs: 7.00 → 2.50", top);
        Assert.Contains("cached share going from 25% to 86%", top);
    }

    public static void Warnings_FlagUnfairComparisons()
    {
        var a = Baseline();
        var b = Run("cccc", ("main", "main", 20_000, 10_000, 500, 1.0), ("Design", "d1", 10_000, 0, 100, 0.5));
        b.CopilotVersion = "1.0.110";
        b.Calls[0].Model = "gpt-6-luna";
        var w = Comparison.Build(a, b, Dimension.Agent).Warnings;
        Assert.True(w.Any(x => x.StartsWith("Different models")), "model");
        Assert.True(w.Any(x => x.Contains("A: Reqs") && x.Contains("B: Design")), "sub-agents in only one run");
        Assert.True(w.Any(x => x.Contains("Different Copilot versions")), "version");
        Assert.Contains("A and B are the same session.", string.Join("|", Comparison.Build(a, a, Dimension.Agent).Warnings));
    }

    public static void ManyGroups_FoldIntoOthersAndStillAddUp()
    {
        var a = Run("aaaa", Enumerable.Range(0, 12).Select(i => ($"agent{i}", $"r{i}", 1000L, 0L, 10L, 1.0 + i)).ToArray());
        var b = Run("bbbb", Enumerable.Range(0, 12).Select(i => ($"agent{i}", $"r{i}", 1000L, 0L, 10L, 1.0 + i * 0.5)).ToArray());
        var c = Comparison.Build(a, b, Dimension.Agent);
        Assert.Equal(Comparison.MaxBridgeSteps, c.BridgeByGroup.Count, "folded");
        Assert.Contains("others", c.BridgeByGroup[^1].Name);
        Assert.True(Math.Abs(c.BridgeByGroup.Sum(s => s.Delta) - c.Delta) < 1e-9, "still adds up");
    }

    public static void Curves_DrawOneLinePerRun()
    {
        var c = Comparison.Build(Baseline(), Trimmed(), Dimension.Agent);
        var reqs = c.Curves.Single(x => x.Agent == "Reqs");
        Assert.Equal(1, reqs.A.Count, "one run in A");
        Assert.Equal(2, reqs.B.Count, "two runs in B");
        Assert.Equal(1.0, reqs.A[0][^1].X, "x runs from 0 to 1 within a run");
    }

    public static void SameRun_CostsTheSame()
    {
        var c = Comparison.Build(Baseline(), Baseline(), Dimension.Agent);
        Assert.Contains("cost the same", c.ChangeFindings.Single().Text);
        Assert.Contains("cost the same as", CompareReport.Build(c));
    }

    public static void Report_IsSelfContainedAndEscapesLabels()
    {
        var html = CompareReport.Build(Comparison.Build(Baseline(), Trimmed(), Dimension.Agent, "<b>base</b>", "new & better"));
        foreach (var part in new[] { "Headline changes", "Credit bridge by agent", "Credit bridge by cause", "Context curves", "Fixed overhead", "Tool usage", "Matched by name" })
            Assert.Contains(part, html, part);
        Assert.DoesNotContain("<b>base</b>", html, "labels are escaped");
        Assert.Contains("&lt;b&gt;base&lt;/b&gt;", html);
        Assert.Contains("new &amp; better", html);
        Assert.DoesNotContain("https://", html, "no network");
        Assert.DoesNotContain("<script src", html, "no external scripts");
    }

    public static void Command_ComparesFixtureSessions()
    {
        var file = Path.Combine(Fixtures.EmptyDir(), "c.html");
        var stdout = new StringWriter();
        var stderr = new StringWriter();
        int exit = Program.Run(["compare", "1111", "4444", "--root", Fixtures.UserDir, "--cli-root", Path.Combine(Fixtures.Root, "copilot"),
            "--label-a", "local", "--label-b", "copilot", "--out", file], stdout, stderr);
        Assert.Equal(0, exit, "exit; stderr: " + stderr);
        Assert.Contains("local 0.30 → copilot 0.22 credits", stdout.ToString());
        var html = File.ReadAllText(file);
        Assert.Contains("different harnesses", html, "Local vs Copilot harness flagged");
        Assert.DoesNotContain("SECRET", html, "no content");
        Assert.Equal(ExitCodes.Error, Program.Run(["compare", "1111", "4444", "--by", "tool"], new StringWriter(), new StringWriter()), "bad --by");
    }
}
