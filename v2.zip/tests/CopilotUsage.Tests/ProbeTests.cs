using CopilotUsage.Logs;
using CopilotUsage.Pricing;
using CopilotUsage.Probe;
using CopilotUsage.Storage;

namespace CopilotUsage.Tests;

public static class ProbeTests
{
    static ProbeResult Probe(string sessionId, string? eventsDir = null)
    {
        var session = SessionCatalog.FindAll(StorageRoots.Find(Fixtures.UserDir)).Single(s => s.Id == sessionId);
        return Prober.Run(session, new ProbeOptions
        {
            Pricing = PricingTable.Load(),
            EventsDir = eventsDir ?? Fixtures.EmptyDir(),
        });
    }

    static CheckOutcome Outcome(ProbeResult r, string id) => r.Checks.Single(c => c.Id == id).Outcome;

    public static void WorkspaceSession_PassesGateG0()
    {
        var r = Probe(Fixtures.WorkspaceSession);
        Assert.True(r.GatePassed, "G0 passes");
        foreach (var id in new[] { "P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P10", "P11", "P12", "P14" })
            Assert.Equal(CheckOutcome.Pass, Outcome(r, id), id + ": " + r.Checks.Single(c => c.Id == id).Detail);
        Assert.Equal(CheckOutcome.Info, Outcome(r, "P9"), "P9");
        Assert.Equal(CheckOutcome.Skip, Outcome(r, "P13"), "P13 needs --live");
        Assert.Equal(CheckOutcome.Warn, Outcome(r, "P15"), "P15: hooks seen in the debug log, no event file");
        Assert.Equal("0.60.0", r.CopilotVersion, "Copilot version from session_start");
        Assert.Equal("Generate PIL harness", r.Title, "title from state.vscdb");
    }

    public static void WorkspaceSession_CountsCallsAcrossMainAndChildLogs()
    {
        var f = Probe(Fixtures.WorkspaceSession).Fingerprint;
        var llm = f["llmRequests"]!;
        Assert.Equal(6, (int)llm["total"]!, "llm_request total (4 main + 2 sub-agent)");
        Assert.Equal(5, (int)llm["ok"]!, "successful calls");
        Assert.Equal(1, (int)llm["overLongContext"]!, "calls over 272K");
        Assert.Equal(290_000L, (long)llm["peakInputTokens"]!, "peak input");
        Assert.Equal(1, (int)f["files"]!.AsArray().Single(x => (string)x!["pattern"]! == "main.jsonl")!["badLines"]!, "bad line counted, not fatal");
    }

    public static void Fingerprint_HoldsNoContent()
    {
        var json = Probe(Fixtures.WorkspaceSession).Fingerprint.ToJsonString();
        Assert.DoesNotContain("SECRET", json, "fingerprint");
        Assert.DoesNotContain("pil-harness", json, "fingerprint (folder path)");
        Assert.DoesNotContain("Generate PIL harness", json, "fingerprint (title)");
        Assert.Contains("\"read_file\"", json, "tool names are kept");
        Assert.Contains("\"gpt-6.1-sol\"", json, "model names are kept");
        Assert.Contains("\"Reqs\"", json, "sub-agent names are kept");
    }

    public static void GlobalSession_FailsGateAndListsUnknowns()
    {
        var r = Probe(Fixtures.GlobalSession);
        Assert.True(!r.GatePassed, "G0 fails without model calls");
        Assert.Equal(CheckOutcome.Pass, Outcome(r, "P1"), "P1");
        Assert.Equal(CheckOutcome.Fail, Outcome(r, "P2"), "P2");
        Assert.Equal(CheckOutcome.Info, Outcome(r, "P11"), "P11");
        var unknown = r.Fingerprint["unknown"]!.ToJsonString();
        Assert.Contains("mystery_event", unknown, "unknown type");
        Assert.Contains("session_start.attrs.newField", unknown, "unknown field");
        Assert.Equal(2, (int)r.Fingerprint["files"]!.AsArray()[0]!["badLines"]!, "broken and non-object lines");
        Assert.Equal(CheckOutcome.Info, Outcome(r, "P10"), "no global state.vscdb in the fixture");
    }

    public static void HookEventFile_PassesP14ToP16()
    {
        var events = Fixtures.EmptyDir();
        File.WriteAllLines(Path.Combine(events, Fixtures.WorkspaceSession + ".jsonl"),
        [
            """{"event":"SessionStart","ts":1}""",
            """{"event":"PostToolUse","ts":2,"tool":"read_file","responseLength":1234}""",
            """{"event":"Stop","ts":3}""",
        ]);
        var r = Probe(Fixtures.WorkspaceSession, events);
        Assert.Equal(CheckOutcome.Pass, Outcome(r, "P14"), "P14");
        Assert.Equal(CheckOutcome.Pass, Outcome(r, "P15"), "P15");
        Assert.Equal(CheckOutcome.Pass, Outcome(r, "P16"), "P16");
    }

    public static void Classify_KnowsEveryFileCopilotWrites()
    {
        Assert.Equal(LogFileKind.Main, DebugLogFormat.Classify("main.jsonl").Kind);
        Assert.Equal((LogFileKind.Child, "runSubagent-*.jsonl"), DebugLogFormat.Classify("runSubagent-Reqs-functions.runSubagent_3.jsonl"));
        Assert.Equal((LogFileKind.Child, "title-*.jsonl"), DebugLogFormat.Classify("title-1234abcd.jsonl"));
        Assert.Equal((LogFileKind.SystemPrompt, "system_prompt_*.json"), DebugLogFormat.Classify("system_prompt_12.json"));
        Assert.Equal((LogFileKind.Tools, "tools_*.json"), DebugLogFormat.Classify("tools_0.json"));
        Assert.Equal(LogFileKind.Models, DebugLogFormat.Classify("models.json").Kind);
        Assert.Equal((LogFileKind.Other, "main.jsonl.#.tmp"), DebugLogFormat.Classify("main.jsonl.1794040000000.tmp"));
    }
}
