using CopilotUsage.Pricing;
using CopilotUsage.Probe;
using CopilotUsage.Storage;

namespace CopilotUsage.Tests;

/// <summary>The Copilot harness source: ~/.copilot/session-state (VS Code agent host / Copilot CLI).</summary>
public static class CliSourceTests
{
    const string Session = "44444444-4444-4444-8444-444444444444";
    static string Home => Path.Combine(Fixtures.Root, "copilot");

    static (int Exit, string Out, string Err) Run(params string[] args)
    {
        var stdout = new StringWriter();
        var stderr = new StringWriter();
        return (Program.Run(args, stdout, stderr), stdout.ToString(), stderr.ToString());
    }

    static ProbeResult Probe() =>
        CliProber.Run(CliSessionCatalog.FindAll(Home).Single(), new ProbeOptions { Pricing = PricingTable.Load(), EventsDir = Fixtures.EmptyDir() });

    static CheckOutcome Outcome(ProbeResult r, string id) => r.Checks.Single(c => c.Id == id).Outcome;

    public static void Catalog_ReadsWorkspaceYaml()
    {
        var s = CliSessionCatalog.FindAll(Home).Single();
        Assert.Equal(Session, s.Id, "id");
        Assert.Equal(@"C:\work\pil-harness", s.WorkspaceFolder, "cwd");
        Assert.Equal("Requirements pass", s.Title, "quoted name");
        Assert.Equal("example/pil-harness", s.Repository, "repository");
        Assert.True(!s.Active, "no inuse lock, so not open");
        Assert.Equal(SessionSource.CopilotCli, s.Source);
    }

    public static void Catalog_AcceptsHomeOrSessionStateFolder() =>
        Assert.Equal(1, CliSessionCatalog.FindAll(Path.Combine(Home, "session-state")).Count, "session-state folder given directly");

    public static void Selector_FromDirPicksTheRightSource()
    {
        var dir = Path.Combine(Home, "session-state", Session);
        Assert.True(SessionSelector.FromDir(dir) is CliSession, "events.jsonl → Copilot harness session");
    }

    public static void Probe_PassesEveryCheckItCan()
    {
        var r = Probe();
        Assert.True(r.GatePassed, "G0");
        foreach (var id in new[] { "P1", "P2", "P3", "P4", "P5", "P7", "P8", "P9", "P10", "P11", "P12", "P14", "P15", "P16", "P19" })
            Assert.Equal(CheckOutcome.Pass, Outcome(r, id), id + ": " + r.Checks.Single(c => c.Id == id).Detail);
        Assert.Equal(CheckOutcome.Pass, Outcome(r, "P6"), "every model in the fixture is in pricing.json");
        Assert.Equal(CheckOutcome.Skip, Outcome(r, "P13"), "P13 needs --live");
        Assert.Equal("1.0.103", r.CopilotVersion);
    }

    public static void Probe_CountsUsageAndReconcilesTotals()
    {
        var r = Probe();
        var usage = r.Fingerprint["usage"]!;
        Assert.Equal(2, (int)usage["records"]!, "usage records");
        Assert.Equal(1, (int)usage["byAgent"]!, "calls made by a sub-agent");
        Assert.Equal(1, (int)usage["overLongContext"]!, "calls over 272K");
        Assert.Equal(224_000_000L, (long)usage["sumNanoAiu"]!, "sum of per-call nanoAIU");
        Assert.Contains("(match)", r.Checks.Single(c => c.Id == "P19").Detail);
        Assert.Equal(1, (int)r.Fingerprint["file"]!["badLines"]!, "bad line counted, not fatal");
    }

    public static void Probe_TotalsMismatchWarns()
    {
        var dir = Path.Combine(Fixtures.EmptyDir(), "session-state", Session);
        Directory.CreateDirectory(dir);
        var lines = File.ReadAllLines(Path.Combine(Home, "session-state", Session, "events.jsonl"))
            .Select(l => l.Replace("\"totalNanoAiu\":224000000", "\"totalNanoAiu\":300000000"));
        File.WriteAllLines(Path.Combine(dir, "events.jsonl"), lines);
        var r = CliProber.Run(CliSessionCatalog.FromDir(dir), new ProbeOptions { Pricing = PricingTable.Load(), EventsDir = Fixtures.EmptyDir() });
        Assert.Equal(CheckOutcome.Warn, Outcome(r, "P19"));
    }

    public static void Fingerprint_HoldsNoContent()
    {
        var json = Probe().Fingerprint.ToJsonString();
        Assert.DoesNotContain("SECRET", json, "fingerprint");
        Assert.DoesNotContain("pil-harness", json, "fingerprint (folder, repository)");
        Assert.DoesNotContain("Requirements pass", json, "fingerprint (title)");
        Assert.DoesNotContain("copilot-usage status", json, "fingerprint (command line)");
        Assert.Contains("\"powershell\"", json, "tool names are kept");
        Assert.Contains("\"explore\"", json, "sub-agent names are kept");
    }

    public static void Cli_ProbeAndDoctorUseOnlyTheGivenCliRoot()
    {
        var outFile = Path.Combine(Fixtures.EmptyDir(), "fp.json");
        var (exit, output, err) = Run("probe", "latest", "--cli-root", Home, "--out", outFile);
        Assert.Equal(ExitCodes.Ok, exit, "probe exit; stderr: " + err);
        Assert.Contains("Source  Copilot harness (session-state)", output);
        Assert.Contains(Session, output);

        var (_, doctor, _) = Run("doctor", "--cli-root", Home);
        Assert.Contains("1 sessions, 0 open", doctor);
        Assert.Contains("not searched (--cli-root given)", doctor);
    }

    public static void Cli_MissingCliRootIsAnError() =>
        Assert.Equal(ExitCodes.Error, Run("probe", "--cli-root", Path.Combine(Fixtures.Root, "sqlite")).Exit);
}
