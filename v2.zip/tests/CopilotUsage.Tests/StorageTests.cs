using CopilotUsage.Storage;

namespace CopilotUsage.Tests;

public static class StorageTests
{
    static IReadOnlyList<DebugLogSession> FixtureSessions() => SessionCatalog.FindAll(StorageRoots.Find(Fixtures.UserDir));

    public static void UriToPath_DecodesWindowsDrive() =>
        Assert.Equal(@"C:\dev\gh_experiments\experiments", WorkspaceInfo.UriToPath("file:///c%3A/dev/gh_experiments/experiments"));

    public static void UriToPath_KeepsUnixPath() =>
        Assert.Equal("/home/me/repo name", WorkspaceInfo.UriToPath("file:///home/me/repo%20name"));

    public static void UriToPath_HandlesUncHost() =>
        Assert.Equal(@"\\server\share\x", WorkspaceInfo.UriToPath("file://server/share/x"));

    public static void UriToPath_LeavesRemoteUriReadable() =>
        Assert.Equal("vscode-remote://wsl+Ubuntu/home/me", WorkspaceInfo.UriToPath("vscode-remote://wsl%2BUbuntu/home/me"));

    public static void RootOverride_AcceptsUserParentAndStorageFolders()
    {
        var expected = Path.GetFullPath(Fixtures.UserDir);
        Assert.Equal(expected, StorageRoots.FromOverride(Fixtures.UserDir)!.UserDir, "User folder");
        Assert.Equal(expected, StorageRoots.FromOverride(Fixtures.Root)!.UserDir, "parent folder");
        Assert.Equal(expected, StorageRoots.FromOverride(Path.Combine(Fixtures.UserDir, "workspaceStorage"))!.UserDir, "workspaceStorage");
        Assert.True(StorageRoots.FromOverride(Path.Combine(Fixtures.Root, "sqlite")) is null, "a folder without VS Code data is rejected");
    }

    public static void FindAll_FindsWorkspaceAndGlobalSessions()
    {
        var sessions = FixtureSessions();
        Assert.Equal(3, sessions.Count, "session count: workspace, global, and the global one whose log is empty (77…)");
        var ws = sessions.Single(s => s.Id == Fixtures.WorkspaceSession);
        Assert.Equal(@"C:\work\pil-harness", ws.WorkspaceFolder, "workspace folder");
        Assert.True(!ws.IsGlobal, "workspace session is not global");
        Assert.True(ws.StateDbPath!.EndsWith(Path.Combine("a1b2c3d4e5f60718293a4b5c6d7e8f90", "state.vscdb")), "workspace state.vscdb");
        var global = sessions.Single(s => s.Id == Fixtures.GlobalSession);
        Assert.True(global.IsGlobal, "global session");
        Assert.True(global.WorkspaceFolder is null, "global session has no folder");
    }

    public static void FindAll_SortsNewestFirst()
    {
        var sessions = FixtureSessions();
        for (int i = 1; i < sessions.Count; i++)
            Assert.True(sessions[i - 1].LastWriteUtc >= sessions[i].LastWriteUtc, "sorted by last write, newest first");
    }

    public static void Select_ByIndexLatestPrefixAndFolder()
    {
        var sessions = FixtureSessions();
        Assert.Equal(sessions[0].Id, SessionSelector.Select(null, null, sessions).Id, "default is latest");
        Assert.Equal(sessions[0].Id, SessionSelector.Select("latest", null, sessions).Id, "latest");
        Assert.Equal(sessions[1].Id, SessionSelector.Select("2", null, sessions).Id, "index 2");
        Assert.Equal(Fixtures.GlobalSession, SessionSelector.Select("3333", null, sessions).Id, "all-digit prefix beyond the list is an ID");
        Assert.Equal(Fixtures.GlobalSession, SessionSelector.Select("33333333-3", null, sessions).Id, "prefix");
        Assert.Equal(Fixtures.WorkspaceSession, SessionSelector.Select(Fixtures.WorkspaceSession.ToUpperInvariant(), null, sessions).Id, "full ID, any case");
    }

    public static void Select_ReportsMissingSessionsWithExitCode3()
    {
        var sessions = FixtureSessions();
        Assert.Equal(ExitCodes.SessionNotIdentified, Assert.Throws<CliException>(() => SessionSelector.Select("9", null, sessions)).ExitCode, "index out of range");
        Assert.Equal(ExitCodes.SessionNotIdentified, Assert.Throws<CliException>(() => SessionSelector.Select("ffff", null, sessions)).ExitCode, "unknown prefix");
        Assert.Equal(ExitCodes.SessionNotIdentified, Assert.Throws<CliException>(() => SessionSelector.Select("latest", null, [])).ExitCode, "no sessions");
    }

    public static void Select_AmbiguousPrefixListsMatches()
    {
        var a = new DebugLogSession("abc-1", "x", null, null, null, DateTime.UtcNow);
        var b = new DebugLogSession("abc-2", "y", null, null, null, DateTime.UtcNow);
        var e = Assert.Throws<CliException>(() => SessionSelector.Select("abc", null, [a, b]));
        Assert.Contains("abc-1, abc-2", e.Message);
    }

    public static void Select_ByDebugLogFolderWithDir()
    {
        var dir = FixtureSessions().Single(s => s.Id == Fixtures.WorkspaceSession).Dir;
        var s = SessionSelector.Select(null, dir, []);
        Assert.Equal(Fixtures.WorkspaceSession, s.Id, "id from folder name");
        Assert.Equal(@"C:\work\pil-harness", s.WorkspaceFolder, "folder found from the storage layout");
    }

    public static void ReadNewLines_ReturnsOnlyCompleteNewLines()
    {
        var file = Path.Combine(Fixtures.EmptyDir(), "log.jsonl");
        File.WriteAllText(file, "one\ntwo\npart");
        var lines = new List<string>();
        long offset = SafeFile.ReadNewLines(file, 0, lines);
        Assert.Equal(2, lines.Count, "complete lines");
        File.AppendAllText(file, "ial\nthree\n");
        lines.Clear();
        SafeFile.ReadNewLines(file, offset, lines);
        Assert.Equal("partial|three", string.Join("|", lines));
    }
}
