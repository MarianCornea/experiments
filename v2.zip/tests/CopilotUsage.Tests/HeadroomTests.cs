using CopilotUsage.Analysis;
using CopilotUsage.Logs;
using CopilotUsage.Model;
using CopilotUsage.Pricing;
using CopilotUsage.Report;
using CopilotUsage.Storage;

namespace CopilotUsage.Tests;

/// <summary>Usable context: the prompt size left after Copilot's output reservation, and how close each run came to it.</summary>
public static class HeadroomTests
{
    static SessionData Cli() => SessionLoader.Load(CliSessionCatalog.FindAll(Path.Combine(Fixtures.Root, "copilot")).Single(), PricingTable.Load());

    static SessionData Debug() =>
        SessionLoader.Load(SessionCatalog.FindAll(StorageRoots.Find(Fixtures.UserDir)).Single(s => s.Id == Fixtures.WorkspaceSession), PricingTable.Load());

    public static void Parsers_RecordEachCallsPromptLimit()
    {
        var cli = Cli();
        Assert.Equal(272000L, cli.Calls.First(c => c.Model.StartsWith("gpt")).MaxPromptTokens, "Copilot harness: usage.maxPromptTokens");
        Assert.Equal(128000L, cli.Calls.First(c => c.Model.StartsWith("mai-code")).MaxPromptTokens, "per model");
        Assert.Equal(922000L, Debug().Calls.First(c => c.Model == "gpt-6.1-sol").MaxPromptTokens, "debug log: models.json max_prompt_tokens");
    }

    public static void ModelLimits_MatchTheNamesLogsUse()
    {
        var limits = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase) { ["gpt-6-luna"] = 872000 };
        Assert.Equal(872000L, ModelLimits.For(limits, "copilot/gpt-6-luna"));
        Assert.Equal(872000L, ModelLimits.For(limits, "GPT-6 Luna"));
        Assert.Equal(null, ModelLimits.For(limits, "mai-code-1.1-flash"));
        Assert.Equal(0, ModelLimits.Read(Path.Combine(Fixtures.EmptyDir(), "missing.json")).Count, "no file: no limits");
    }

    public static void Headroom_FlagsARunNearItsLimit()
    {
        var d = new SessionData { Session = CliSessionCatalog.FindAll(Path.Combine(Fixtures.Root, "copilot")).Single() };
        var t0 = DateTimeOffset.Parse("2026-11-09T10:00:00Z");
        long[] inputs = [40_000, 80_000, 112_000, 30_000];
        for (int i = 0; i < inputs.Length; i++)
            d.Calls.Add(new ModelCall { Model = "mai-code-1.1-flash", Input = inputs[i], Output = 100, NanoAiu = 10_000_000, MaxPromptTokens = 128_000,
                                        Start = t0.AddSeconds(i * 10), End = t0.AddSeconds(i * 10 + 5) });
        d.Finish();
        new CostEngine(PricingTable.Load()).Apply(d);
        var row = Headroom.By(d).Single();
        Assert.Equal(112000L, row.Peak);
        Assert.Equal(1, row.Drops, "the compaction after the peak");
        Assert.True(Math.Abs(row.Share!.Value - 0.875) < 1e-9, "112K of 128K");
        var finding = Findings.For(d, ContextGrowth.Analyze(d)).Single(f => f.Text.Contains("usable context"));
        Assert.Contains("The main agent reached 88% of its usable context (112K of 128K tokens on mai-code-1.1-flash); its context dropped once", finding.Text);
    }

    public static void Report_ShowsHeadroomAndTheUsableShare()
    {
        var html = HtmlReport.Build(Cli(), PricingTable.Load());
        Assert.Contains("<h3>Context headroom</h3>", html);
        Assert.Contains("The reservation itself is not billed", html);
        Assert.Contains(" usable (", html, "peak tile: of N usable (x%)");
        Assert.DoesNotContain("reached 0% of its usable context", html, "no finding far from the limit");
    }

    public static void Status_SaysHowMuchContextIsUsable()
    {
        var stdout = new StringWriter();
        Program.Run(["status", "--session", "44444444-4444-4444-8444-444444444444", "--cli-root", Path.Combine(Fixtures.Root, "copilot")], stdout, new StringWriter());
        Assert.Contains("usable", stdout.ToString());
    }
}
