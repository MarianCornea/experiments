﻿using System.Diagnostics;
using System.Reflection;

namespace CopilotUsage.Tests;

/// <summary>
/// Runs every public static void method of the public static classes whose name ends in "Tests".
/// Optional argument: a filter matched against "Class.Method".
/// </summary>
public static class Runner
{
    public static int Main(string[] args)
    {
        // Keep the tool's own data (events, checkpoints, caches) away from the real one, and ignore a session ID
        // inherited from a Copilot shell the tests may be run from.
        Environment.SetEnvironmentVariable("COPILOT_USAGE_HOME", Fixtures.EmptyDir());
        Environment.SetEnvironmentVariable("COPILOT_AGENT_SESSION_ID", null);
        var filter = args.FirstOrDefault();
        var tests = typeof(Runner).Assembly.GetTypes()
            .Where(t => t.IsPublic && t.IsAbstract && t.IsSealed && t.Name.EndsWith("Tests", StringComparison.Ordinal))
            .SelectMany(t => t.GetMethods(BindingFlags.Public | BindingFlags.Static).Where(m => m.ReturnType == typeof(void) && m.GetParameters().Length == 0))
            .Where(m => filter is null || $"{m.DeclaringType!.Name}.{m.Name}".Contains(filter, StringComparison.OrdinalIgnoreCase))
            .OrderBy(m => m.DeclaringType!.Name).ThenBy(m => m.Name)
            .ToList();

        int failed = 0;
        var clock = Stopwatch.StartNew();
        foreach (var test in tests)
        {
            var name = $"{test.DeclaringType!.Name}.{test.Name}";
            try
            {
                test.Invoke(null, null);
                Console.WriteLine($"  ok    {name}");
            }
            catch (TargetInvocationException e)
            {
                failed++;
                var inner = e.InnerException ?? e;
                Console.WriteLine($"  FAIL  {name}: {inner.Message}");
                if (inner is not AssertException) Console.WriteLine(inner.StackTrace);
            }
        }
        Console.WriteLine($"{tests.Count - failed} passed, {failed} failed ({clock.Elapsed.TotalSeconds:N1} s)");
        return failed == 0 && tests.Count > 0 ? 0 : 1;
    }
}

public sealed class AssertException(string message) : Exception(message);

public static class Assert
{
    public static void True(bool condition, string message = "expected true")
    {
        if (!condition) throw new AssertException(message);
    }

    public static void Equal<T>(T expected, T actual, string? what = null)
    {
        if (!EqualityComparer<T>.Default.Equals(expected, actual))
            throw new AssertException($"{what ?? "value"}: expected <{expected}>, got <{actual}>");
    }

    public static void Contains(string expected, string actual, string? what = null)
    {
        if (!actual.Contains(expected, StringComparison.Ordinal))
            throw new AssertException($"{what ?? "text"} does not contain <{expected}>: {Clip(actual)}");
    }

    public static void DoesNotContain(string unexpected, string actual, string? what = null)
    {
        if (actual.Contains(unexpected, StringComparison.Ordinal))
            throw new AssertException($"{what ?? "text"} contains <{unexpected}>");
    }

    public static T Throws<T>(Action action) where T : Exception
    {
        try { action(); }
        catch (T e) { return e; }
        catch (Exception e) { throw new AssertException($"expected {typeof(T).Name}, got {e.GetType().Name}: {e.Message}"); }
        throw new AssertException($"expected {typeof(T).Name}, nothing was thrown");
    }

    static string Clip(string s) => s.Length > 300 ? s[..300] + "..." : s;
}

/// <summary>Paths into tests/fixtures, copied next to the test executable.</summary>
public static class Fixtures
{
    public static string Root => Path.Combine(AppContext.BaseDirectory, "fixtures");
    public static string UserDir => Path.Combine(Root, "User");
    public const string WorkspaceSession = "11111111-1111-4111-8111-111111111111";
    public const string GlobalSession = "33333333-3333-4333-8333-333333333333";

    /// <summary>An empty folder for tests that must not see the user's real tool data.</summary>
    public static string EmptyDir()
    {
        var dir = Path.Combine(Path.GetTempPath(), "copilot-usage-tests", Guid.NewGuid().ToString("n"));
        Directory.CreateDirectory(dir);
        return dir;
    }
}
