using CopilotUsage.Analysis;
using CopilotUsage.Model;
using CopilotUsage.Pricing;
using CopilotUsage.Report;
using CopilotUsage.Storage;

namespace CopilotUsage.Tests;

/// <summary>M3: findings and the HTML report (FR-09, NFR-05, NFR-07).</summary>
public static class ReportTests
{
    static SessionData Cli() => SessionLoader.Load(CliSessionCatalog.FindAll(Path.Combine(Fixtures.Root, "copilot")).Single(), PricingTable.Load());

    static SessionData Debug() =>
        SessionLoader.Load(SessionCatalog.FindAll(StorageRoots.Find(Fixtures.UserDir)).Single(s => s.Id == Fixtures.WorkspaceSession), PricingTable.Load());

    public static void Findings_AnswerWhereWhyAndWhatGrew()
    {
        var s = Cli();
        var findings = Findings.For(s, ContextGrowth.Analyze(s));
        var driver = findings.First(f => f.Topic == FindingTopic.Driver);
        Assert.Contains("Sub-agent run explore", driver.Text, "the sub-agent run cost the most");
        Assert.Contains("85%", driver.Text, "0.19 of 0.224 credits");
        Assert.True(findings.Any(f => f.Topic == FindingTopic.Cause), "a cost cause");
        Assert.True(findings.All(f => f.Topic != FindingTopic.LongContext), "mai-code-1.1-flash has one price, so its 300K call is not long context");
        for (int i = 1; i < findings.Count; i++) Assert.True(findings[i - 1].AtStake >= findings[i].AtStake, "ranked by credits at stake");

        // Growth needs two calls of one agent with tools between them. In the Local fixture read_file gets half of the main
        // agent's +9,000 and all of the sub-agent's +260,000: 264.5K.
        var d = Debug();
        var growth = Findings.For(d, ContextGrowth.Analyze(d)).First(f => f.Topic == FindingTopic.Growth);
        Assert.Contains("read_file preceded 265K tokens of context growth", growth.Text, "what grew the context");
    }

    public static void Findings_HandleASessionWithoutCalls()
    {
        var empty = SessionLoader.Load(SessionCatalog.FindAll(StorageRoots.Find(Fixtures.UserDir)).Single(s => s.Id == Fixtures.GlobalSession), PricingTable.Load());
        var findings = Findings.For(empty, ContextGrowth.Analyze(empty));
        Assert.Contains("No model calls", findings.Single().Text);
        var html = HtmlReport.Build(empty, PricingTable.Load());
        Assert.Contains("<h2>Findings</h2>", html, "the report still renders");
    }

    public static void Report_HasAllEightPartsAndNoContent()
    {
        var html = HtmlReport.Build(Debug(), PricingTable.Load());
        foreach (var part in new[] { "Copilot workflow cost report", "class=\"hero\"", "<h2>Findings</h2>", "<h2>Context per call</h2>",
                     "<h2>Cumulative credits</h2>", "<h2>Breakdowns</h2>", "<h2>Context growth by tool</h2>", "<h2>Detail</h2>" })
            Assert.Contains(part, html, "part: " + part);
        Assert.DoesNotContain("SECRET", html, "no prompt, file or argument content");
        Assert.Contains("Generate PIL harness", html, "the session title is allowed");
        Assert.Contains("system_prompt_0.json", html, "prompt artifact sizes");
        Assert.Contains("By skill", html, "skill breakdown (generate-harness)");
    }

    public static void Report_IsSelfContainedWithDarkMode()
    {
        var html = HtmlReport.Build(Cli(), PricingTable.Load());
        Assert.DoesNotContain("<script src", html, "no external scripts");
        Assert.DoesNotContain("<link", html, "no external stylesheets or fonts");
        Assert.DoesNotContain("http://", html.Replace("http://www.w3.org", ""), "no network URLs");
        Assert.DoesNotContain("https://", html, "no network URLs");
        Assert.Contains("prefers-color-scheme:dark", html, "dark mode");
        Assert.Contains("data-theme=\"dark\"", html, "dark mode toggle scope");
    }

    public static void Report_EscapesNames()
    {
        var s = Cli();
        s.Title = "<img src=x onerror=alert(1)>";
        foreach (var c in s.Calls) c.Agent = "a<b>&\"c\"";
        var html = HtmlReport.Build(s, PricingTable.Load());
        Assert.DoesNotContain("<img src=x", html, "title escaped");
        Assert.Contains("&lt;img src=x onerror=alert(1)&gt;", html, "title shown as text");
        Assert.DoesNotContain("a<b>", html, "agent names escaped in tables and tooltip data");
    }

    public static void Report_MarksEstimatedCredits()
    {
        var s = Cli();
        foreach (var c in s.Calls) { c.NanoAiu = null; c.BilledSplitNano = null; }
        new CostEngine(PricingTable.Load()).Apply(s);
        var html = HtmlReport.Build(s, PricingTable.Load());
        Assert.Contains("includes estimated credits", html, "NFR-07: estimated figures are marked");
        Assert.Contains("billed,", html, "headline gives the billed and estimated shares");
    }

    public static void ReportCommand_WritesTheFile()
    {
        var file = Path.Combine(Fixtures.EmptyDir(), "r.html");
        var stdout = new StringWriter();
        int exit = Program.Run(["report", "4444", "--cli-root", Path.Combine(Fixtures.Root, "copilot"), "--out", file], stdout, new StringWriter());
        Assert.Equal(0, exit);
        Assert.Contains("Report: ", stdout.ToString());
        Assert.Contains("format check", File.ReadAllText(file).ToLowerInvariant(), "probe status in the header");
    }
}
