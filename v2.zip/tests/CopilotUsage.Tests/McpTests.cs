using System.Text.Json;
using CopilotUsage.Analysis;
using CopilotUsage.Model;
using CopilotUsage.Pricing;
using CopilotUsage.Probe;
using CopilotUsage.Report;
using CopilotUsage.Storage;
using CopilotUsage.Tracking;

namespace CopilotUsage.Tests;

/// <summary>MCP server statistics (FR-21, FR-22), carried result tokens, and probe checks P17 / P18.</summary>
public static class McpTests
{
    const long T0 = 1794050000000;
    const string Sid = "88888888-8888-4888-8888-888888888888";

    /// <summary>
    /// A debug-log session: four main-agent calls carrying tools_0.json (jira: 3 tools, docs: 1 tool, plus read_file);
    /// mcp_jira_search_issues runs before call 2 (+9,000 tokens), mcp_jira_get_issue fails before call 3 (+1,000).
    /// </summary>
    static DebugLogSession MakeSession()
    {
        var dir = Path.Combine(Fixtures.EmptyDir(), Sid);
        Directory.CreateDirectory(dir);
        static string Def(string name, int descLength) =>
            JsonSerializer.Serialize(new { type = "function", name, description = "SECRET " + new string('d', descLength), parameters = new { type = "object" } });
        var defs = "[" + string.Join(",", Def("read_file", 400), Def("mcp_jira_search_issues", 4000), Def("mcp_jira_get_issue", 2000),
            Def("mcp_jira_create_issue", 800), Def("mcp_docs_lookup", 400)) + "]";
        File.WriteAllText(Path.Combine(dir, "tools_0.json"), JsonSerializer.Serialize(new { content = defs }));
        string Llm(string id, int at, long input, long cached) =>
            $$"""{"ts":{{T0 + at * 1000}},"dur":2000,"sid":"{{Sid}}","type":"llm_request","name":"chat:gpt-6-luna","spanId":"{{id}}","status":"ok","attrs":{"model":"gpt-6-luna","debugName":"panel/editAgent","inputTokens":{{input}},"outputTokens":200,"cachedTokens":{{cached}},"copilotUsageNanoAiu":5000000,"toolsFile":"tools_0.json"} }""";
        string Tool(string name, int at, string status) =>
            $$"""{"ts":{{T0 + at * 1000}},"dur":500,"sid":"{{Sid}}","type":"tool_call","name":"{{name}}","spanId":"t{{at}}","status":"{{status}}","attrs":{"args":"SECRET-ARGS","result":"SECRET-RESULT"} }""";
        File.WriteAllLines(Path.Combine(dir, "main.jsonl"),
        [
            $$"""{"ts":{{T0}},"dur":0,"sid":"{{Sid}}","type":"session_start","name":"session_start","spanId":"s","status":"ok","attrs":{"copilotVersion":"0.73.0"} }""",
            $$"""{"ts":{{T0 + 500}},"dur":0,"sid":"{{Sid}}","type":"user_message","name":"user_message","spanId":"u","status":"ok","attrs":{"content":"SECRET-PROMPT"} }""",
            Llm("c1", 1, 20000, 0), Tool("mcp_jira_search_issues", 4, "ok"), Llm("c2", 6, 29000, 19000),
            Tool("mcp_jira_get_issue", 9, "error"), Llm("c3", 11, 30000, 28000), Llm("c4", 15, 31000, 29000),
        ]);
        return SessionCatalog.FromDir(dir);
    }

    static SessionData Load(DebugLogSession s) => SessionLoader.Load(s, PricingTable.Load(), tool: new ToolData(Fixtures.EmptyDir(), Fixtures.EmptyDir()));

    public static void Names_FollowEachClientsPrefix()
    {
        Assert.Equal("github", McpNames.ServerOf("mcp_github_get_issue"), "VS Code: mcp_<server>_<tool>");
        Assert.Equal("github-mcp-server", McpNames.ServerOf("github-mcp-server-get_issue"), "Copilot runtime: <server>-<tool>");
        Assert.Equal("fs", McpNames.ServerOf("mcp__fs__read_file"), "Claude style: mcp__<server>__<tool>");
        foreach (var builtIn in new[] { "view", "read_file", "copilot_readFile", "runSubagent", "apply_patch" })
            Assert.Equal(null, McpNames.ServerOf(builtIn), builtIn + " is built in");
        var map = new McpMap().Add("search_code", "code-search").Add("github-pull-request_*", "");
        Assert.Equal("code-search", McpNames.ServerOf("search_code", map), "map for a tool without a prefix");
        Assert.Equal(null, McpNames.ServerOf("github-pull-request_activePullRequest", map), "a null entry marks a tool as not MCP");
    }

    public static void Stats_CountDefinitionsUseAndCarriedResults()
    {
        var data = Load(MakeSession());
        Assert.Equal(5, data.ToolDefinitions["tools_0.json"].Count, "names and sizes read from tools_0.json");
        ContextGrowth.Analyze(data);
        var mcp = McpStats.Analyze(data, PricingTable.Load());
        Assert.True(mcp.DefinitionsLogged);
        var jira = mcp.Servers.Single(s => s.Server == "jira");
        Assert.Equal(3, jira.ToolsLoaded, "tools loaded");
        Assert.Equal(2, jira.ToolsUsed, "tools used");
        Assert.Equal("mcp_jira_create_issue", jira.UnusedTools.Single());
        Assert.Equal(4, jira.CallsCarrying, "every call carried tools_0.json");
        Assert.Equal(jira.DefinitionTokensPerCall!.Value * 4, jira.DefinitionTokensCarried, "per-call size × calls");
        Assert.True(jira.DefinitionCost is { } c && c.Low < c.Point && c.Point < c.High, "cost range: all cached < point < all fresh");
        Assert.Equal(1, jira.Failures);

        var search = jira.Tools.Single(t => t.Tool == "mcp_jira_search_issues");
        Assert.Equal(9000L, search.ResultTokens, "inferred from the next call's growth");
        Assert.Equal(27000L, search.CarriedTokens, "carried by calls 2, 3 and 4");
        Assert.Equal(2000L, jira.Tools.Single(t => t.Tool == "mcp_jira_get_issue").CarriedTokens, "1,000 × calls 3 and 4");
        Assert.Equal(0, mcp.Servers.Single(s => s.Server == "docs").ToolsUsed, "docs is loaded, never called");
    }

    public static void Report_ShowsServersFindingsAndCarriedColumn()
    {
        var html = HtmlReport.Build(Load(MakeSession()), PricingTable.Load());
        Assert.Contains("<h2>MCP servers</h2>", html);
        Assert.Contains("mcp_jira_create_issue (unused)", html);
        Assert.Contains("Server jira loads 3 tools and used 2", html, "finding");
        var data = Load(MakeSession());
        var growth = ContextGrowth.Analyze(data);
        var findings = string.Join("|", Findings.For(data, growth, McpStats.Analyze(data, PricingTable.Load())).Select(f => f.Text));
        Assert.Contains("Tool mcp_jira_search_issues returned 1 result averaging 9.0K tokens; later calls carried them for 27K tokens", findings);
        Assert.Contains("<th class=\"n\">Carried</th>", html, "carried column in the context-growth table");
        Assert.DoesNotContain("SECRET", html, "definitions keep names and sizes only");
    }

    public static void Map_RenamesServersInTheReport()
    {
        var file = Path.Combine(Fixtures.EmptyDir(), "map.json");
        File.WriteAllText(file, """{ "mcp_jira_*": "Jira Cloud" }""");
        var html = HtmlReport.Build(Load(MakeSession()), PricingTable.Load(), mcpMap: McpMap.Load(file));
        Assert.Contains("Server Jira Cloud loads 3 tools", html);
        Assert.Throws<CliException>(() => McpMap.Load(Path.Combine(Fixtures.EmptyDir(), "missing.json")));
    }

    public static void Probe_P18PassesWhenDefinitionsNameTheirServer()
    {
        var r = Prober.Run(MakeSession(), new ProbeOptions { Pricing = PricingTable.Load(), EventsDir = Fixtures.EmptyDir() });
        var p18 = r.Checks.Single(c => c.Id == "P18");
        Assert.Equal(CheckOutcome.Pass, p18.Outcome, p18.Detail);
        Assert.Contains("jira (3 tools)", p18.Detail);
        Assert.Equal(CheckOutcome.Skip, r.Checks.Single(c => c.Id == "P17").Outcome, "no budget stop recorded");
    }

    public static void Compare_ListsServersOfBothRuns()
    {
        var a = Load(MakeSession());
        var b = SessionLoader.Load(CliSessionCatalog.FindAll(Path.Combine(Fixtures.Root, "copilot")).Single(), PricingTable.Load());
        var c = Comparison.Build(a, b, Dimension.Agent, "with jira", "without");
        var jira = c.Mcp.Single(r => r.Server == "jira");
        Assert.True(jira.InA && !jira.InB, "present in A only");
        Assert.Contains("not present", CompareReport.Build(c));
    }

    public static void Probe_P17ReadsWhatHappenedAfterEachStop()
    {
        var session = CliSessionCatalog.FindAll(Path.Combine(Fixtures.Root, "copilot")).Single();
        var calls = Logs.CliSessionParser.Parse(session).SuccessfulCalls.OrderBy(c => c.Start).ToList();
        ProbeCheck P17(params HookEvent[] stops)
        {
            var dir = Fixtures.EmptyDir();
            File.WriteAllLines(Path.Combine(dir, session.Id + ".jsonl"), stops.Select(s => s.ToJsonLine()));
            return CliProber.Run(session, new ProbeOptions { Pricing = PricingTable.Load(), EventsDir = dir }).Checks.Single(c => c.Id == "P17");
        }
        HookEvent Stop(string kind, DateTimeOffset at) =>
            new() { Event = "budgetStop", Ts = at.ToUnixTimeMilliseconds(), SessionId = session.Id, Budget = kind, Credits = 0.1, Limit = 0.1 };

        var soft = P17(Stop("soft", calls[0].Start.AddSeconds(-1)));
        Assert.Equal(CheckOutcome.Pass, soft.Outcome, "the agent went on to wrap up: " + soft.Detail);
        var hard = P17(Stop("hard", calls[0].Start.AddSeconds(-30)));
        Assert.Equal(CheckOutcome.Warn, hard.Outcome, "model calls followed the hard stop");
        Assert.Contains("the session was not ended", hard.Detail);
        Assert.Contains("keep the limit as a report warning", hard.Detail);
        var ended = P17(Stop("hard", calls[^1].End.AddSeconds(1)));
        Assert.Equal(CheckOutcome.Pass, ended.Outcome, "nothing after the stop: " + ended.Detail);
    }
}
