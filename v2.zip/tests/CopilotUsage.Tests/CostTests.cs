using CopilotUsage.Analysis;
using CopilotUsage.Model;
using CopilotUsage.Pricing;
using CopilotUsage.Storage;

namespace CopilotUsage.Tests;

/// <summary>Credits per call (FR-06) and context growth (FR-08) on hand-built sessions.</summary>
public static class CostTests
{
    static readonly DateTimeOffset T0 = DateTimeOffset.Parse("2026-11-07T10:00:00Z");

    static SessionData Session(params ModelCall[] calls)
    {
        var d = new SessionData { Session = new CliSession("s", "s", null, null, null, false, DateTime.UtcNow) };
        d.Calls.AddRange(calls);
        new CostEngine(PricingTable.Load()).Apply(d);
        return d;
    }

    static ModelCall Call(string model, long input, long cached, long output, long? nano = null, int second = 0) => new()
    {
        Model = model, Input = input, CacheRead = cached, Output = output, NanoAiu = nano,
        Start = T0.AddSeconds(second), End = T0.AddSeconds(second + 1),
    };

    static void Near(double expected, double actual, string what) =>
        Assert.True(Math.Abs(expected - actual) < 1e-9, $"{what}: expected {expected}, got {actual}");

    public static void Estimate_UsesTheTierOfTheCallsOwnInput()
    {
        // (60,000 × $2.00 + 40,000 × $0.10 + 1,000 × $10.00) / 1M = $0.134 = 13.4 credits
        var c = Session(Call("gpt-6.1-sol", 100_000, 40_000, 1_000)).Calls[0];
        Assert.Equal(CostSource.Estimated, c.Cost.Source);
        Near(13.4, c.Cost.Credits, "credits");
        Near(12.0, c.Cost.Split.FreshInput, "fresh input part");
        Near(0.4, c.Cost.Split.CacheRead, "cached part");
        Near(1.0, c.Cost.Split.Output, "output part");
        Assert.True(!c.Cost.LongContext, "under 272K");
    }

    public static void Estimate_LongContextPremiumIsLongTierMinusDefaultTier()
    {
        // 300,000 fresh input: $4.00/M → 120 credits; at the default tier $2.00/M → 60 credits.
        var c = Session(Call("gpt-6.1-sol", 300_000, 0, 0)).Calls[0];
        Assert.True(c.Cost.LongContext, "over 272K");
        Near(120, c.Cost.Credits, "credits at the long tier");
        Near(60, c.Cost.LongContextPremium ?? -1, "premium");
    }

    public static void Billed_WinsAndIsSplitByTheEstimate()
    {
        var c = Session(Call("gpt-6.1-sol", 100_000, 40_000, 1_000, nano: 20_000_000_000)).Calls[0];
        Assert.Equal(CostSource.Billed, c.Cost.Source);
        Near(20, c.Cost.Credits, "billed credits");
        Near(20, c.Cost.Split.Total, "split adds up to the billed credits");
        Near(20 * 12.0 / 13.4, c.Cost.Split.FreshInput, "split in the estimate's proportions");
    }

    public static void Billed_ZeroIsBilledNotEstimated()
    {
        var c = Session(Call("gpt-6.1-sol", 1_000, 0, 10, nano: 0)).Calls[0];
        Assert.Equal(CostSource.Billed, c.Cost.Source);
        Near(0, c.Cost.Credits, "zero credits");
    }

    public static void Billed_UsesCopilotsBillingDetailsForTheSplit()
    {
        var call = Call("gpt-6-luna", 27_650, 0, 302, nano: 360_717_500);
        call.CacheWrite = 27_647;
        call.BilledSplitNano = new CostSplit(30_000, 0, 345_587_500, 15_100_000);
        var c = Session(call).Calls[0];
        Assert.Equal("billing details", c.Cost.RateSource);
        Near(0.3607175, c.Cost.Credits, "credits");
        Near(0.3607175, c.Cost.Split.Total, "split total");
        Assert.True(c.Cost.Split.CacheWrite > c.Cost.Split.Output, "cache write is the largest part");
    }

    public static void Estimate_UsesTheCacheWritePrice()
    {
        // gpt-6-luna: 0.10 input, 0.125 cache write USD per 1M = 10 and 12.5 credits per 1M.
        var call = Call("gpt-6-luna", 200_000, 0, 0);
        call.CacheWrite = 200_000;
        var c = Session(call).Calls[0];
        Assert.Equal(CostSource.Estimated, c.Cost.Source);
        Near(2.5, c.Cost.Split.CacheWrite, "200K cache-write tokens at 12.5 credits per 1M");
        Near(0, c.Cost.Split.FreshInput, "all input was a cache write");
    }

    public static void SinglePriceModel_HasNoLongContext()
    {
        var c = Session(Call("mai-code-1.1-flash", 300_000, 0, 10, nano: 1_000_000_000)).Calls[0];
        Assert.True(!c.Cost.LongContext, "one price tier: no surcharge above 272K");
        Assert.Equal(null, c.Cost.LongContextThreshold);
        var luna = Session(Call("gpt-5.6-luna", 210_000, 0, 10)).Calls[0];
        Assert.True(luna.Cost.LongContext, "gpt-5.6-luna switches tier at 200K");
        Assert.Equal(200_000L, luna.Cost.LongContextThreshold);
    }

    public static void ObservedRates_EstimateModelsMissingFromPricing()
    {
        // One billed call teaches the rates (10 credits per 1M fresh input, 50 per 1M output); the next has no nanoAIU.
        // The teaching call stays under 272K: only default-tier calls teach rates.
        var teach = Call("unlisted-model", 200_000, 0, 100_000, nano: 7_000_000_000);
        teach.BilledSplitNano = new CostSplit(2_000_000_000, 0, 0, 5_000_000_000);
        var unbilled = Call("unlisted-model", 2_000_000 / 10, 0, 10_000, second: 5);
        var d = Session(teach, unbilled);
        var c = d.Calls[1];
        Assert.Equal(CostSource.Estimated, c.Cost.Source);
        Assert.Equal("observed rates", c.Cost.RateSource);
        Near(2.0 + 0.5, c.Cost.Credits, "200K × 10/M + 10K × 50/M");
    }

    public static void Utility_UnpricedAndFailedCalls()
    {
        var failed = Call("gpt-6.1-sol", 0, 0, 0);
        failed.Failed = true;
        var d = Session(Call("gpt-4o-mini", 5_000, 0, 50), Call("mystery-model", 5_000, 0, 50), failed);
        Assert.Equal(CostSource.Utility, d.Calls[0].Cost.Source);
        Assert.Equal(CostSource.Unpriced, d.Calls[1].Cost.Source);
        Assert.Equal(CostSource.Failed, d.Calls[2].Cost.Source);
        Near(0, d.TotalCredits, "none of them is priced");
        Assert.Equal("mystery-model", d.Diagnostics.UnpricedModels.Single());
    }

    public static void Growth_SharesDeltasAmongToolsBetweenCalls()
    {
        var d = new SessionData { Session = new CliSession("s", "s", null, null, null, false, DateTime.UtcNow) };
        long[] inputs = [10_000, 15_000, 18_000, 8_000];
        for (int i = 0; i < inputs.Length; i++)
            d.Calls.Add(new ModelCall { Input = inputs[i], Start = T0.AddSeconds(i * 10), End = T0.AddSeconds(i * 10 + 2), Model = "gpt-6.1-sol" });
        // Two tools between call 1 and 2 share +5,000; none between 2 and 3 (+3,000 → model turn); 3 → 4 drops (reset).
        d.Tools.Add(new ToolCall { Name = "read_file", Start = T0.AddSeconds(3), End = T0.AddSeconds(4), ResultTokens = 2_400 });
        d.Tools.Add(new ToolCall { Name = "rg", Start = T0.AddSeconds(5), End = T0.AddSeconds(6) });
        var g = ContextGrowth.Analyze(d);
        Near(2_500, g.Tools.Single(t => t.Tool == "read_file").InferredGrowth, "read_file share");
        Near(2_500, g.Tools.Single(t => t.Tool == "rg").InferredGrowth, "rg share");
        Assert.Equal(2_400L, g.Tools.Single(t => t.Tool == "read_file").MeasuredTokens, "measured size kept beside the inferred growth");
        Near(3_000, g.ModelTurnGrowth, "growth with no tool call");
        Assert.Equal(1, g.Resets, "drop counted as a reset");
        Assert.Equal(10_000L, g.FixedOverhead.Single().FirstCallInput, "first call = fixed overhead");
    }
}
