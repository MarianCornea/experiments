using CopilotUsage.Analysis;
using CopilotUsage.Logs;
using CopilotUsage.Model;
using CopilotUsage.Pricing;
using CopilotUsage.Report;
using CopilotUsage.Storage;

namespace CopilotUsage.Tests;

/// <summary>VS Code chat transcripts (chatSessions/*.jsonl): the Local harness source when a debug log has no calls.</summary>
public static class TranscriptTests
{
    const string TranscriptSessionId = "55555555-5555-4555-8555-555555555555";
    const string EmptyLogSessionId = "77777777-7777-4777-8777-777777777777";
    static readonly DateTimeOffset T0 = DateTimeOffset.FromUnixTimeMilliseconds(1794045600000);

    static List<ChatSession> Local()
    {
        var roots = StorageRoots.Find(Fixtures.UserDir);
        return TranscriptCatalog.Merge(SessionCatalog.FindAll(roots), TranscriptCatalog.FindAll(roots));
    }

    static TranscriptSession Fixture() => (TranscriptSession)Local().Single(s => s.Id == TranscriptSessionId);

    static void Near(double expected, double actual, string what) =>
        Assert.True(Math.Abs(expected - actual) < 1e-9, $"{what}: expected {expected}, got {actual}");

    public static void Replay_AppliesEveryOperationKind()
    {
        var r = ChatTranscript.Replay(Fixture().File);
        Assert.True(r.StartsWithState, "starts with the full state");
        Assert.Equal("Transcript fixture", ChatTranscript.Str(r.State, "customTitle"), "kind 1 sets a value");
        var requests = ChatTranscript.Arr(r.State, "requests")!;
        Assert.Equal(2, requests.Count, "kind 2 appends");
        Assert.Equal(0.65, ChatTranscript.Num(requests[1], "copilotCredits"), "a later kind 1 replaces the value");
        var tools = ChatTranscript.Arr(requests[1], "response")!.Select(p => ChatTranscript.Str(p, "toolId")).ToList();
        Assert.Equal("runSubagent,copilot_readFile,copilot_createFile", string.Join(",", tools), "kind 2 with i truncates, then appends");
        Assert.True(r.State!["inputState"] is null, "kind 3 deletes");
        Assert.Equal(1, r.BadLines, "a bad line is skipped and counted");
        Assert.Contains("kind 9", string.Join(",", r.UnknownOperations), "unknown kinds are counted");
    }

    public static void Parse_GivesBilledRecordsPerRequestAndSubagent()
    {
        var d = SessionLoader.Load(Fixture(), PricingTable.Load(), tool: new ToolData(Fixtures.EmptyDir(), Fixtures.EmptyDir()));
        Assert.True(d.PerRequest, "per-request data");
        Assert.Equal("Transcript fixture", d.Title);
        Near(0.90, d.TotalCredits, "0.25 + 0.65");
        Near(0.90, d.BilledCredits, "all billed");
        Assert.Equal(3, d.Calls.Count, "request 1, the Explore run, request 2");

        var explore = d.Calls.Single(c => c.Agent == "Explore");
        Near(0.4, explore.Cost.Credits, "sub-agent credits");
        Assert.Equal(T0.AddSeconds(62), explore.Start, "starts at the model call that asked for it");
        Assert.Equal(T0.AddSeconds(80), explore.End, "ends at the next main-agent call");
        Near(0.25, d.Calls.Last(c => c.Agent == AgentRun.MainName).Cost.Credits, "request 2 main agent = 0.65 − 0.4");

        var first = d.Calls[0];
        Assert.Equal("gpt-6-luna", first.Model, "resolved model, not copilot/auto");
        Assert.Equal(6000L, first.Input, "last call's prompt");
        Assert.Equal(2, first.Rounds, "two model calls in request 1");
        Assert.Equal("review-reqs", first.Skill, "slash command");
        Assert.Equal("5+", d.ModelCallCountText, "2 + 3 main-agent calls, sub-agent calls unknown");
        Near(0.90, d.Calls.Sum(c => c.Cost.Split.Unsplit), "billed credits are not split by cause");
        Assert.Equal(0.0, d.Calls.Sum(c => c.Cost.Split.Output + c.Cost.Split.FreshInput), "no estimated split");

        Assert.Equal(4, d.Tools.Count, "readFile; runSubagent, readFile (Explore), createFile");
        Assert.Equal("Explore", d.Tools.Single(t => t.Agent == "Explore").Agent);
        Assert.Equal(1, d.Diagnostics.Files.Single().BadLines);
    }

    public static void Catalog_UsesTranscriptsOnlyWhereDebugLogsHaveNoCalls()
    {
        var local = Local();
        Assert.True(local.Single(s => s.Id == Fixtures.WorkspaceSession) is DebugLogSession, "a debug log with calls wins over its transcript");
        var t = local.Single(s => s.Id == TranscriptSessionId);
        Assert.True(t is TranscriptSession, "a transcript without a debug log is listed");
        Assert.Equal(@"C:\work\pil-harness", t.WorkspaceFolder, "workspace folder from workspace.json");
        var empty = local.Single(s => s.Id == EmptyLogSessionId);
        Assert.True(empty is TranscriptSession, "an empty debug log is replaced by the transcript");
        Assert.True(empty.WorkspaceFolder is null, "empty-window chat");
        Assert.True(local.Single(s => s.Id == Fixtures.GlobalSession) is DebugLogSession, "a debug log without a transcript stays");
        Assert.True(local.All(s => !s.Id.StartsWith("66666666")), "older .json transcripts carry no usage and are skipped");
        Assert.Equal("Local harness (chat transcript)", t.SourceLabel);
    }

    public static void List_ShowsTranscriptCreditsAndKeepsDebugLogTotals()
    {
        var stdout = new StringWriter();
        Assert.Equal(0, Program.Run(["list", "--root", Fixtures.UserDir], stdout, new StringWriter()));
        var lines = stdout.ToString().Split('\n');
        var row = lines.Single(l => l.Contains("Transcript fixture"));
        Assert.Contains("Local", row);
        Assert.Contains("5+", row, "model calls");
        Assert.Contains("0.90", row, "billed credits");
        Assert.True(lines.Any(l => l.Contains("Empty window chat") && l.Contains("0.05")), "empty-window transcript");
        Assert.DoesNotContain("9.99", stdout.ToString(), "the debug log, not the transcript, prices session 1111");
    }

    public static void Report_SaysWhatIsMissingAndHoldsNoContent()
    {
        var d = SessionLoader.Load(Fixture(), PricingTable.Load(), tool: new ToolData(Fixtures.EmptyDir(), Fixtures.EmptyDir()));
        var html = HtmlReport.Build(d, PricingTable.Load());
        Assert.Contains("Local harness (chat transcript)", html);
        Assert.Contains("chat transcript: credits are billed per request", html, "finding explains the data");
        Assert.Contains("Not available for this chat", html, "context-per-call note");
        Assert.Contains("not recorded", html, "cache tiles");
        Assert.DoesNotContain("SECRET", html, "no prompt, tool argument or result text");
        Assert.DoesNotContain("was the largest cost", html, "no cause finding without a split");
    }

    public static void Probe_TranscriptPassesTheGateAndWarnsAboutBadLines()
    {
        var file = Path.Combine(Fixtures.EmptyDir(), "fp.json");
        var stdout = new StringWriter();
        int exit = Program.Run(["probe", "5555", "--root", Fixtures.UserDir, "--out", file], stdout, new StringWriter());
        var o = stdout.ToString();
        Assert.Equal(0, exit, "gate passes: " + o);
        Assert.Contains("Local harness (chat transcript)", o);
        Assert.Contains("PASS  P3", o, "billed credits on every completed request");
        Assert.Contains("PASS  P7", o, "sub-agent credits fit");
        Assert.Contains("WARN  P8", o, "bad line and unknown kind");
        var fingerprint = File.ReadAllText(file);
        Assert.DoesNotContain("SECRET", fingerprint, "structure only");
        Assert.Contains("\"Explore\"", fingerprint, "sub-agent names are kept");
    }

    public static void Compare_WarnsThatTranscriptDataHasNoTokens()
    {
        var file = Path.Combine(Fixtures.EmptyDir(), "c.html");
        var stdout = new StringWriter();
        int exit = Program.Run(["compare", "1111", "5555", "--root", Fixtures.UserDir, "--out", file], stdout, new StringWriter());
        Assert.Equal(0, exit);
        Assert.Contains("comes from a chat transcript", File.ReadAllText(file));
    }

    public static void Engine_NeverEstimatesATranscriptRecord()
    {
        var d = new SessionData { Session = Fixture(), PerRequest = true };
        d.Calls.Add(new ModelCall { Model = "gpt-6-luna", Input = 50_000, Output = 1_000, Rounds = 3, Start = T0, End = T0 });
        new CostEngine(PricingTable.Load()).Apply(d);
        Assert.Equal(CostSource.Unpriced, d.Calls[0].Cost.Source, "tokens of the last call would undercount");
        Assert.Equal(0, d.Diagnostics.UnpricedModels.Count, "the model is known; the record just has no credits");
    }
}
