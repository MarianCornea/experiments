using CopilotUsage.Sqlite;

namespace CopilotUsage.Tests;

public static class SqliteTests
{
    static string StateDb => Path.Combine(Fixtures.UserDir, "workspaceStorage", "a1b2c3d4e5f60718293a4b5c6d7e8f90", "state.vscdb");

    public static void ReadsAllRowsAcrossInteriorPages()
    {
        var db = SqliteFile.Open(StateDb);
        var root = db.FindTable("ItemTable") ?? throw new AssertException("ItemTable missing");
        var keys = db.ReadTable(root).Select(r => (string)r[0]!).ToList();
        Assert.Equal(302, keys.Count, "row count (300 + big + index)");
        Assert.True(keys.Contains("fixture.key.000") && keys.Contains("fixture.key.299"), "first and last rows");
    }

    public static void ReadsOverflowValues()
    {
        var value = StateDb_Get("fixture.big");
        Assert.Equal(20_000, value?.Length, "overflowed value length");
        Assert.Equal(string.Concat(Enumerable.Repeat("abcdefghij", 2000)), value, "overflowed value content");
    }

    public static void ReadsChatSessionIndex()
    {
        var index = StateDb_Get(Sqlite.StateDb.SessionIndexKey);
        Assert.Contains("Generate PIL harness", index ?? "", "index");
    }

    public static void MissingKeyIsNull() => Assert.True(StateDb_Get("no.such.key") is null, "missing key");

    public static void AppliesCommittedWalFrames()
    {
        var db = SqliteFile.Open(Path.Combine(Fixtures.Root, "sqlite", "live.db"));
        Assert.True(db.WalFramesApplied > 0, "WAL frames applied");
        Assert.Equal("new", Sqlite.StateDb.GetItem(db, "state"), "value updated in the WAL");
        Assert.Equal("yes", Sqlite.StateDb.GetItem(db, "only-in-wal"), "row only in the WAL");
    }

    public static void RejectsNonSqliteFiles()
    {
        var file = Path.Combine(Fixtures.EmptyDir(), "x.vscdb");
        File.WriteAllText(file, new string('x', 200));
        Assert.Throws<InvalidDataException>(() => SqliteFile.Open(file));
    }

    static string? StateDb_Get(string key) => Sqlite.StateDb.GetItem(SqliteFile.Open(StateDb), key);
}
