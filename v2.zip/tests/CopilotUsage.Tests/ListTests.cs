namespace CopilotUsage.Tests;

/// <summary>copilot-usage list on the fixtures (FR-03).</summary>
public static class ListTests
{
    static string Run(params string[] extra)
    {
        var stdout = new StringWriter();
        var stderr = new StringWriter();
        string[] args = ["list", "--root", Fixtures.UserDir, "--cli-root", Path.Combine(Fixtures.Root, "copilot"), .. extra];
        int exit = Program.Run(args, stdout, stderr);
        Assert.Equal(ExitCodes.Ok, exit, "exit code; stderr: " + stderr);
        return stdout.ToString();
    }

    public static void ShowsBothHarnessesAndHidesEmptySessions()
    {
        var output = Run();
        Assert.Contains("Generate PIL harness", output, "Local harness session with its state.vscdb title");
        Assert.Contains("Requirements pass", output, "Copilot harness session with its workspace.yaml name");
        Assert.Contains("Local", output);
        Assert.Contains("Copilot", output);
        Assert.Contains("1 sessions without model calls hidden", output);
        Assert.DoesNotContain("SECRET", output, "no content in the listing");
    }

    public static void IncludeEmptyShowsSessionsWithoutCalls()
    {
        var output = Run("--include-empty");
        Assert.Contains(Fixtures.GlobalSession, output, "session without a title is listed by ID");
        Assert.DoesNotContain("hidden", output);
    }

    public static void ShowsCallsAndBilledCredits()
    {
        var line = Run().Split('\n').Single(l => l.Contains("Generate PIL harness"));
        Assert.Contains("    5 ", line, "successful calls");
        Assert.Contains("0.30 ", line, "billed credits, no estimate marker");
    }

    public static void FolderFilterAndLimit()
    {
        Assert.Contains("No sessions match.", Run("--folder", "no-such-folder"));
        var limited = Run("--limit", "1").Split('\n', StringSplitOptions.RemoveEmptyEntries);
        Assert.Equal(2, limited.Count(l => !l.Contains("hidden")), "header + 1 row");
    }
}
