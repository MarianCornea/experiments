using CopilotUsage.Analysis;
using CopilotUsage.Model;
using CopilotUsage.Pricing;
using CopilotUsage.Storage;

namespace CopilotUsage.Tests;

/// <summary>Both parsers on the sanitized fixtures (FR-05) and the attribution on top of them (FR-07).</summary>
public static class ParserTests
{
    static SessionData CliFixture() =>
        SessionLoader.Load(CliSessionCatalog.FindAll(Path.Combine(Fixtures.Root, "copilot")).Single(), PricingTable.Load());

    static SessionData DebugFixture() =>
        SessionLoader.Load(SessionCatalog.FindAll(StorageRoots.Find(Fixtures.UserDir)).Single(s => s.Id == Fixtures.WorkspaceSession), PricingTable.Load());

    public static void Cli_ReadsCallsWithStartFromDuration()
    {
        var d = CliFixture();
        Assert.Equal(2, d.Calls.Count, "calls");
        var first = d.Calls[0];
        Assert.Equal(DateTimeOffset.Parse("2026-11-07T13:00:05Z"), first.End, "end = record timestamp");
        Assert.Equal(DateTimeOffset.Parse("2026-11-07T13:00:01Z"), first.Start, "start = end - duration");
        Assert.Equal((52000L, 40000L, 12000L, 800L), (first.Input, first.CacheRead, first.CacheWrite, first.Output), "tokens");
        Assert.Equal(0L, first.FreshInput, "fresh = input - cache read - cache write");
        Assert.Equal("1.0.103", d.CopilotVersion);
        Assert.Equal("Requirements pass", d.Title);
    }

    public static void Cli_AttributesCallsAndToolsToAgentRuns()
    {
        var d = CliFixture();
        Assert.Equal("main", d.Calls[0].Agent);
        Assert.Equal("explore", d.Calls[1].Agent, "sub-agent call");
        Assert.Equal("55555555-5555-4555-8555-555555555555", d.Calls[1].AgentRunId);
        var run = d.Runs["55555555-5555-4555-8555-555555555555"];
        Assert.Equal(DateTimeOffset.Parse("2026-11-07T13:00:07.100Z"), run.Start, "run start from subagent.started");
        Assert.Equal(DateTimeOffset.Parse("2026-11-07T13:00:20.100Z"), run.End, "run end from subagent.completed");
        Assert.Equal("powershell|task", string.Join("|", d.Tools.Select(t => t.Name)), "tools");
        Assert.Equal(120L, d.Tools[0].ResultTokens, "measured result size");
        Assert.Equal(224_000_000L, d.CheckpointNanoAiu, "checkpoint total");
        Assert.Equal(1, d.Diagnostics.BadLines, "bad line skipped");
    }

    public static void Cli_AssignsActiveSkillFromSlashCommand() =>
        Assert.True(CliFixture().Calls.All(c => c.Skill == "review-reqs"), "every call after /review-reqs carries the skill");

    public static void Debug_ReadsMainAndChildLogs()
    {
        var d = DebugFixture();
        Assert.Equal(6, d.Calls.Count, "4 in main.jsonl + 2 in the sub-agent log");
        Assert.Equal(1, d.Diagnostics.FailedRequests, "failed request counted");
        Assert.Equal(2, d.Calls.Count(c => c.Agent == "Reqs"), "sub-agent calls named from child_session_ref");
        Assert.Equal(CallKind.Title, d.Calls.Single(c => c.Model == "gpt-4o-mini").Kind, "title call");
        var run = d.Runs["22222222-2222-4222-8222-222222222222"];
        Assert.Equal(DateTimeOffset.FromUnixTimeMilliseconds(1794040017150), run.Start, "run start from the subagent span");
        Assert.Equal(DateTimeOffset.FromUnixTimeMilliseconds(1794040036950), run.End, "run end = start + dur");
        Assert.Equal(4, d.Tools.Count, "tools from both files");
        Assert.Equal("Generate PIL harness", d.Title, "title from state.vscdb");
        Assert.Equal(1, d.Diagnostics.BadLines, "bad line skipped");
        Assert.True(d.SuccessfulCalls.All(c => c.Skill == "generate-harness"), "skill from the slash command");
    }

    public static void Debug_BilledCreditsComeFromNanoAiu()
    {
        var d = DebugFixture();
        // 34M + 41M + 0 (title) + 32M + 190M nanoAIU; the failed call is not priced.
        Assert.Equal(0.297, Math.Round(d.TotalCredits, 6), "total credits");
        Assert.True(d.Calls.Where(c => !c.Failed).All(c => c.Cost.Source == CostSource.Billed), "all billed");
        Assert.Equal(CostSource.Failed, d.Calls.Single(c => c.Failed).Cost.Source);
        Assert.True(d.Calls.Single(c => c.Input == 290_000).Cost.LongContext, "long-context call flagged");
    }

    public static void Breakdown_SharesSumToOneAndSortByCredits()
    {
        var d = DebugFixture();
        foreach (var dim in Enum.GetValues<Dimension>())
        {
            var rows = Breakdown.By(d, dim);
            Assert.Equal(1.0, Math.Round(rows.Sum(r => r.Share), 9), $"shares by {dim}");
            Assert.Equal(d.SuccessfulCalls.Count(), rows.Sum(r => r.Calls), $"calls by {dim}");
            for (int i = 1; i < rows.Count; i++) Assert.True(rows[i - 1].Credits >= rows[i].Credits, $"sorted by {dim}");
        }
        var agents = Breakdown.By(d, Dimension.Agent);
        Assert.Equal("Reqs", agents[0].Key, "the sub-agent cost the most");
        Assert.Equal(Breakdown.NoPhase, Breakdown.By(d, Dimension.Phase).Single().Key, "no phases before M2");
    }

    public static void Performance_TwoThousandCallsUnderFiveSeconds()
    {
        // NFR-06: a 2,000-call session must be parsed, priced and attributed well within 5 seconds.
        var dir = Path.Combine(Fixtures.EmptyDir(), "session-state", "66666666-6666-4666-8666-666666666666");
        Directory.CreateDirectory(dir);
        var t0 = DateTimeOffset.Parse("2026-11-07T08:00:00Z");
        var lines = new List<string>();
        for (int i = 0; i < 2000; i++)
        {
            var at = t0.AddSeconds(i * 10);
            string agent = i % 4 == 0 ? "" : $",\"agentId\":\"agent-{i % 3}\"";
            lines.Add("{\"type\":\"session.usage_record\",\"data\":{\"usage\":{\"model\":\"gpt-6.1-sol\"," +
                      $"\"inputTokens\":{20_000 + i * 50},\"outputTokens\":300,\"cacheReadTokens\":{15_000 + i * 40},\"cacheWriteTokens\":100," +
                      $"\"duration\":2000,\"copilotUsage\":{{\"totalNanoAiu\":{40_000_000 + i},\"tokenDetails\":[]}}}}}}," +
                      $"\"id\":\"u{i}\",\"timestamp\":\"{at:O}\"{agent}}}");
            for (int k = 0; k < 2; k++)
                lines.Add($"{{\"type\":\"tool.execution_start\",\"data\":{{\"toolCallId\":\"t{i}-{k}\",\"toolName\":\"view\"}}," +
                          $"\"id\":\"s{i}{k}\",\"timestamp\":\"{at.AddSeconds(1 + k):O}\"{agent}}}");
        }
        File.WriteAllLines(Path.Combine(dir, "events.jsonl"), lines);

        var clock = System.Diagnostics.Stopwatch.StartNew();
        var d = SessionLoader.Load(CliSessionCatalog.FromDir(dir), PricingTable.Load());
        foreach (var dim in Enum.GetValues<Dimension>()) Breakdown.By(d, dim);
        ContextGrowth.Analyze(d);
        clock.Stop();
        Assert.Equal(2000, d.Calls.Count, "calls");
        Assert.True(clock.Elapsed.TotalSeconds < 5, $"took {clock.Elapsed.TotalSeconds:N2} s");
        Console.WriteLine($"        (2,000 calls in {clock.Elapsed.TotalMilliseconds:N0} ms)");
    }

    public static void Breakdown_NumbersRepeatedRunsOfOneAgent()
    {
        var d = new SessionData { Session = new CliSession("x", "x", null, null, null, false, DateTime.UtcNow) };
        var t0 = DateTimeOffset.Parse("2026-11-07T10:00:00Z");
        d.Runs["a"] = new AgentRun { Id = "a", Name = "explore", Start = t0 };
        d.Runs["b"] = new AgentRun { Id = "b", Name = "explore", Start = t0.AddMinutes(5) };
        Assert.Contains("explore #1", Breakdown.RunLabel(d, d.Runs["a"]));
        Assert.Contains("explore #2", Breakdown.RunLabel(d, d.Runs["b"]));
    }
}
