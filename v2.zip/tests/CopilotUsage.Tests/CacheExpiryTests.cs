using CopilotUsage.Analysis;
using CopilotUsage.Model;
using CopilotUsage.Pricing;
using CopilotUsage.Report;
using CopilotUsage.Storage;

namespace CopilotUsage.Tests;

/// <summary>Calls that lost the prompt cache after a pause longer than its lifetime.</summary>
public static class CacheExpiryTests
{
    static readonly DateTimeOffset T0 = DateTimeOffset.Parse("2026-11-09T10:00:00Z");

    /// <summary>Main-agent gpt-6-luna calls: (minutes after T0, input, cache read, cache write).</summary>
    static SessionData Session(int? ttl, params (int Minute, long Input, long Read, long Write)[] calls)
    {
        var d = new SessionData { Session = CliSessionCatalog.FindAll(Path.Combine(Fixtures.Root, "copilot")).Single() };
        foreach (var (m, input, read, write) in calls)
            d.Calls.Add(new ModelCall { Model = "gpt-6-luna", Input = input, CacheRead = read, CacheWrite = write, Output = 100, NanoAiu = 1_000_000,
                                        CacheTtlSeconds = ttl, Start = T0.AddMinutes(m), End = T0.AddMinutes(m).AddSeconds(5) });
        d.Finish();
        new CostEngine(PricingTable.Load()).Apply(d);
        return d;
    }

    static SessionData Expired() => Session(1800, (0, 100_000, 0, 100_000), (5, 100_000, 99_000, 1_000), (45, 102_000, 0, 102_000));

    public static void Parser_RecordsTheCacheLifetime() =>
        Assert.Equal(1800, CliSessionCatalog.FindAll(Path.Combine(Fixtures.Root, "copilot")).Select(s => Logs.CliSessionParser.Parse(s)).Single()
            .Calls.First().CacheTtlSeconds, "usage.cacheTtlSeconds");

    public static void Find_FlagsAPausePastTheLifetimeThatLostTheCache()
    {
        var row = CacheExpiry.Find(Expired(), PricingTable.Load()).Single();
        Assert.Equal(3, row.CallIndex);
        Assert.Equal(40.0, row.PauseMinutes, "counted from the previous call's start");
        Assert.Equal(30, row.TtlMinutes);
        Assert.Equal(100_000L, row.LostTokens, "what the previous call held");
        // gpt-6-luna: cache write 0.125, cache read 0.01 USD per 1M = 12.5 and 1 credits per 1M.
        Assert.True(Math.Abs(row.ExtraCredits!.Value - 1.15) < 1e-9, "100K × (12.5 − 1) / 1M: " + row.ExtraCredits);
    }

    public static void Find_IgnoresSurvivingCachesAndShortPauses()
    {
        var survived = Session(1800, (0, 100_000, 0, 100_000), (45, 101_000, 99_500, 1_500));
        Assert.Equal(0, CacheExpiry.Find(survived, PricingTable.Load()).Count, "a long pause, but the cache was read: not flagged");
        var shortPause = Session(1800, (0, 100_000, 0, 100_000), (10, 102_000, 0, 102_000));
        Assert.Equal(0, CacheExpiry.Find(shortPause, PricingTable.Load()).Count, "a drop within the lifetime has another cause");
        var assumed = CacheExpiry.Find(Session(null, (0, 100_000, 0, 100_000), (31, 100_000, 0, 100_000)), PricingTable.Load()).Single();
        Assert.True(assumed.TtlAssumed, "no logged lifetime: Copilot's usual 30 minutes");
    }

    public static void Report_ExplainsTheExpiry()
    {
        var d = Expired();
        var finding = Findings.For(d, ContextGrowth.Analyze(d), null, CacheExpiry.Find(d, PricingTable.Load())).Single(f => f.Text.Contains("pause"));
        Assert.Contains("After a 40-minute pause at", finding.Text);
        Assert.Contains("the main agent's cache had expired (Copilot keeps it 30 minutes after the last call)", finding.Text);
        Assert.Contains("about 1.15 credits more than reading them from the cache", finding.Text);
        var html = HtmlReport.Build(d, PricingTable.Load());
        Assert.Contains("<h3>Cache expiries</h3>", html);
        Assert.DoesNotContain("<h3>Cache expiries</h3>", HtmlReport.Build(Session(1800, (0, 100_000, 0, 100_000), (5, 100_000, 99_000, 1_000)), PricingTable.Load()),
            "no table without an expiry");
    }
}
