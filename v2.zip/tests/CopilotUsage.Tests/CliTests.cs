using CopilotUsage.Cli;
using CopilotUsage.Pricing;

namespace CopilotUsage.Tests;

public static class CliTests
{
    static (int Exit, string Out, string Err) Run(params string[] args)
    {
        var stdout = new StringWriter();
        var stderr = new StringWriter();
        int exit = Program.Run(args, stdout, stderr);
        return (exit, stdout.ToString(), stderr.ToString());
    }

    public static void Args_ParsesOptionsFlagsAndPositionals()
    {
        var a = CliArgs.Parse(["latest", "--out", "x.json", "--live", "--limit=5"], "live");
        Assert.Equal("latest", a.Positionals.Single());
        Assert.Equal("x.json", a.Get("out"));
        Assert.True(a.Has("live"), "flag");
        Assert.Equal(5, a.GetInt("limit"));
        a.RejectUnknown();
    }

    public static void CommandHelp_ShowsOnlyThatCommand()
    {
        var (exit, o, _) = Run("report", "--help");
        Assert.Equal(0, exit, "report --help");
        Assert.Contains("copilot-usage report [<session>]", o);
        Assert.Contains("<session> is a list index", o, "session note for commands that take one");
        Assert.DoesNotContain("copilot-usage compare", o, "other commands left out");

        Assert.Equal(Run("help", "report").Out, o, "help <command> is the same");
        var phase = Run("phase", "-h").Out;
        Assert.Contains("phase start", phase);
        Assert.Contains("phase end", phase);
        Assert.Contains("Exit codes", phase);
        Assert.DoesNotContain("hooks install", Run("hook", "--help").Out, "hook is not hooks");
        Assert.Contains("hooks remove", Run("hooks", "--help").Out);
        Assert.Contains("unknown command", Run("nope", "--help").Err);
        foreach (var c in new[] { "doctor", "probe", "list", "compare", "status" })
            Assert.Equal(0, Run(c, "--help").Exit, c + " --help");
    }

    public static void Args_RejectsUnknownOptionsAndMissingValues()
    {
        var a = CliArgs.Parse(["--colour", "red"]);
        Assert.Contains("--colour", Assert.Throws<CliException>(a.RejectUnknown).Message);
        Assert.Throws<CliException>(() => CliArgs.Parse(["--out"]));
    }

    public static void UnknownCommand_ExitsWithError()
    {
        var (exit, _, err) = Run("frobnicate");
        Assert.Equal(ExitCodes.Error, exit);
        Assert.Contains("unknown command", err);
    }

    public static void Compare_NeedsTwoSessions()
    {
        var (exit, _, err) = Run("compare", "1");
        Assert.Equal(ExitCodes.Error, exit);
        Assert.Contains("usage: copilot-usage compare", err);
    }

    public static void Doctor_ReportsFixtureRoot()
    {
        var (exit, output, _) = Run("doctor", "--root", Fixtures.UserDir);
        Assert.Equal(ExitCodes.Ok, exit);
        Assert.Contains("3 sessions with debug logs", output);
        Assert.Contains("copilot-usage probe latest", output);
    }

    public static void Probe_WritesFingerprintAndExitsZeroWhenGatePasses()
    {
        var outFile = Path.Combine(Fixtures.EmptyDir(), "fp.json");
        var (exit, output, err) = Run("probe", "1111", "--root", Fixtures.UserDir, "--out", outFile);
        Assert.Equal(ExitCodes.Ok, exit, "exit code; stderr: " + err);
        Assert.Contains("Gate G0 passed", output);
        Assert.Contains("\"fingerprintVersion\": 1", File.ReadAllText(outFile));
    }

    public static void Probe_ExitsOneWhenGateFails()
    {
        var outFile = Path.Combine(Fixtures.EmptyDir(), "fp.json");
        var (exit, output, _) = Run("probe", "3333", "--root", Fixtures.UserDir, "--out", outFile);
        Assert.Equal(ExitCodes.Error, exit);
        Assert.Contains("Gate G0 failed: P2, P3", output);
    }

    public static void Probe_UnknownSessionExitsThree() =>
        Assert.Equal(ExitCodes.SessionNotIdentified, Run("probe", "ffff", "--root", Fixtures.UserDir).Exit);

    public static void Pricing_MatchesIdsAliasesAndVariants()
    {
        var p = PricingTable.Load();
        Assert.Equal(PriceMatch.Priced, p.Match("gpt-6.1-sol").Kind, "id");
        Assert.Equal(PriceMatch.Priced, p.Match("GPT-6.1 Sol").Kind, "display name alias");
        Assert.Equal(PriceMatch.Priced, p.Match("copilot/gpt-6.1-sol-2026-09-01").Kind, "prefixed, dated variant");
        Assert.Equal(PriceMatch.Utility, p.Match("gpt-4o-mini").Kind, "utility model");
        Assert.Equal(PriceMatch.Unpriced, p.Match("mystery-model-1").Kind, "unknown model");
        Assert.Equal("claude-opus-5.5", p.Match("claude-opus-5.5").Price!.Id, "exact match beats the claude-opus-5 prefix");
        Assert.Equal("claude-opus-5.5", p.Match("claude-opus-5-5").Price!.Id, "dashed version alias");
        Assert.Equal("claude-opus-4.8-fast", p.Match("claude-opus-4.8-fast-preview").Price!.Id, "longest prefix wins");
        Assert.Equal(200_000L, p.Match("gpt-5.6-luna").Price!.LongContextThreshold, "per-model threshold");
        Assert.Equal(0.125m, p.Match("gpt-6-luna").Price!.Tiers[0].CacheWriteOrDefault, "listed cache-write price");
        Assert.Equal(0.75m * 1.25m, p.Match("gemini-3.8-flash").Price!.Tiers[0].CacheWriteOrDefault, "default: 1.25 x input");
        Assert.Equal(272_000L, p.Match("gpt-6.1-sol").Price!.LongContextThreshold, "long-context threshold");
    }
}
