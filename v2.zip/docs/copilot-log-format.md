# Copilot Chat debug-log format — verified notes

Read from the Copilot Chat extension's own source (`ChatDebugFileLogger` in the bundled
`resources/app/extensions/copilot/dist/extension.js`), versions 0.60.0, 0.68.0, 0.69.0 and 0.73.0 (identical writer), VS Code 1.132,
on 2026-11-07. This replaces the third-party description in the spec where they differ. Real logs
still have to be probed (gate G0); these notes say what the probe should expect.

## Switching it on

Debug logs are **off by default**. Setting: `github.copilot.chat.agentDebugLog.fileLogging.enabled`
(`true`, then reload the window). Related settings:

| Setting | Default | Effect on this tool |
| --- | --- | --- |
| `...fileLogging.flushIntervalMs` | 4000 | Write delay: a finished call reaches disk within ~4 s (probe P13) |
| `...fileLogging.maxRetainedSessionLogs` | 50 | Older session folders are **deleted** — report soon after a run |
| `...fileLogging.maxSessionLogSizeMB` | 100 | Over the limit the file is cut to its newest 60 % — early calls are lost |

## Location

`<storageUri>/debug-logs/<sessionId>/`, where `storageUri` is
`workspaceStorage/<hash>/GitHub.copilot-chat` for a window with a folder, else
`globalStorage/github.copilot-chat` (case differs; Windows is case-insensitive).

## Files in a session folder

| File | Content |
| --- | --- |
| `main.jsonl` | Events of the main session |
| `<label>-<childSessionId>.jsonl` | One per child session; `label` is e.g. `runSubagent-<Name>`, sanitized: `/\:*?"<>\|` and control chars → `_`, `..` → `_` |
| `system_prompt_<n>.json` | `{"content": "<system prompt>"}`, a new file when the prompt length or model changes |
| `tools_<n>.json` | `{"content": "<tool definitions>"}`, a new file when their length changes. The content is a JSON array of `{type: "function", name, description, parameters}` (built by `ABn` in extension.js from the request's tools; older builds may use the OpenAI shape `{type, function: {name, …}}`). Each `llm_request` names the file it carried in `attrs.toolsFile`. |
| `models.json` | Snapshot of available models |

## Event envelope

`{ v?, ts, dur, sid, type, name, spanId, parentSpanId?, status: "ok"|"error", attrs, rIdx? }` —
`ts` is epoch ms, `dur` ms, `rIdx` is set when a session was resumed (run index).

## Event types and attributes

| type | name | attrs |
| --- | --- | --- |
| `session_start` | `session_start` | `copilotVersion`, `vscodeVersion`, child only: `parentSessionId`, `label`; envelope has `v: 1` |
| `turn_start` / `turn_end` | `turn_start:<turnId>` | `turnId` |
| `user_message` | `user_message` | `content` (≤ 5,000 chars) — content, never kept |
| `agent_response` | `agent_response` | `response`, `reasoning` (≤ 5,000 chars) — content, never kept |
| `llm_request` | `chat:<model>` | `model`, `debugName`, `inputTokens`, `outputTokens`, `cachedTokens`, `ttft`, `responseId`, `userRequest`, `inputMessages`, `maxTokens`, `temperature`, `topP`, `requestOptions`, `requestShape`, `copilotUsageNanoAiu`, `error`, `systemPromptFile`, `toolsFile` |
| `tool_call` | tool name | `args`, `result` (each ≤ 5,000 chars), `error` |
| `subagent` | agent name | `agentName`, `description`, `error` — span of one sub-agent run (`ts`, `dur`) |
| `hook` | hook type | `command`, `input`, `output`, `resultKind`, `error` |
| `child_session_ref` | label | `childSessionId`, `childLogFile`, `label` |
| `discovery` / `generic` | event name | `details`, `category`, `source` |

Content-bearing attributes (`content`, `response`, `reasoning`, `userRequest`, `inputMessages`,
`args`, `result`, `details`, `description`, `command`, `input`, `output`, `error`) are reduced to
their length at parse time.

Differences from the spec's data-source table:

- `child_session_ref` carries `label` and `childLogFile`, not `childTitle`.
- `tool_call.attrs.result` is logged, but capped at 5,000 characters, so it measures small results
  only; large results still need PostToolUse hook sizes (P16).
- `subagent` events give each sub-agent run's start and duration without hooks.
- `hook` events show in the debug log when VS Code runs a hook (useful for P14).
- `system_prompt_*.json` and `tools_*.json` are referenced from each `llm_request`
  (`systemPromptFile`, `toolsFile`), so fixed overhead can be tied to calls.

## Chat transcripts (Local harness fallback, verified 2026-11-07 in VS Code 1.132 / Copilot Chat 0.73)

`workspaceStorage/<hash>/chatSessions/<sessionId>.jsonl` (and `globalStorage/emptyWindowChatSessions/`
for chats without a folder) is the file VS Code reloads a chat from. Always written, whatever the
debug-log setting. Older chats use `<sessionId>.json` (a plain snapshot, `version: 3`) with no usage
fields at all; the tool skips those.

**Operation log.** Each line is `{kind, k?, v?, i?}`: `0` = the whole state (first line), `1` = set the
value at path `k` (strings for keys, numbers for array indexes), `2` = append the items of `v` to the
array at `k`, first truncating it to `i` when `i` is given, `3` = delete the value at `k`. Values are
updated in place: a request's `copilotCredits` is appended early and set again when it completes, so
the file must be replayed (verified in the workbench's writer, `_diffObject`).

**Per request** (`requests[]`): `timestamp` (epoch ms), `modelId` (`copilot/auto` when Auto),
`promptTokens` (the *last* model call's prompt), `completionTokens` (summed over the request),
`copilotCredits` = Σ `copilot_usage.total_nano_aiu` / 1e9 over the request's model calls, **sub-agent runs
included** (billed: the extension accumulates it, the workbench adds sub-agent credits),
`promptTokenDetails[]` (category, label, percentageOfPrompt), `elapsedMs`, and `result`:
`timings.totalElapsed`, `metadata.resolvedModel`, `metadata.promptTokens/outputTokens` (last call),
`metadata.toolCallRounds[]` = one entry per main-agent model call (`id`, `modelId`, `timestamp`,
`thinking.tokens`, `toolCalls[]` with `id`, `name`, `arguments`). Agent-host chats can also carry
`modelTotals`, `latestModelCall`, `sessionCopilotCredits` (not seen yet in a Local chat).

**Response parts** (`response[]`): `kind` (`toolInvocationSerialized`, `thinking`, `autoModeResolution`
with `resolvedModel`, …). A tool part has `toolId` (e.g. `copilot_readFile`), `toolCallId`, and
`subAgentInvocationId` when a sub-agent ran it, equal to the `toolCallId` of the `runSubagent` part.
That part's `toolSpecificData` is `{kind: "subagent", agentName, modelName, credits, prompt, result, …}`;
`credits` is the run's billed total. Tool parts do not link to `toolCallRounds` (different IDs).

**Not recorded:** tokens per model call, cache reads and writes, the sub-agent's own model calls. So a
transcript gives billed credits per request and per sub-agent run, not the cause split or context growth.

**Seen on this machine:** two chats whose debug logs held only `session_start` (logging on) had
transcripts with 0.48 and 2.91 credits. The file holds full content; the parser keeps numbers and names only.

## Other local Copilot data (not used in v1)

- `globalStorage/github.copilot-chat/session-store.db` — SQLite (WAL), not yet examined.
- `state.vscdb` → `ItemTable` key `chat.ChatSessionStore.index`:
  `{version, entries: {<sessionId>: {sessionId, title, lastMessageDate, …}}}`.

## Agent host / Copilot CLI sessions (found 2026-11-07)

In VS Code 1.132 a chat can run in the **agent host** (log: `logs/<date>/agenthost.log`,
sessions `ahp-session:/...`), which uses the Copilot CLI engine. Those chats write **no** debug logs,
even with `agentDebugLog.fileLogging.enabled` on. They are stored by the Copilot CLI instead:

`~/.copilot/session-state/<sessionId>/events.jsonl` (plus `workspace.yaml`, `checkpoints/`, `files/`,
`inuse.*.lock` while active). One JSON event per line: `{type, id, parentId, timestamp, agentId?, data}`.

| type | Useful fields (structure seen, values not read) |
| --- | --- |
| `session.start` | `sessionId`, `copilotVersion`, `producer`, `selectedModel`, `context.cwd / gitRoot / repository / branch` |
| `session.usage_record` | `usage.model`, `inputTokens`, `outputTokens`, `cacheReadTokens`, **`cacheWriteTokens`**, `reasoningTokens`, `cost`, `copilotUsage.totalNanoAiu`, `copilotUsage.tokenDetails[]`, `duration`, `maxPromptTokens`, `toolTokenCount`, `numToolCalls`, `toolCounts`, `parentToolCallId`, `initiator`; envelope `agentId` |
| `assistant.turn_start` / `assistant.message` | `turnId`, `model`, `toolRequests[].name`, `parentToolCallId`, `agentId` |
| `tool.execution_start` / `tool.execution_complete` | `toolCallId`, `toolName`, `success`, `toolTelemetry.metrics.result_token_count`, `resultLength`, `context_current_tokens`, `context_token_limit` |
| `subagent.started` | `toolCallId`, `agentName`, `agentType`, `model`, `executionMode` |
| `hook.start` / `hook.end` | `hookType`, `input` (prompt, tool args and results: content), `success` |
| `session.auto_mode_resolved` | `chosenModel`, `candidateModels` |
| `user.message`, `system.message` | content — never kept |

This store has what the debug logs lack: cache-write tokens, a cost per call, and a measured
token count per tool result. Content-bearing fields (`content`, `arguments`, `result`, `input`,
`attachments`, `reasoning*`, `encryptedContent`) must be reduced to lengths like the debug logs.

### Billing details in `session.usage_record`

`usage.copilotUsage.tokenDetails[]` holds `{tokenType, tokenCount, batchSize, costPerBatch, model}` with
`tokenType` in `input`, `cache_read`, `cache_write`, `output`. `Σ tokenCount / batchSize × costPerBatch`
equals `totalNanoAiu` exactly (checked on 56 real calls). Here `input` counts only fresh tokens:
`inputTokens = input + cache_read + cache_write`. Observed for `gpt-6-luna`: cache write is billed at
1.25× fresh input, cache read at 0.1×. The record's `timestamp` is the end of the call; its start is
`timestamp − duration`.

## Hooks (both harnesses, verified in VS Code 1.132 / Copilot runtime 1.0.103 source, 2026-11-07)

**Files.** Repository: `.github/hooks/*.json`. User: `~/.copilot/hooks/*.json` (`COPILOT_HOME` moves `~/.copilot`).
VS Code (Local harness) reads the same folders, plus `.claude/settings*.json`.

**Format** (Copilot CLI style, read by the Copilot runtime and mapped by VS Code):

```json
{ "version": 1,
  "hooks": { "preToolUse": [ { "type": "command", "bash": "...", "powershell": "...", "timeoutSec": 5 } ] } }
```

An action may also use `command`, `windows`/`linux`/`osx`, `cwd`, `env`, `matcher`. Events (camelCase):
`sessionStart`, `sessionEnd`, `userPromptSubmitted`, `userPromptTransformed`, `preToolUse`, `postToolUse`,
`postToolUseFailure`, `subagentStart`, `subagentStop`, `agentStop`, `preCompact`, `errorOccurred`,
`permissionRequest`, `notification`. VS Code maps them to its names (`agentStop` → `Stop`, …).

**Input on stdin** (Copilot harness): `sessionId`, `timestamp` (ms), `cwd`, and per event `prompt`, `toolName`,
`toolArgs`, `toolResult.textResultForLlm`, `agentId`, `agentName`, `agentType`, `parentAgentId`, `stopReason`.
No event name is passed, so each action passes `--event`. VS Code's Local harness sends Claude-style
snake_case (`session_id`, `hook_event_name`, `tool_name`, `tool_input`, `tool_response`).

**Sub-agents.** Hooks fired inside a sub-agent carry the sub-agent's ID as `sessionId`. Only
`subagentStart` / `subagentStop` (fired in the parent, with `agentId`) link the two.

**Blocking a tool.** `preToolUse` prints `{"permissionDecision":"deny","permissionDecisionReason":"..."}` and
exits 0. The runtime is **fail-closed**: a hook that errors denies the tool; a timeout allows it.

**Ending a session (checked 2026-11-08).** VS Code's hook contract (`extensions/copilot/assets/prompts/skills/
agent-customization/references/hooks.md`) lists common output `continue`, `stopReason`, `systemMessage`;
`PreToolUse` reads `hookSpecificOutput.permissionDecision`; exit 2 is a blocking error. The Copilot runtime
(`@github/copilot/sdk/prebuilds/win32-x64/runtime.node`) parses hook output fields `modifiedPrompt`,
`suppressOutput`, `handled`, `responseContent`, `handledBy`, `hookSpecificOutput`, `permissionDecision`,
`permissionDecisionReason`, `modifiedArgs`, `updatedInput`, `modifiedResult` (and `behavior`, `interrupt` for
permission-request hooks); no `continue` or `stopReason`. So the hard budget sends both `continue: false` and a
deny: VS Code ends the session, the runtime most likely only denies each tool call. Probe P17 measures it.

**Output reservation (checked 2026-11-08).** Copilot keeps the model's `max_output_tokens` (128K for most
models) free inside the context window: debug-log `models.json` lists `capabilities.limits` with
`max_context_window_tokens`, `max_output_tokens` and `max_prompt_tokens` (e.g. gpt-6-luna 1,000,000 / 128,000 /
872,000; mai-code-1.1-flash 256,000 / 128,000 / 127,997). The Copilot harness logs the prompt cap per call as
`usage.maxPromptTokens` (272,000 for gpt-6-luna, 128,000 for mai-code-1.1-flash). VS Code's context bar draws
used = prompt + output and an "output buffer" segment = (max output − output so far) / window. Billing counts
only tokens produced: in 100 real calls the billed output and input token counts equal `outputTokens` and
`inputTokens` exactly. Transcripts carry `outputBuffer` (the reservation) per request.

**Cache lifetime (checked 2026-11-09).** Each `session.usage_record` carries `cacheTtlSeconds` (1800 on all
gpt-6-luna calls and most mai-code-1.1-flash calls), `cachePolicyTtlSeconds` (1800, gpt-6-luna) and
`cacheExpiresAt` = the call's start + 30 minutes exactly, so every call restarts the lifetime of its agent's
cache. mai-code-1.1-flash calls read from the cache but bill no cache writes and carry no `cacheExpiresAt`. The
longest pause in the real sessions was 16.5 minutes, and the next call still read 96% of its input from cache;
an expiry has not been observed yet.

**MCP tool names.** VS Code: `mcp_<prefix>_<tool>`, where the prefix is the server label lower-cased, characters
outside `[a-z0-9_.-]` replaced by `_`, cut to 13 characters, plus a number when two servers share it
(`MMi.take` in the workbench). The Copilot runtime: `<server>-<tool>` (e.g. `github-mcp-server-*`); its
session-state logs carry no tool definitions, only `usage.toolTokenCount` (all definitions, per call).

**Session ID in shells.** The runtime sets `COPILOT_AGENT_SESSION_ID` in its shell environment
(`shell_environment.rs`); the value inside a VS Code agent-host session is still unverified.

**Native workflows.** The runtime has its own workflow feature (`logPhaseNames`, limit `maxAiCredits`, a
soft post-paid credit ceiling per run); see the SDK `docs/workflows.md`.
