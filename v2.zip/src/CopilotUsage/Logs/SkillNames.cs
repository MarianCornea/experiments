using System.Text.RegularExpressions;

namespace CopilotUsage.Logs;

/// <summary>Finds the skill a message starts: a leading slash command such as "/generate-harness". Only the name is kept.</summary>
public static partial class SkillNames
{
    public static string? FromMessage(string? content)
    {
        if (content is null) return null;
        var m = SlashCommand().Match(content);
        return m.Success ? m.Groups[1].Value : null;
    }

    [GeneratedRegex(@"^\s*/([A-Za-z0-9][\w.\-]{0,63})(?=\s|$)")]
    private static partial Regex SlashCommand();
}
