using System.Text.Json;
using CopilotUsage.Storage;

namespace CopilotUsage.Logs;

/// <summary>
/// Reads a debug log's models.json (Copilot's model list): per model id, capabilities.limits.max_prompt_tokens, the
/// prompt size left after the output reservation (e.g. 1,000,000 window − 128,000 output = 872,000).
/// </summary>
public static class ModelLimits
{
    public static Dictionary<string, long> Read(string? file)
    {
        var limits = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);
        if (file is null || !File.Exists(file)) return limits;
        try
        {
            using var doc = JsonDocument.Parse(SafeFile.ReadAllText(file));
            var list = doc.RootElement.ValueKind == JsonValueKind.Array ? doc.RootElement
                : doc.RootElement.ValueKind == JsonValueKind.Object && doc.RootElement.TryGetProperty("data", out var d) ? d : default;
            if (list.ValueKind != JsonValueKind.Array) return limits;
            foreach (var m in list.EnumerateArray())
                if (Json.Str(m, "id") is { } id && Json.Long(Json.At(m, "capabilities.limits"), "max_prompt_tokens") is long max && max > 0)
                    limits[id] = max;
        }
        catch (Exception e) when (e is JsonException or IOException or UnauthorizedAccessException) { }
        return limits;
    }

    /// <summary>The limit for a model as the logs name it ("copilot/gpt-6-luna", "GPT-6 Luna").</summary>
    public static long? For(IReadOnlyDictionary<string, long> limits, string model)
    {
        if (limits.Count == 0) return null;
        var name = Pricing.PricingTable.Normalize(model);
        return limits.TryGetValue(name, out var v) ? v : limits.FirstOrDefault(kv => Pricing.PricingTable.Normalize(kv.Key) == name).Value is long w and > 0 ? w : null;
    }
}
