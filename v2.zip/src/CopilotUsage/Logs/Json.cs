using System.Globalization;
using System.Text.Json;

namespace CopilotUsage.Logs;

/// <summary>Small tolerant accessors: a missing or wrongly typed field is null, never an exception.</summary>
internal static class Json
{
    public static string? Str(JsonElement e, string name) =>
        e.ValueKind == JsonValueKind.Object && e.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;

    public static long? Long(JsonElement e, string name)
    {
        if (e.ValueKind != JsonValueKind.Object || !e.TryGetProperty(name, out var v) || v.ValueKind != JsonValueKind.Number) return null;
        return v.TryGetInt64(out var l) ? l : (long)Math.Round(v.GetDouble());
    }

    public static double? Double(JsonElement e, string name) =>
        e.ValueKind == JsonValueKind.Object && e.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.Number ? v.GetDouble() : null;

    public static bool Has(JsonElement e, string name) => e.ValueKind == JsonValueKind.Object && e.TryGetProperty(name, out _);

    public static JsonElement At(JsonElement e, string dotted)
    {
        foreach (var part in dotted.Split('.'))
            if (e.ValueKind != JsonValueKind.Object || !e.TryGetProperty(part, out e)) return default;
        return e;
    }

    public static DateTimeOffset? Time(JsonElement e, string name) =>
        Str(e, name) is { } s && DateTimeOffset.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var t) ? t : null;

    public static DateTimeOffset? EpochMs(JsonElement e, string name) =>
        Long(e, name) is long ms ? DateTimeOffset.FromUnixTimeMilliseconds(ms) : null;

    /// <summary>Parses one JSONL line; null for a bad line or a non-object.</summary>
    public static JsonDocument? ParseObject(string line)
    {
        try
        {
            var doc = JsonDocument.Parse(line);
            if (doc.RootElement.ValueKind == JsonValueKind.Object) return doc;
            doc.Dispose();
        }
        catch (JsonException) { }
        return null;
    }
}
