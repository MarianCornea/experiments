using System.Text.Json;
using CopilotUsage.Model;
using CopilotUsage.Storage;
using static CopilotUsage.Logs.Json;

namespace CopilotUsage.Logs;

/// <summary>Parses a Local harness session: main.jsonl plus every child log (sub-agents, title generation) (FR-05).</summary>
public static class DebugLogParser
{
    public static SessionData Parse(DebugLogSession session)
    {
        var data = new SessionData { Session = session };
        foreach (var artifact in SessionCatalog.SafeEnumerateFiles(session.Dir).Where(f => DebugLogFormat.Classify(Path.GetFileName(f)).Kind is LogFileKind.SystemPrompt or LogFileKind.Tools).Order())
        {
            data.PromptArtifacts.Add((Path.GetFileName(artifact), new FileInfo(artifact).Length));
            if (DebugLogFormat.Classify(Path.GetFileName(artifact)).Kind == LogFileKind.Tools && ToolDefinitions.Read(artifact) is { } defs)
                data.ToolDefinitions[Path.GetFileName(artifact)] = defs;
        }
        var files = SessionCatalog.SafeEnumerateFiles(session.Dir)
            .Where(f => f.EndsWith(".jsonl", StringComparison.OrdinalIgnoreCase))
            .OrderBy(f => Path.GetFileName(f).Equals("main.jsonl", StringComparison.OrdinalIgnoreCase) ? 0 : 1)
            .ThenBy(f => f, StringComparer.Ordinal)
            .ToList();

        // child_session_ref in main.jsonl names each child log; subagent spans give each run's timing.
        var childLabels = new Dictionary<string, (string Label, string? ParentSpan)>(StringComparer.OrdinalIgnoreCase);
        var subagentSpans = new Dictionary<string, (string Name, DateTimeOffset Start, DateTimeOffset End)>(StringComparer.Ordinal);

        foreach (var file in files)
        {
            var name = Path.GetFileName(file);
            bool isMain = name.Equals("main.jsonl", StringComparison.OrdinalIgnoreCase);
            var (runId, agentName, isTitle) = isMain ? (AgentRun.MainId, AgentRun.MainName, false) : ChildIdentity(name, childLabels);
            if (!isMain && !data.Runs.ContainsKey(runId))
                data.Runs[runId] = new AgentRun { Id = runId, Name = agentName };

            int lines = 0, bad = 0;
            try
            {
                foreach (var line in SafeFile.ReadLines(file))
                {
                    if (line.Length == 0) continue;
                    lines++;
                    using var doc = ParseObject(line);
                    if (doc is null) { bad++; continue; }
                    Read(doc.RootElement, data, runId, agentName, isMain, isTitle, childLabels, subagentSpans);
                }
            }
            catch (Exception e) when (e is IOException or UnauthorizedAccessException) { bad++; }
            data.Diagnostics.Files.Add((name, lines, bad));
        }

        // Sub-agent run timing: the subagent span that shares its parent tool span with the child_session_ref.
        foreach (var (childId, (_, parentSpan)) in childLabels)
            if (parentSpan is not null && subagentSpans.TryGetValue(parentSpan, out var span) && data.Runs.TryGetValue(childId, out var run))
            {
                run.Name = span.Name;
                run.Start = span.Start;
                run.End = span.End;
            }

        var limits = ModelLimits.Read(Path.Combine(session.Dir, "models.json"));
        foreach (var c in data.Calls) c.MaxPromptTokens ??= ModelLimits.For(limits, c.Model);
        data.Finish();
        return data;
    }

    static void Read(JsonElement e, SessionData data, string runId, string agentName, bool isMain, bool isTitle,
        Dictionary<string, (string Label, string? ParentSpan)> childLabels,
        Dictionary<string, (string Name, DateTimeOffset Start, DateTimeOffset End)> subagentSpans)
    {
        var type = Str(e, "type") ?? "<missing>";
        var counts = data.Diagnostics.EventCounts;
        counts[type] = counts.GetValueOrDefault(type) + 1;
        if (!DebugLogFormat.AttrsByType.ContainsKey(type)) data.Diagnostics.UnknownEventTypes.Add(type);

        var start = EpochMs(e, "ts");
        if (start is null) return;
        var end = start.Value + TimeSpan.FromMilliseconds(Double(e, "dur") ?? 0);
        data.SeeTimestamp(start.Value);
        var attrs = At(e, "attrs");

        switch (type)
        {
            case "session_start" when isMain:
                data.CopilotVersion ??= Str(attrs, "copilotVersion");
                break;

            case "child_session_ref" when isMain:
                if (Str(attrs, "childSessionId") is { } childId)
                    childLabels[childId] = (Str(attrs, "label") ?? Str(e, "name") ?? "sub-agent", Str(e, "parentSpanId"));
                break;

            case "subagent" when isMain:
                if (Str(e, "parentSpanId") is { } parent)
                    subagentSpans[parent] = (Str(attrs, "agentName") ?? Str(e, "name") ?? "sub-agent", start.Value, end);
                break;

            case "user_message" when isMain:
                data.TurnStarts.Add(start.Value);
                if (SkillNames.FromMessage(Str(attrs, "content")) is { } skill)
                    data.Skills.Add(new SkillUse { At = start.Value, Name = skill });
                break;

            case "llm_request":
            {
                var debugName = Str(attrs, "debugName") ?? "";
                bool failed = Str(e, "status") == "error" || Has(attrs, "error");
                data.Calls.Add(new ModelCall
                {
                    Start = start.Value,
                    End = end,
                    AgentRunId = runId,
                    Agent = agentName,
                    Model = Str(attrs, "model") ?? "unknown",
                    Input = Long(attrs, "inputTokens") ?? 0,
                    CacheRead = Long(attrs, "cachedTokens") ?? 0,
                    Output = Long(attrs, "outputTokens") ?? 0,
                    NanoAiu = failed ? null : Long(attrs, "copilotUsageNanoAiu"),
                    Failed = failed,
                    ToolsFile = Str(attrs, "toolsFile"),
                    Kind = debugName.StartsWith("summarizeConversationHistory", StringComparison.OrdinalIgnoreCase) ? CallKind.Compaction
                        : isTitle || debugName.Contains("title", StringComparison.OrdinalIgnoreCase) ? CallKind.Title
                        : CallKind.Request,
                });
                break;
            }

            case "tool_call":
                data.Tools.Add(new ToolCall
                {
                    Start = start.Value,
                    End = end,
                    AgentRunId = runId,
                    Agent = agentName,
                    Name = Str(e, "name") ?? "unknown",
                    Success = Str(e, "status") != "error",
                });
                break;
        }
    }

    /// <summary>Run ID and agent name of a child log: runSubagent-Reqs-&lt;id&gt;.jsonl → (id, "Reqs").</summary>
    static (string RunId, string Name, bool IsTitle) ChildIdentity(string fileName, Dictionary<string, (string Label, string? ParentSpan)> childLabels)
    {
        var stem = Path.GetFileNameWithoutExtension(fileName);
        // Prefer the exact mapping from child_session_ref (childLogFile = "<label>-<childId>.jsonl").
        foreach (var (childId, (label, _)) in childLabels)
            if (stem.EndsWith("-" + childId, StringComparison.OrdinalIgnoreCase) || stem.EndsWith("-" + Sanitize(childId), StringComparison.OrdinalIgnoreCase))
                return (childId, AgentName(label), label.StartsWith("title", StringComparison.OrdinalIgnoreCase));

        bool isTitle = stem.StartsWith("title", StringComparison.OrdinalIgnoreCase);
        if (stem.StartsWith("runSubagent-", StringComparison.OrdinalIgnoreCase))
        {
            var rest = stem["runSubagent-".Length..];
            int dash = rest.IndexOf('-');
            return dash > 0 ? (rest[(dash + 1)..], rest[..dash], false) : (rest, rest, false);
        }
        int first = stem.IndexOf('-');
        return first > 0 ? (stem[(first + 1)..], isTitle ? "title" : stem[..first], isTitle) : (stem, stem, isTitle);
    }

    static string AgentName(string label) =>
        label.StartsWith("runSubagent-", StringComparison.OrdinalIgnoreCase) ? label["runSubagent-".Length..]
        : label.StartsWith("title", StringComparison.OrdinalIgnoreCase) ? "title"
        : label;

    static string Sanitize(string s) =>
        new string(s.Select(c => "/\\:*?\"<>|".Contains(c) || c < 0x20 ? '_' : c).ToArray()).Replace("..", "_");
}
