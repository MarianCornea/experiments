using System.Text.RegularExpressions;

namespace CopilotUsage.Logs;

public enum LogFileKind { Main, Child, SystemPrompt, Tools, Models, Other }

/// <summary>
/// The debug-log format as written by Copilot Chat 0.60–0.73 (ChatDebugFileLogger).
/// See docs/copilot-log-format.md. Anything outside this set is reported by probe check P11.
/// </summary>
public static partial class DebugLogFormat
{
    public const string ExpectedFrom = "Copilot Chat 0.60–0.73 source (ChatDebugFileLogger)";

    public static readonly IReadOnlySet<string> EnvelopeFields = new HashSet<string>
        { "v", "ts", "dur", "sid", "type", "name", "spanId", "parentSpanId", "status", "attrs", "rIdx" };

    public static readonly IReadOnlyDictionary<string, IReadOnlySet<string>> AttrsByType = new Dictionary<string, IReadOnlySet<string>>
    {
        ["session_start"] = new HashSet<string> { "copilotVersion", "vscodeVersion", "parentSessionId", "label" },
        ["turn_start"] = new HashSet<string> { "turnId" },
        ["turn_end"] = new HashSet<string> { "turnId" },
        ["user_message"] = new HashSet<string> { "content" },
        ["agent_response"] = new HashSet<string> { "response", "reasoning" },
        ["llm_request"] = new HashSet<string>
        {
            "model", "debugName", "inputTokens", "outputTokens", "cachedTokens", "ttft", "responseId", "userRequest",
            "inputMessages", "maxTokens", "temperature", "topP", "requestOptions", "requestShape", "copilotUsageNanoAiu",
            "error", "systemPromptFile", "toolsFile",
        },
        ["tool_call"] = new HashSet<string> { "args", "result", "error" },
        ["subagent"] = new HashSet<string> { "agentName", "description", "error" },
        ["hook"] = new HashSet<string> { "command", "input", "output", "resultKind", "error" },
        ["child_session_ref"] = new HashSet<string> { "childSessionId", "childLogFile", "label" },
        ["discovery"] = new HashSet<string> { "details", "category", "source" },
        ["generic"] = new HashSet<string> { "details", "category", "source" },
        ["error"] = new HashSet<string>(),
    };

    /// <summary>Event types whose "name" is a tool, agent, hook, model or label name, so it may be recorded.</summary>
    public static readonly IReadOnlySet<string> TypesWithSafeNames = new HashSet<string>
        { "tool_call", "subagent", "hook", "child_session_ref", "llm_request", "session_start", "user_message", "agent_response" };

    /// <summary>Attribute values that are names or versions, never content, so they may be recorded.</summary>
    public static readonly IReadOnlySet<string> SafeValueAttrs = new HashSet<string>
    {
        "llm_request.model", "llm_request.debugName", "session_start.copilotVersion", "session_start.vscodeVersion",
        "session_start.label", "subagent.agentName", "child_session_ref.label", "hook.resultKind",
        "discovery.category", "generic.category", "discovery.source", "generic.source",
    };

    /// <summary>Names of terminal tools, used for probe check P12.</summary>
    public static readonly IReadOnlySet<string> TerminalTools = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        { "run_in_terminal", "runInTerminal", "copilot_runInTerminal", "terminal", "run_terminal_command" };

    public static (LogFileKind Kind, string Pattern) Classify(string fileName)
    {
        if (fileName.Equals("main.jsonl", StringComparison.OrdinalIgnoreCase)) return (LogFileKind.Main, "main.jsonl");
        if (fileName.Equals("models.json", StringComparison.OrdinalIgnoreCase)) return (LogFileKind.Models, "models.json");
        if (SystemPromptFile().IsMatch(fileName)) return (LogFileKind.SystemPrompt, "system_prompt_*.json");
        if (ToolsFile().IsMatch(fileName)) return (LogFileKind.Tools, "tools_*.json");
        if (fileName.EndsWith(".jsonl", StringComparison.OrdinalIgnoreCase))
        {
            if (fileName.StartsWith("runSubagent-", StringComparison.OrdinalIgnoreCase)) return (LogFileKind.Child, "runSubagent-*.jsonl");
            int dash = fileName.IndexOf('-');
            return (LogFileKind.Child, dash > 0 ? Generalize(fileName[..dash]) + "-*.jsonl" : "*.jsonl");
        }
        return (LogFileKind.Other, Generalize(fileName));
    }

    /// <summary>Replaces digit and hex runs so a file name becomes a pattern without IDs.</summary>
    static string Generalize(string name) => IdRun().Replace(name, "#");

    [GeneratedRegex(@"^system_prompt_\d+\.json$", RegexOptions.IgnoreCase)]
    private static partial Regex SystemPromptFile();

    [GeneratedRegex(@"^tools_\d+\.json$", RegexOptions.IgnoreCase)]
    private static partial Regex ToolsFile();

    [GeneratedRegex(@"[0-9a-fA-F]{6,}|\d+")]
    private static partial Regex IdRun();
}
