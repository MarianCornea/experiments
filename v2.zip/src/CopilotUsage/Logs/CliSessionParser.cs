using System.Text.Json;
using CopilotUsage.Model;
using CopilotUsage.Probe;
using CopilotUsage.Storage;
using static CopilotUsage.Logs.Json;

namespace CopilotUsage.Logs;

/// <summary>Parses a Copilot harness session (events.jsonl) into calls, tools, agent runs and skills (FR-05).</summary>
public static class CliSessionParser
{
    public static SessionData Parse(CliSession session)
    {
        var data = new SessionData { Session = session, Title = session.Title };
        var tools = new Dictionary<string, ToolCall>(StringComparer.Ordinal);
        int lines = 0, bad = 0;
        if (File.Exists(session.EventsFile))
        {
            try
            {
                foreach (var line in SafeFile.ReadLines(session.EventsFile))
                {
                    if (line.Length == 0) continue;
                    lines++;
                    using var doc = ParseObject(line);
                    if (doc is null) { bad++; continue; }
                    Read(doc.RootElement, data, tools);
                }
            }
            catch (Exception e) when (e is IOException or UnauthorizedAccessException) { bad++; }
        }
        data.Diagnostics.Files.Add(("events.jsonl", lines, bad));
        data.Finish();
        return data;
    }

    static void Read(JsonElement e, SessionData data, Dictionary<string, ToolCall> tools)
    {
        var type = Str(e, "type") ?? "<missing>";
        var counts = data.Diagnostics.EventCounts;
        counts[type] = counts.GetValueOrDefault(type) + 1;
        if (!CliProber.KnownTypes.Contains(type)) data.Diagnostics.UnknownEventTypes.Add(type);

        var at = Time(e, "timestamp");
        if (at is { } t) data.SeeTimestamp(t);
        var d = At(e, "data");
        var agentId = Str(e, "agentId") is { Length: > 0 } id ? id : AgentRun.MainId;

        switch (type)
        {
            case "session.start":
                data.CopilotVersion = Str(d, "copilotVersion");
                break;

            case "subagent.started":
            {
                var run = Run(data, agentId);
                run.Name = Str(d, "agentName") ?? run.Name;
                run.Start ??= at;
                run.Model = Str(d, "model") ?? run.Model;
                break;
            }

            case "subagent.completed":
                Run(data, agentId).End = at;
                break;

            case "user.message" when agentId == AgentRun.MainId && Str(d, "source") is null:
                if (at is { } promptAt) data.TurnStarts.Add(promptAt);
                if (SkillNames.FromMessage(Str(d, "content")) is { } skill && at is { } when)
                    data.Skills.Add(new SkillUse { At = when, Name = skill });
                break;

            // The runtime logs every skill it loads, by name; more exact than spotting slash commands.
            case "skill.invoked":
                if (Str(d, "name") is { Length: > 0 and <= 64 } invoked && at is { } invokedAt)
                    data.Skills.Add(new SkillUse { At = invokedAt, Name = invoked });
                break;

            case "session.usage_record":
                if (at is { } end) data.Calls.Add(ReadCall(At(d, "usage"), end, data, agentId));
                break;

            case "tool.execution_start":
            {
                var name = Str(d, "toolName") ?? "unknown";
                var tool = new ToolCall
                {
                    Start = at ?? default, End = at ?? default, Name = name,
                    AgentRunId = agentId, Agent = Run(data, agentId).Name,
                };
                if (Str(d, "toolCallId") is { } callId) tools[callId] = tool;
                data.Tools.Add(tool);
                // A skill run through the skill tool counts like a slash command.
                if (name.Equals("skill", StringComparison.OrdinalIgnoreCase) && at is { } toolAt &&
                    (Str(At(d, "arguments"), "skill") ?? Str(At(d, "arguments"), "name")) is { Length: > 0 and <= 64 } toolSkill)
                    data.Skills.Add(new SkillUse { At = toolAt, Name = toolSkill });
                break;
            }

            case "tool.execution_complete":
                if (Str(d, "toolCallId") is { } completedId && tools.TryGetValue(completedId, out var done))
                {
                    if (at is { } finished) done.End = finished;
                    done.Success = d.TryGetProperty("success", out var ok) ? ok.ValueKind != JsonValueKind.False : true;
                    done.ResultTokens = Long(At(d, "toolTelemetry.metrics"), "result_token_count");
                }
                break;

            case "session.usage_checkpoint":
                if (Long(d, "totalNanoAiu") is long total) data.CheckpointNanoAiu = total;
                break;
        }
    }

    static ModelCall ReadCall(JsonElement u, DateTimeOffset end, SessionData data, string agentId)
    {
        double durationMs = Double(u, "duration") ?? 0;
        var interaction = (Str(u, "interactionType") ?? "") + " " + (Str(u, "initiator") ?? "");
        var call = new ModelCall
        {
            End = end,
            Start = end - TimeSpan.FromMilliseconds(durationMs),
            AgentRunId = agentId,
            Agent = Run(data, agentId).Name,
            Model = Str(u, "model") ?? "unknown",
            MaxPromptTokens = Long(u, "maxPromptTokens"),
            CacheTtlSeconds = Long(u, "cacheTtlSeconds") is long ttl ? (int)ttl : null,
            Input = Long(u, "inputTokens") ?? 0,
            CacheRead = Long(u, "cacheReadTokens") ?? 0,
            CacheWrite = Long(u, "cacheWriteTokens") ?? 0,
            Output = Long(u, "outputTokens") ?? 0,
            Reasoning = Long(u, "reasoningTokens") ?? 0,
            ToolDefinitionTokens = Long(u, "toolTokenCount"),
            NanoAiu = Long(At(u, "copilotUsage"), "totalNanoAiu"),
            Kind = interaction.Contains("compact", StringComparison.OrdinalIgnoreCase) || interaction.Contains("summar", StringComparison.OrdinalIgnoreCase)
                ? CallKind.Compaction
                : interaction.Contains("title", StringComparison.OrdinalIgnoreCase) ? CallKind.Title : CallKind.Request,
        };
        call.BilledSplitNano = BilledSplit(At(u, "copilotUsage.tokenDetails"));
        return call;
    }

    /// <summary>Copilot's own billed split: nanoAIU per token type (input, cache_read, cache_write, output).</summary>
    static CostSplit? BilledSplit(JsonElement details)
    {
        if (details.ValueKind != JsonValueKind.Array || details.GetArrayLength() == 0) return null;
        double fresh = 0, read = 0, write = 0, output = 0, other = 0;
        foreach (var t in details.EnumerateArray())
        {
            double count = Double(t, "tokenCount") ?? 0, batch = Double(t, "batchSize") ?? 0, cost = Double(t, "costPerBatch") ?? 0;
            if (batch <= 0) return null;
            double nano = count / batch * cost;
            switch (Str(t, "tokenType"))
            {
                case "input": fresh += nano; break;
                case "cache_read": read += nano; break;
                case "cache_write": write += nano; break;
                case "output": output += nano; break;
                default: other += nano; break;
            }
        }
        return new CostSplit(fresh, read, write, output, other);
    }

    static AgentRun Run(SessionData data, string agentId)
    {
        if (agentId == AgentRun.MainId) return data.MainRun();
        if (!data.Runs.TryGetValue(agentId, out var run))
            data.Runs[agentId] = run = new AgentRun { Id = agentId, Name = "sub-agent" };
        return run;
    }
}
