using System.Text;
using System.Text.Json;
using CopilotUsage.Model;
using CopilotUsage.Storage;

namespace CopilotUsage.Logs;

/// <summary>
/// Reads a debug log's tools_N.json: {"content": "&lt;JSON array of tool definitions&gt;"}, each element
/// {type, name, description, parameters} (or the OpenAI shape {type, function: {name, …}}). Keeps names and sizes only.
/// </summary>
public static class ToolDefinitions
{
    public static IReadOnlyList<ToolDefinition>? Read(string file)
    {
        try
        {
            using var outer = JsonDocument.Parse(SafeFile.ReadAllText(file));
            if (Json.Str(outer.RootElement, "content") is not { } content) return null;
            using var inner = JsonDocument.Parse(content);
            if (inner.RootElement.ValueKind != JsonValueKind.Array) return null;
            var list = new List<ToolDefinition>();
            foreach (var el in inner.RootElement.EnumerateArray())
            {
                var name = Json.Str(el, "name") ?? (el.ValueKind == JsonValueKind.Object && el.TryGetProperty("function", out var fn) ? Json.Str(fn, "name") : null);
                if (name is null) continue;
                long bytes = Encoding.UTF8.GetByteCount(el.GetRawText());
                list.Add(new ToolDefinition(name, (bytes + 3) / 4));
            }
            return list;
        }
        catch (Exception e) when (e is JsonException or IOException or UnauthorizedAccessException)
        {
            return null;
        }
    }
}
