using System.Text.Json;
using System.Text.Json.Nodes;
using CopilotUsage.Model;
using CopilotUsage.Storage;

namespace CopilotUsage.Logs;

/// <summary>
/// Replays a VS Code chat transcript (chatSessions/*.jsonl). Each line is one operation on the chat's state:
/// kind 0 = the whole state, 1 = set the value at path k, 2 = append v to the array at k (first truncating it to i
/// when i is given), 3 = delete the value at k. Verified against VS Code 1.132's writer (see docs/copilot-log-format.md).
/// </summary>
public static class ChatTranscript
{
    public sealed class Replayed
    {
        public JsonObject? State { get; set; }
        public int Lines { get; set; }
        public int BadLines { get; set; }
        public SortedDictionary<string, int> Operations { get; } = new(StringComparer.Ordinal);
        public SortedSet<string> UnknownOperations { get; } = new(StringComparer.Ordinal);
        /// <summary>Whether the first operation was a full state (kind 0), as the format requires.</summary>
        public bool StartsWithState { get; set; }
    }

    public static Replayed Replay(string file)
    {
        var r = new Replayed();
        foreach (var line in SafeFile.ReadLines(file))
        {
            if (string.IsNullOrWhiteSpace(line)) continue;
            r.Lines++;
            JsonObject? op;
            try { op = JsonNode.Parse(line) as JsonObject; }
            catch (JsonException) { r.BadLines++; continue; }
            if (op is null || Int(op["kind"]) is not int kind) { r.BadLines++; continue; }
            if (r.Lines == 1) r.StartsWithState = kind == 0;
            var key = "kind " + kind;
            r.Operations[key] = r.Operations.GetValueOrDefault(key) + 1;
            try
            {
                if (!Apply(r, op, kind)) r.UnknownOperations.Add(key);
            }
            catch (Exception e) when (e is InvalidOperationException or ArgumentException or FormatException or IndexOutOfRangeException)
            {
                r.BadLines++;
            }
        }
        return r;
    }

    static bool Apply(Replayed r, JsonObject op, int kind)
    {
        var value = op["v"]?.DeepClone();
        if (kind == 0)
        {
            r.State = value as JsonObject;
            return true;
        }
        if (kind is not (1 or 2 or 3)) return false;
        if (r.State is null || op["k"] is not JsonArray path || path.Count == 0) throw new InvalidOperationException("operation before state or without path");

        // Walk to the parent of the last path segment, creating objects on the way for set and append.
        JsonNode parent = r.State;
        for (int i = 0; i < path.Count - 1; i++)
        {
            var next = Child(parent, path[i]);
            if (next is null)
            {
                if (kind == 3) return true;
                next = new JsonObject();
                SetChild(parent, path[i], next);
            }
            parent = next;
        }
        var last = path[^1];
        switch (kind)
        {
            case 1:
                SetChild(parent, last, value);
                break;
            case 2:
                if (Child(parent, last) is not JsonArray array)
                {
                    array = [];
                    SetChild(parent, last, array);
                }
                if (Int(op["i"]) is int at)
                    while (array.Count > Math.Max(0, at)) array.RemoveAt(array.Count - 1);
                if (value is JsonArray items)
                    foreach (var item in items.ToList())
                    {
                        items.Remove(item);
                        array.Add(item);
                    }
                break;
            case 3:
                if (parent is JsonObject o && last?.GetValueKind() == JsonValueKind.String) o.Remove(last.GetValue<string>());
                else if (parent is JsonArray a && Int(last) is int idx && idx >= 0 && idx < a.Count) a.RemoveAt(idx);
                break;
        }
        return true;
    }

    static JsonNode? Child(JsonNode parent, JsonNode? segment) => parent switch
    {
        JsonObject o when segment?.GetValueKind() == JsonValueKind.String => o[segment.GetValue<string>()],
        JsonArray a when Int(segment) is int i && i >= 0 && i < a.Count => a[i],
        _ => null,
    };

    static void SetChild(JsonNode parent, JsonNode? segment, JsonNode? value)
    {
        switch (parent)
        {
            case JsonObject o when segment?.GetValueKind() == JsonValueKind.String:
                o[segment.GetValue<string>()] = value;
                break;
            case JsonArray a when Int(segment) is int i && i >= 0:
                while (a.Count < i) a.Add(null);
                if (i == a.Count) a.Add(value); else a[i] = value;
                break;
            default:
                throw new InvalidOperationException("path does not fit the state");
        }
    }

    internal static int? Int(JsonNode? n) =>
        n is JsonValue v && v.GetValueKind() == JsonValueKind.Number && v.TryGetValue<double>(out var d) && d == Math.Floor(d) ? (int)d : null;

    internal static string? Str(JsonNode? n, string key) =>
        n is JsonObject o && o[key] is JsonValue v && v.GetValueKind() == JsonValueKind.String ? v.GetValue<string>() : null;

    internal static double? Num(JsonNode? n, string key) =>
        n is JsonObject o && o[key] is JsonValue v && v.GetValueKind() == JsonValueKind.Number ? v.GetValue<double>() : null;

    internal static JsonArray? Arr(JsonNode? n, string key) => n is JsonObject o ? o[key] as JsonArray : null;
}

/// <summary>
/// Turns a chat transcript into session data: one record per request for the main agent and one per sub-agent run,
/// each with Copilot's billed credits. Prompt, response and tool text is never kept.
/// </summary>
public static class TranscriptParser
{
    public static SessionData Parse(TranscriptSession session)
    {
        var data = new SessionData { Session = session, PerRequest = true };
        var replayed = ChatTranscript.Replay(session.File);
        data.Diagnostics.Files.Add((Path.GetFileName(session.File), replayed.Lines, replayed.BadLines));
        foreach (var (k, v) in replayed.Operations) data.Diagnostics.EventCounts[k] = v;
        foreach (var k in replayed.UnknownOperations) data.Diagnostics.UnknownEventTypes.Add(k);

        var state = replayed.State;
        data.Title = ChatTranscript.Str(state, "customTitle");
        if (ChatTranscript.Num(state, "creationDate") is double created) data.SeeTimestamp(FromMs(created));

        var requests = ChatTranscript.Arr(state, "requests") ?? [];
        for (int i = 0; i < requests.Count; i++)
            if (requests[i] is JsonObject request) AddRequest(data, request, i);

        // The chat's debug-log folder, when VS Code made one, holds models.json with each model's prompt limit.
        if (session.WorkspaceStorageDir is not null)
        {
            var limits = SessionCatalog.ExtensionFolders
                .Select(ext => ModelLimits.Read(Path.Combine(session.WorkspaceStorageDir, ext, SessionCatalog.DebugLogsFolder, session.Id, "models.json")))
                .FirstOrDefault(l => l.Count > 0);
            if (limits is not null)
                foreach (var c in data.Calls.Where(c => c.AgentRunId == AgentRun.MainId)) c.MaxPromptTokens = ModelLimits.For(limits, c.Model);
        }
        data.Finish();
        return data;
    }

    static void AddRequest(SessionData data, JsonObject request, int index)
    {
        var start = ChatTranscript.Num(request, "timestamp") is double ts ? FromMs(ts) : data.FirstEvent ?? DateTimeOffset.UnixEpoch;
        var result = request["result"] as JsonObject;
        var meta = result?["metadata"] as JsonObject;
        double elapsedMs = ChatTranscript.Num(result?["timings"], "totalElapsed") ?? ChatTranscript.Num(request, "elapsedMs") ?? 0;
        var end = start.AddMilliseconds(Math.Max(0, elapsedMs));
        data.TurnStarts.Add(start);
        data.SeeTimestamp(start);
        data.SeeTimestamp(end);

        var skill = ChatTranscript.Str(request["slashCommand"], "name") ?? SkillNames.FromMessage(ChatTranscript.Str(request["message"], "text"));
        if (skill is not null) data.Skills.Add(new SkillUse { At = start, Name = skill });

        var rounds = ChatTranscript.Arr(meta, "toolCallRounds")?.OfType<JsonObject>().ToList() ?? [];
        var parts = ChatTranscript.Arr(request, "response")?.OfType<JsonObject>().ToList() ?? [];

        // Sub-agent runs: a runSubagent tool part whose toolSpecificData carries the run's billed credits. Its start is the
        // model call that asked for it; it ends when the next model call of the main agent starts.
        var subagentRounds = rounds.Where(r => ChatTranscript.Arr(r, "toolCalls")?.OfType<JsonObject>()
                                                   .Any(t => ChatTranscript.Str(t, "name") == "runSubagent") == true).ToList();
        long subNano = 0;
        int subIndex = 0;
        foreach (var part in parts.Where(p => ChatTranscript.Str(p["toolSpecificData"], "kind") == "subagent"))
        {
            var detail = part["toolSpecificData"];
            var runId = ChatTranscript.Str(part, "toolCallId") ?? $"subagent-{index + 1}-{subIndex + 1}";
            var round = subIndex < subagentRounds.Count ? subagentRounds[subIndex] : null;
            subIndex++;
            var runStart = ChatTranscript.Num(round, "timestamp") is double rs ? FromMs(rs) : start;
            var after = round is null ? null : rounds.SkipWhile(r => r != round).Skip(1).FirstOrDefault();
            var runEnd = ChatTranscript.Num(after, "timestamp") is double re ? FromMs(re) : end;
            var model = Model(ChatTranscript.Str(detail, "modelName"));
            data.Runs[runId] = new AgentRun { Id = runId, Name = ChatTranscript.Str(detail, "agentName") ?? "subagent", Start = runStart, End = runEnd, Model = model };
            long? nano = ChatTranscript.Num(detail, "credits") is double c ? Nano(c) : null;
            subNano += nano ?? 0;
            data.Calls.Add(new ModelCall
            {
                AgentRunId = runId, Model = model, Start = runStart, End = runEnd, NanoAiu = nano, Kind = CallKind.Request,
                Rounds = 0, // the transcript does not say how many model calls the sub-agent made
            });
        }

        // The main agent: the request's billed total (sub-agents included) minus the sub-agent runs.
        long? total = ChatTranscript.Num(request, "copilotCredits") is double credits ? Nano(credits) : null;
        var mainModel = Model(ChatTranscript.Str(meta, "resolvedModel")
                              ?? parts.Select(p => ChatTranscript.Str(p, "resolvedModel")).FirstOrDefault(m => m is not null)
                              ?? rounds.Select(r => ChatTranscript.Str(r, "modelId")).Where(m => m is not null).GroupBy(m => m).MaxBy(g => g.Count())?.Key
                              ?? ChatTranscript.Str(request, "modelId"));
        data.Calls.Add(new ModelCall
        {
            Model = mainModel, Start = start, End = end, Kind = CallKind.Request,
            NanoAiu = total is long t ? Math.Max(0, t - subNano) : null,
            Input = (long)(ChatTranscript.Num(request, "promptTokens") ?? ChatTranscript.Num(meta, "promptTokens") ?? 0),
            Output = (long)(ChatTranscript.Num(request, "completionTokens") ?? ChatTranscript.Num(meta, "outputTokens") ?? 0),
            Reasoning = (long)rounds.Sum(r => ChatTranscript.Num(r["thinking"], "tokens") ?? 0),
            Rounds = Math.Max(1, rounds.Count),
            Failed = total is null && result?["errorDetails"] is not null,
        });

        // Tools: name and owner only. The transcript gives no tool timings, so each takes its run's start.
        foreach (var part in parts.Where(p => ChatTranscript.Str(p, "kind") == "toolInvocationSerialized"))
        {
            var owner = ChatTranscript.Str(part, "subAgentInvocationId") is { } sub && data.Runs.ContainsKey(sub) ? sub : AgentRun.MainId;
            var at = owner == AgentRun.MainId ? start : data.Runs[owner].Start ?? start;
            data.Tools.Add(new ToolCall { Name = ChatTranscript.Str(part, "toolId") ?? "tool", AgentRunId = owner, Start = at, End = at });
        }
    }

    /// <summary>Model IDs as the other logs write them: "copilot/auto" → "auto", "Auto" → "auto".</summary>
    static string Model(string? id)
    {
        if (string.IsNullOrWhiteSpace(id)) return "unknown";
        var m = id.Trim();
        if (m.StartsWith("copilot/", StringComparison.OrdinalIgnoreCase)) m = m["copilot/".Length..];
        return m.ToLowerInvariant();
    }

    static long Nano(double credits) => (long)Math.Round(credits * 1e9);

    static DateTimeOffset FromMs(double ms) => DateTimeOffset.FromUnixTimeMilliseconds((long)ms);
}
