using System.Buffers.Binary;
using System.Text;
using CopilotUsage.Storage;

namespace CopilotUsage.Sqlite;

/// <summary>
/// A minimal read-only SQLite reader: enough to scan table b-trees (with overflow pages) and to
/// apply committed frames from a -wal file. Used for state.vscdb, so no NuGet package is needed (NFR-02).
/// The database is read into memory with shared access, so VS Code is never blocked.
/// </summary>
public sealed class SqliteFile
{
    readonly byte[] _db;
    readonly Dictionary<uint, byte[]> _walPages = [];
    readonly int _usable;

    public int PageSize { get; }
    public int TextEncoding { get; }
    public int WalFramesApplied { get; private set; }

    SqliteFile(byte[] db)
    {
        _db = db;
        if (db.Length < 100 || Encoding.ASCII.GetString(db, 0, 16) != "SQLite format 3\0")
            throw new InvalidDataException("not a SQLite 3 database");
        int pageSize = BinaryPrimitives.ReadUInt16BigEndian(db.AsSpan(16));
        PageSize = pageSize == 1 ? 65536 : pageSize;
        _usable = PageSize - db[20];
        int encoding = (int)BinaryPrimitives.ReadUInt32BigEndian(db.AsSpan(56));
        TextEncoding = encoding is 2 or 3 ? encoding : 1;
    }

    public static SqliteFile Open(string path)
    {
        var file = new SqliteFile(SafeFile.ReadAllBytes(path));
        var wal = path + "-wal";
        if (File.Exists(wal))
        {
            var bytes = SafeFile.ReadAllBytes(wal);
            if (bytes.Length > 32) file.ApplyWal(bytes);
        }
        return file;
    }

    /// <summary>Keeps the newest copy of each page from frames up to the last commit whose salts match the WAL header.</summary>
    void ApplyWal(byte[] wal)
    {
        uint magic = BinaryPrimitives.ReadUInt32BigEndian(wal);
        if (magic is not (0x377f0682 or 0x377f0683)) return;
        int walPageSize = (int)BinaryPrimitives.ReadUInt32BigEndian(wal.AsSpan(8));
        if (walPageSize != PageSize) return;
        uint salt1 = BinaryPrimitives.ReadUInt32BigEndian(wal.AsSpan(16));
        uint salt2 = BinaryPrimitives.ReadUInt32BigEndian(wal.AsSpan(20));

        var pending = new Dictionary<uint, byte[]>();
        int frames = 0;
        for (long offset = 32; offset + 24 + PageSize <= wal.Length; offset += 24 + PageSize)
        {
            var header = wal.AsSpan((int)offset, 24);
            if (BinaryPrimitives.ReadUInt32BigEndian(header[8..]) != salt1 ||
                BinaryPrimitives.ReadUInt32BigEndian(header[12..]) != salt2)
                break; // frames from an older WAL generation
            uint pageNumber = BinaryPrimitives.ReadUInt32BigEndian(header);
            uint dbSizeAfterCommit = BinaryPrimitives.ReadUInt32BigEndian(header[4..]);
            pending[pageNumber] = wal.AsSpan((int)offset + 24, PageSize).ToArray();
            frames++;
            if (dbSizeAfterCommit != 0)
            {
                foreach (var (page, data) in pending) _walPages[page] = data;
                pending.Clear();
                WalFramesApplied = frames;
            }
        }
    }

    byte[] Page(uint number)
    {
        if (_walPages.TryGetValue(number, out var fromWal)) return fromWal;
        long offset = (long)(number - 1) * PageSize;
        if (number == 0 || offset + PageSize > _db.Length)
            throw new InvalidDataException($"page {number} is outside the database");
        return _db.AsSpan((int)offset, PageSize).ToArray();
    }

    /// <summary>Rows of the table with the given root page, in rowid order.</summary>
    public IEnumerable<object?[]> ReadTable(uint rootPage)
    {
        var stack = new Stack<uint>();
        var visited = new HashSet<uint>();
        stack.Push(rootPage);
        while (stack.Count > 0)
        {
            uint number = stack.Pop();
            if (!visited.Add(number)) throw new InvalidDataException($"b-tree loop at page {number}");
            var page = Page(number);
            int h = number == 1 ? 100 : 0;
            byte type = page[h];
            int cells = BinaryPrimitives.ReadUInt16BigEndian(page.AsSpan(h + 3));

            if (type == 0x05) // interior table page: push children right-to-left so they pop in order
            {
                stack.Push(BinaryPrimitives.ReadUInt32BigEndian(page.AsSpan(h + 8)));
                for (int i = cells - 1; i >= 0; i--)
                {
                    int pointer = BinaryPrimitives.ReadUInt16BigEndian(page.AsSpan(h + 12 + 2 * i));
                    stack.Push(BinaryPrimitives.ReadUInt32BigEndian(page.AsSpan(pointer)));
                }
            }
            else if (type == 0x0D) // leaf table page
            {
                for (int i = 0; i < cells; i++)
                {
                    int p = BinaryPrimitives.ReadUInt16BigEndian(page.AsSpan(h + 8 + 2 * i));
                    long payloadSize = ReadVarint(page, ref p);
                    ReadVarint(page, ref p); // rowid
                    yield return DecodeRecord(ReadPayload(page, p, payloadSize));
                }
            }
            else
            {
                throw new InvalidDataException($"page {number} is not a table page (type {type})");
            }
        }
    }

    /// <summary>Root page of a table, from sqlite_master.</summary>
    public uint? FindTable(string name)
    {
        foreach (var row in ReadTable(1))
            if (row.Length >= 4 && row[0] is "table" && row[1] is string n &&
                n.Equals(name, StringComparison.OrdinalIgnoreCase) && row[3] is long root)
                return (uint)root;
        return null;
    }

    byte[] ReadPayload(byte[] page, int start, long size)
    {
        int maxLocal = _usable - 35;
        if (size <= maxLocal) return page.AsSpan(start, (int)size).ToArray();

        int minLocal = ((_usable - 12) * 32 / 255) - 23;
        long k = minLocal + ((size - minLocal) % (_usable - 4));
        int local = k <= maxLocal ? (int)k : minLocal;

        var payload = new byte[size];
        page.AsSpan(start, local).CopyTo(payload);
        int written = local;
        uint next = BinaryPrimitives.ReadUInt32BigEndian(page.AsSpan(start + local));
        int guard = 0;
        while (written < size && next != 0)
        {
            if (++guard > 1_000_000) throw new InvalidDataException("overflow chain too long");
            var overflow = Page(next);
            next = BinaryPrimitives.ReadUInt32BigEndian(overflow);
            int n = (int)Math.Min(_usable - 4, size - written);
            overflow.AsSpan(4, n).CopyTo(payload.AsSpan(written));
            written += n;
        }
        if (written < size) throw new InvalidDataException("overflow chain ended early");
        return payload;
    }

    object?[] DecodeRecord(byte[] record)
    {
        int p = 0;
        long headerSize = ReadVarint(record, ref p);
        var types = new List<long>();
        while (p < headerSize) types.Add(ReadVarint(record, ref p));

        var values = new object?[types.Count];
        int d = (int)headerSize;
        for (int i = 0; i < types.Count; i++)
        {
            long t = types[i];
            switch (t)
            {
                case 0: values[i] = null; break;
                case >= 1 and <= 6:
                    int len = t switch { 5 => 6, 6 => 8, _ => (int)t };
                    values[i] = ReadSignedBigEndian(record.AsSpan(d, len));
                    d += len;
                    break;
                case 7:
                    values[i] = BinaryPrimitives.ReadDoubleBigEndian(record.AsSpan(d));
                    d += 8;
                    break;
                case 8: values[i] = 0L; break;
                case 9: values[i] = 1L; break;
                case 10 or 11: values[i] = null; break;
                default:
                    int size = (int)((t - (t % 2 == 0 ? 12 : 13)) / 2);
                    var span = record.AsSpan(d, size);
                    values[i] = t % 2 == 0 ? span.ToArray() : DecodeText(span);
                    d += size;
                    break;
            }
        }
        return values;
    }

    public string DecodeText(ReadOnlySpan<byte> bytes) => TextEncoding switch
    {
        2 => Encoding.Unicode.GetString(bytes),
        3 => Encoding.BigEndianUnicode.GetString(bytes),
        _ => Encoding.UTF8.GetString(bytes),
    };

    static long ReadSignedBigEndian(ReadOnlySpan<byte> bytes)
    {
        long v = (sbyte)bytes[0];
        for (int i = 1; i < bytes.Length; i++) v = (v << 8) | bytes[i];
        return v;
    }

    static long ReadVarint(byte[] b, ref int p)
    {
        long v = 0;
        for (int i = 0; i < 8; i++)
        {
            byte x = b[p++];
            v = (v << 7) | (long)(x & 0x7f);
            if ((x & 0x80) == 0) return v;
        }
        return (v << 8) | b[p++];
    }
}

/// <summary>VS Code's key/value table in state.vscdb.</summary>
public static class StateDb
{
    public const string SessionIndexKey = "chat.ChatSessionStore.index";

    /// <summary>Returns the value for a key in ItemTable, or null when the key is absent.</summary>
    public static string? GetItem(SqliteFile db, string key)
    {
        var root = db.FindTable("ItemTable") ?? throw new InvalidDataException("ItemTable not found");
        string? value = null;
        foreach (var row in db.ReadTable(root))
            if (row.Length >= 2 && row[0] is string k && k == key)
                value = row[1] switch { string s => s, byte[] b => db.DecodeText(b), _ => null };
        return value;
    }
}
