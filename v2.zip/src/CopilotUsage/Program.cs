﻿using System.Reflection;
using System.Text;
using CopilotUsage;
using CopilotUsage.Cli;
using CopilotUsage.Commands;

Console.OutputEncoding = Encoding.UTF8;
// Hook payloads are UTF-8 JSON; Console.In would decode them with the console code page and keep a byte-order mark.
using var stdin = new StreamReader(Console.OpenStandardInput(), new UTF8Encoding(false), detectEncodingFromByteOrderMarks: true);
return Program.Run(args, Console.Out, Console.Error, stdin);

public partial class Program
{
    public static string Version =>
        typeof(Program).Assembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion.Split('+')[0] ?? "0.0.0";

    // Commands planned for later milestones; they answer with what is missing instead of failing silently.
    static readonly Dictionary<string, string> Planned = new();

    public static int Run(string[] args, TextWriter stdout, TextWriter stderr, TextReader? stdin = null)
    {
        if (args.Length == 0 || args[0] is "--help" or "-h" || (args[0] == "help" && args.Length == 1))
        {
            stdout.Write(Help);
            return ExitCodes.Ok;
        }
        // "help <command>" or "<command> --help": just that command's part of the help.
        var helpFor = args[0] == "help" ? args[1] : args.Skip(1).Any(a => a is "--help" or "-h") ? args[0] : null;
        if (helpFor is not null && CommandHelp(helpFor) is { } commandHelp)
        {
            stdout.Write(commandHelp);
            return ExitCodes.Ok;
        }
        if (args[0] is "--version" or "version")
        {
            stdout.WriteLine("copilot-usage " + Version);
            return ExitCodes.Ok;
        }

        // The hook never throws and never prints errors: the runtime treats a failing hook as a denial.
        if (args[0] == "hook") return HookCommand.Run(args.Skip(1), stdin ?? TextReader.Null, stdout, stderr);

        try
        {
            var rest = args.Skip(1);
            return args[0] switch
            {
                "doctor" => DoctorCommand.Run(CliArgs.Parse(rest), stdout),
                "probe" => ProbeCommand.Run(CliArgs.Parse(rest, "live"), stdout),
                "list" => ListCommand.Run(CliArgs.Parse(rest, "include-empty"), stdout),
                "hooks" => HooksCommand.Run(CliArgs.Parse(rest, "tool-sizes", "no-pre-tool", "skill"), stdout),
                "status" => StatusCommand.Run(CliArgs.Parse(rest, "json"), stdout),
                "phase" => PhaseCommand.Run(CliArgs.Parse(rest, "json"), stdout),
                "report" => ReportCommand.Run(CliArgs.Parse(rest, "open"), stdout),
                "compare" => CompareCommand.Run(CliArgs.Parse(rest, "open"), stdout),
                var c when Planned.TryGetValue(c, out var m) =>
                    throw new CliException($"'{c}' is planned for milestone {m} and not built yet"),
                var c => throw new CliException($"unknown command '{c}'. Run copilot-usage help"),
            };
        }
        catch (CliException e)
        {
            stderr.WriteLine("copilot-usage: " + e.Message);
            return e.ExitCode;
        }
    }

    /// <summary>The lines of <see cref="Help"/> that describe one command, or null for an unknown command.</summary>
    internal static string? CommandHelp(string command)
    {
        var lines = Help.Split('\n').Select(l => l.TrimEnd('\r')).ToArray();
        var picked = new List<string>();
        var prefix = "  copilot-usage " + command;
        for (int i = 0; i < lines.Length; i++)
        {
            var line = lines[i];
            if (!line.StartsWith(prefix, StringComparison.Ordinal) || (line.Length > prefix.Length && line[prefix.Length] != ' ')) continue;
            picked.Add(line);
            while (i + 1 < lines.Length && lines[i + 1].StartsWith("   ", StringComparison.Ordinal)) picked.Add(lines[++i]);
        }
        if (picked.Count == 0) return null;

        var text = new StringBuilder("Usage\n");
        foreach (var l in picked) text.Append(l).Append('\n');
        if (command is "status" or "phase")
            text.Append("\n  Exit codes: 0 ok, 2 budget exceeded, 3 session not identified, 4 no new log data yet.\n");
        if (picked.Any(l => l.Contains("<session>") || l.Contains("<A>")))
            text.Append("\n<session> is a list index (1 = newest), latest (default), a full or partial\n" +
                        "session ID, a session folder (debug log or session-state), or a workspace folder path.\n");
        if (picked.Any(l => l.Contains("--root")) || command is "list" or "report" or "compare" or "probe")
            text.Append("--root <vscode-user-dir> or --cli-root <copilot-home> limits the search to that folder.\n");
        return text.ToString();
    }

    const string Help = """
        copilot-usage — where a Copilot agent workflow spends its credits

        Usage
          copilot-usage doctor [--root <path>] [--cli-root <path>]
              Data folders for both harnesses, session counts, the debug-log setting, hooks.
          copilot-usage probe [<session>] [--dir <folder>] [--out <file>] [--live] [--pricing <file>]
              Checks one session against the expected format (P1–P19) and writes
              a fingerprint file (structure only, no content).
          copilot-usage list [--limit <n>] [--days <n>] [--folder <text>] [--include-empty] [--pricing <file>]
              Sessions newest first: last activity, start, status, harness, calls, credits, folder, title.
              Status is active when the session changed in the last 10 minutes.

          copilot-usage report [<session>] [--out <file>] [--open] [--pricing <file>] [--mcp-map <file>]
              Writes one self-contained HTML report: where the credits went, why, what grew the context,
              and what each MCP server cost. Default file: %LOCALAPPDATA%\copilot-usage\reports\<id>-<time>.html.
              --mcp-map <file>: JSON of tool-name patterns to MCP servers, e.g. {"jira_*": "jira"}, for tools
              whose names carry no server prefix (null marks a tool as not MCP).

          copilot-usage compare <A> <B> [--label-a <name>] [--label-b <name>] [--by agent|phase|skill|model]
                [--out <file>] [--open] [--mcp-map <file>]
              One HTML report: why run B cost more or less than run A (credit bridges, context curves, overhead,
              MCP servers).

        During a run (the agent calls these; at most 12 lines each)
          copilot-usage status [--budget <credits>] [--json] [--session <id>]
              Session total so far, current context size, cost of each agent run and phase.
          copilot-usage phase start <name> [--session <id>]
          copilot-usage phase end <name> [--budget <credits>] [--json] [--session <id>]
              Marks a phase and prints its cost: every call between start and end, all agents.
          Exit codes: 0 ok, 2 budget exceeded, 3 session not identified, 4 no new log data yet.

        Hooks
          copilot-usage hooks install [--scope repo|user] [--dir <folder>] [--soft-budget <credits>]
                [--hard-budget <credits>] [--on-error open|closed] [--tool-sizes] [--skill] [--no-pre-tool] [--exe <path>]
              Writes <repository>/.github/hooks/copilot-usage.json (repo, the default) or
              <copilot home>/hooks/copilot-usage.json (user).
              --dir <folder>: where to write: the repository (repo) or the Copilot home folder
              (user). Default: the git root of the current folder (repo), or ~/.copilot (user).
              --soft-budget: once the session total reaches it, the next tool call is blocked (once) and the
              agent is told to wrap up and ask the user. --hard-budget: ends the session.
              --on-error closed: a budget check that fails stops the session (default open: the call goes through).
              --skill also writes the workflow-cost skill; --tool-sizes records tool result lengths (postToolUse).
          copilot-usage hooks remove [--scope repo|user] [--dir <folder>]
          copilot-usage hook --event <name> [--soft-budget <credits>] [--hard-budget <credits>] [--on-error open|closed]
              Called by Copilot, not by people: records one hook event from stdin.

        Sessions come from both harnesses: Local (Copilot Chat debug logs in VS Code
        storage) and Copilot (agent host / Copilot CLI, ~/.copilot/session-state).
        --root <vscode-user-dir> or --cli-root <copilot-home> limits the search to that folder.

        <session> is a list index (1 = newest), latest (default), a full or partial
        session ID, a session folder (debug log or session-state), or a workspace folder path.

        Later (not in v1): CSV / MS SQL history export, a native Copilot tool (MCP server).

        """;
}
