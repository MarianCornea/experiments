using System.Text.Json;
using System.Text.Json.Nodes;
using CopilotUsage.Pricing;
using CopilotUsage.Storage;

namespace CopilotUsage.Probe;

/// <summary>
/// Probes a Copilot harness session (VS Code agent host / Copilot CLI): ~/.copilot/session-state/&lt;id&gt;/events.jsonl.
/// Same check IDs as the debug-log probe, mapped to this format, plus P19 (totals reconcile).
/// Records structure only: event types, data field names with kinds, string lengths, and safe names.
/// </summary>
public sealed class CliProber
{
    public const string ExpectedFrom = "Copilot CLI session-state as seen with copilot-agent 1.0.103 (2026-11-07)";
    const long LongContextTokens = 272_000;

    public static readonly IReadOnlySet<string> EnvelopeFields = new HashSet<string> { "type", "data", "id", "timestamp", "parentId", "agentId" };

    public static readonly IReadOnlySet<string> KnownTypes = new HashSet<string>
    {
        "session.start", "session.model_change", "session.auto_mode_resolved", "session.usage_record", "session.usage_checkpoint",
        "session.binary_asset", "user.message", "system.message", "system.notification", "assistant.turn_start", "assistant.message",
        "assistant.turn_end", "tool.execution_start", "tool.execution_complete", "external_tool.requested", "external_tool.completed",
        "subagent.started", "subagent.configured", "subagent.selected", "subagent.completed", "permission.requested",
        "permission.completed", "hook.start", "hook.end",
        // Seen first in a session that loaded a skill (2026-11-07).
        "skill.invoked", "skill.context_delivered_ref", "model.turn_started", "model.model_call_started",
        "model.captured_assignment_context", "model.model_call_success", "model.message", "model.response",
        "model.turn_ended", "model.messages_snapshot",
    };

    public static readonly IReadOnlySet<string> KnownUsageFields = new HashSet<string>
    {
        "model", "provider", "modelDisplayName", "inputTokens", "outputTokens", "cacheReadTokens", "cacheWriteTokens", "reasoningTokens",
        "cost", "duration", "timeToFirstTokenMs", "outputTtftMs", "cacheExpiresAt", "interTokenLatencyMs", "initiator", "interactionType",
        "isByok", "isAuto", "maxPromptTokens", "transport", "requestBodyBytes", "requestBodyWireBytes", "requestBodyEncoding", "apiCallId",
        "providerCallId", "serviceRequestId", "rte", "apiEndpoint", "accounting", "copilotUsage", "aiCreditsStatus", "reasoningEffort",
        "reasoningSummary", "availableToolCount", "toolTokenCount", "customToolCallCount", "unmatchedToolResultCount", "orphanToolCallCount",
        "frontierSource", "cacheTtlSeconds", "cachePolicyTtlSeconds", "cacheDetailsReported", "numToolCalls", "toolCounts", "finishReason",
        "contentFilterTriggered", "parentToolCallId",
    };

    /// <summary>String fields whose values are names or versions (never content), so they may be recorded.</summary>
    static readonly string[] SafeValuePaths =
    [
        "data.hookType", "data.usage.model", "data.usage.initiator", "data.usage.interactionType", "data.usage.aiCreditsStatus",
        "data.usage.finishReason", "data.toolName", "data.agentName", "data.agentType", "data.executionMode", "data.producer",
        "data.copilotVersion", "data.selectedModel", "data.chosenModel", "data.newModel", "data.model",
    ];

    static readonly IReadOnlySet<string> ShellTools = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "powershell", "bash", "shell", "sh", "cmd", "zsh" };

    readonly ProbeOptions _options;
    readonly SortedDictionary<string, TypeStat> _types = new(StringComparer.Ordinal);
    readonly SortedDictionary<string, FieldStat> _usageFields = new(StringComparer.Ordinal);
    readonly SortedDictionary<string, SortedDictionary<string, int>> _names = new(StringComparer.Ordinal);
    readonly SortedDictionary<string, int> _models = new(StringComparer.Ordinal);
    readonly SortedSet<string> _hookTypes = new(StringComparer.Ordinal);
    readonly SortedSet<string> _agentNames = new(StringComparer.Ordinal);

    int _lines, _badLines;
    int _usage, _usageWithTokens, _usageWithCacheRead, _usageWithCacheWrite, _usageWithNano, _usageByAgent, _usageLong, _usageIncomplete;
    long _peakInput, _sumNano, _sumNanoAtCheckpoint = -1, _checkpointNano = -1;
    int _toolStarts, _toolNamed, _toolCompletes, _toolWithTokenCount, _shellCalls, _shellWithCommand, _usageCommandCalls;
    int _subStarted, _subCompleted, _checkpoints, _hookWithSession, _hookSessionMatch, _postToolUseWithResult;
    string? _sessionStartId, _copilotVersion;
    DateTimeOffset? _first, _last, _lastUsage;

    CliProber(ProbeOptions options) => _options = options;

    public static ProbeResult Run(CliSession session, ProbeOptions options) => new CliProber(options).Probe(session);

    ProbeResult Probe(CliSession session)
    {
        bool hasEvents = File.Exists(session.EventsFile);
        long bytes = hasEvents ? new FileInfo(session.EventsFile).Length : 0;
        if (hasEvents)
        {
            try
            {
                foreach (var line in SafeFile.ReadLines(session.EventsFile))
                {
                    if (line.Length == 0) continue;
                    _lines++;
                    if (!ScanLine(line)) _badLines++;
                }
            }
            catch (Exception e) when (e is IOException or UnauthorizedAccessException) { _badLines++; }
        }

        var checks = new List<ProbeCheck>
        {
            hasEvents
                ? Pass("P1", "Session folder", $"events.jsonl found ({Prober.FormatBytes(bytes)}, {_lines:N0} lines, {_badLines} bad){(session.Active ? "; session is open" : "")}")
                : Fail("P1", "Session folder", "events.jsonl not found: this folder is not a Copilot session"),
            _usage > 0
                ? Pass("P2", "Model calls", $"{_usage:N0} session.usage_record events")
                : Fail("P2", "Model calls", "no session.usage_record events: no cost data"),
        };

        double tokenShare = Share(_usageWithTokens, _usage);
        checks.Add(_usage > 0 && tokenShare >= 0.9
            ? Pass("P3", "Token fields", $"inputTokens and outputTokens are numbers on {tokenShare:P0} of calls")
            : Fail("P3", "Token fields", _usage == 0 ? "no model calls to check" : $"token numbers on only {tokenShare:P0} of calls: cost cannot be computed"));

        double cacheShare = Share(_usageWithCacheRead, _usage);
        checks.Add(cacheShare >= 0.9
            ? Pass("P4", "Cache field", $"cacheReadTokens on {cacheShare:P0} of calls, cacheWriteTokens on {Share(_usageWithCacheWrite, _usage):P0}")
            : Warn("P4", "Cache field", $"cacheReadTokens on {cacheShare:P0} of calls: cache analysis limited"));

        double nanoShare = Share(_usageWithNano, _usage);
        checks.Add(nanoShare >= 0.9
            ? Pass("P5", "Billed cost", $"copilotUsage.totalNanoAiu on {nanoShare:P0} of calls ({_sumNano / 1e9:N2} credits)" + (_usageIncomplete > 0 ? $"; {_usageIncomplete} not marked complete" : ""))
            : Warn("P5", "Billed cost", $"copilotUsage.totalNanoAiu on {nanoShare:P0} of calls: credits are estimated for the rest"));

        checks.Add(ModelCheck());

        checks.Add(_subStarted == 0
            ? Info("P7", "Sub-agents", "no sub-agents ran in this session")
            : _usageByAgent > 0
                ? Pass("P7", "Sub-agents", $"{_subStarted} sub-agent runs ({_subCompleted} completed), {_usageByAgent} of {_usage} calls carry an agentId: {string.Join(", ", _agentNames.Take(8))}")
                : Warn("P7", "Sub-agents", $"{_subStarted} sub-agent runs, but no model call carries an agentId: sub-agent cost cannot be split"));

        checks.Add(_toolStarts == 0
            ? Warn("P8", "Tool calls", "no tool.execution_start events: no context-growth attribution")
            : _toolNamed == _toolStarts
                ? Pass("P8", "Tool calls", $"{_toolStarts:N0} tool calls, all named")
                : Warn("P8", "Tool calls", $"{_toolStarts - _toolNamed} of {_toolStarts} tool calls have no name"));

        double sizeShare = Share(_toolWithTokenCount, _toolCompletes);
        checks.Add(_toolWithTokenCount > 0
            ? Pass("P9", "Tool sizes", $"result_token_count measured on {sizeShare:P0} of {_toolCompletes} completed tool calls")
            : Info("P9", "Tool sizes", "no result_token_count on tool completions: growth stays inferred"));

        checks.Add(session.Title is not null
            ? Pass("P10", "Titles", "session name found in workspace.yaml")
            : Info("P10", "Titles", "no name in workspace.yaml: list shows session IDs"));

        var (unknownCheck, unknownJson) = UnknownCheck();
        checks.Add(unknownCheck);

        checks.Add(_usageCommandCalls > 0
            ? Pass("P12", "Tool arguments", $"{_usageCommandCalls} logged shell call(s) to copilot-usage found")
            : _shellWithCommand > 0
                ? Pass("P12", "Tool arguments", $"shell tool calls carry their command line ({_shellWithCommand} of {_shellCalls})")
                : _shellCalls > 0
                    ? Warn("P12", "Tool arguments", "shell tool calls have no command logged: fallback commands rely on folder matching")
                    : Skip("P12", "Tool arguments", "no shell tool calls in this session"));

        checks.Add(_options.Live ? WriteDelayCheck(session) : Skip("P13", "Write delay", "run with --live from the agent's terminal inside the session"));

        var hooks = string.Join(", ", _hookTypes.Take(10));
        checks.Add(_hookTypes.Contains("sessionStart") && _hookTypes.Contains("agentStop")
            ? Pass("P14", "Hooks fire", $"hook events: {hooks}")
            : _hookTypes.Count > 0
                ? Warn("P14", "Hooks fire", $"sessionStart and agentStop not both seen (seen: {hooks})")
                : Warn("P14", "Hooks fire", "no hook events: hooks disabled or unsupported; use the agent-driven fallback"));

        checks.Add(_hookSessionMatch > 0
            ? Pass("P15", "Session match", $"hook sessionId equals the session folder name ({_hookSessionMatch} of {_hookWithSession} hook inputs; the rest belong to sub-agents)")
            : _hookWithSession > 0
                ? Warn("P15", "Session match", "hook sessionId never equals the session folder name: match by folder and time")
                : Skip("P15", "Session match", "no hook inputs with a sessionId"));

        checks.Add(_postToolUseWithResult > 0
            ? Pass("P16", "Tool result size", $"postToolUse hooks carry the tool result ({_postToolUseWithResult} events); sizes are measured")
            : Info("P16", "Tool result size", "no postToolUse hook results: growth per tool relies on result_token_count (P9)"));

        var parsed = Logs.CliSessionParser.Parse(session);
        checks.Add(SharedChecks.BudgetStops(parsed, _options.EventsDir));
        checks.Add(SharedChecks.McpTools(parsed));
        checks.Add(TotalsCheck());

        var fingerprint = BuildFingerprint(session, bytes, checks, unknownJson);
        return new ProbeResult
        {
            Session = session,
            Checks = checks,
            Fingerprint = fingerprint,
            CopilotVersion = _copilotVersion,
            Title = session.Title,
            FilesSummary = string.Join(", ", SessionCatalog.SafeEnumerateFiles(session.Dir).Select(Path.GetFileName)
                .Where(n => n is not null && !n.StartsWith("inuse.", StringComparison.OrdinalIgnoreCase)).Order()) +
                (Directory.Exists(Path.Combine(session.Dir, "checkpoints")) ? ", checkpoints/" : ""),
        };
    }

    // ---------- scanning ----------

    internal bool ScanLine(string line)
    {
        JsonDocument doc;
        try { doc = JsonDocument.Parse(line); }
        catch (JsonException) { return false; }
        using (doc)
        {
            var e = doc.RootElement;
            if (e.ValueKind != JsonValueKind.Object) return false;
            string type = Str(e, "type") ?? "<missing>";
            if (!_types.TryGetValue(type, out var ts)) _types[type] = ts = new TypeStat();
            ts.Count++;
            foreach (var p in e.EnumerateObject()) Record(ts.Envelope, p.Name, p.Value);

            var data = e.TryGetProperty("data", out var d) && d.ValueKind == JsonValueKind.Object ? d : default;
            if (data.ValueKind == JsonValueKind.Object)
                foreach (var p in data.EnumerateObject()) Record(ts.Attrs, p.Name, p.Value);

            foreach (var path in SafeValuePaths)
                if (At(e, path) is { ValueKind: JsonValueKind.String } v && v.GetString() is { Length: > 0 and <= 120 } name)
                {
                    if (!_names.TryGetValue(path, out var counts)) _names[path] = counts = new SortedDictionary<string, int>(StringComparer.Ordinal);
                    if (counts.Count < 50 || counts.ContainsKey(name)) Increment(counts, name);
                }

            if (Str(e, "timestamp") is { } stamp && DateTimeOffset.TryParse(stamp, out var at))
            {
                _first = _first is null || at < _first ? at : _first;
                _last = _last is null || at > _last ? at : _last;
                if (type == "session.usage_record") _lastUsage = at;
            }

            switch (type)
            {
                case "session.start":
                    _sessionStartId = Str(data, "sessionId");
                    _copilotVersion = Str(data, "copilotVersion");
                    break;
                case "session.usage_record": ScanUsage(e, data); break;
                case "session.usage_checkpoint":
                    _checkpoints++;
                    if (Num(data, "totalNanoAiu") is long total) { _checkpointNano = total; _sumNanoAtCheckpoint = _sumNano; }
                    break;
                case "tool.execution_start": ScanToolStart(data); break;
                case "tool.execution_complete":
                    _toolCompletes++;
                    if (At(data, "toolTelemetry.metrics.result_token_count") is { ValueKind: JsonValueKind.Number }) _toolWithTokenCount++;
                    break;
                case "subagent.started":
                    _subStarted++;
                    if (Str(data, "agentName") is { } agent) _agentNames.Add(agent);
                    break;
                case "subagent.completed": _subCompleted++; break;
                case "hook.start": ScanHook(data); break;
            }
        }
        return true;
    }

    void ScanUsage(JsonElement e, JsonElement data)
    {
        _usage++;
        var u = data.ValueKind == JsonValueKind.Object && data.TryGetProperty("usage", out var x) && x.ValueKind == JsonValueKind.Object ? x : default;
        if (u.ValueKind != JsonValueKind.Object) return;
        foreach (var p in u.EnumerateObject()) Record(_usageFields, p.Name, p.Value);

        long? input = Num(u, "inputTokens");
        if (input is not null && Num(u, "outputTokens") is not null) _usageWithTokens++;
        if (Num(u, "cacheReadTokens") is not null) _usageWithCacheRead++;
        if (Num(u, "cacheWriteTokens") is not null) _usageWithCacheWrite++;
        if (Num(At(u, "copilotUsage"), "totalNanoAiu") is long nano) { _usageWithNano++; _sumNano += nano; }
        if (Str(u, "aiCreditsStatus") is { } status && status != "complete") _usageIncomplete++;
        if (Str(u, "model") is { } model) Increment(_models, model);
        if (Str(e, "agentId") is { Length: > 0 }) _usageByAgent++;
        if (input is long i)
        {
            _peakInput = Math.Max(_peakInput, i);
            if (i > LongContextTokens) _usageLong++;
        }
    }

    void ScanToolStart(JsonElement data)
    {
        _toolStarts++;
        var name = Str(data, "toolName");
        if (string.IsNullOrEmpty(name)) return;
        _toolNamed++;
        if (!ShellTools.Contains(name)) return;
        _shellCalls++;
        if (Str(At(data, "arguments"), "command") is { } command)
        {
            _shellWithCommand++;
            if (Tracking.UsageCommands.IsInvocation(command)) _usageCommandCalls++;
        }
    }

    void ScanHook(JsonElement data)
    {
        var hookType = Str(data, "hookType");
        if (hookType is not null) _hookTypes.Add(hookType);
        var input = At(data, "input");
        if (Str(input, "sessionId") is { } sid)
        {
            _hookWithSession++;
            if (sid == _sessionStartId) _hookSessionMatch++;
        }
        if (hookType == "postToolUse" && input.ValueKind == JsonValueKind.Object && input.TryGetProperty("toolResult", out _))
            _postToolUseWithResult++;
    }

    static void Record(SortedDictionary<string, FieldStat> stats, string name, JsonElement value)
    {
        if (!stats.TryGetValue(name, out var s)) stats[name] = s = new FieldStat();
        s.Count++;
        Increment(s.Kinds, Kind(value));
        if (value.ValueKind == JsonValueKind.String) s.MaxLength = Math.Max(s.MaxLength, value.GetString()?.Length ?? 0);
    }

    // ---------- checks ----------

    ProbeCheck ModelCheck()
    {
        if (_models.Count == 0) return Warn("P6", "Model name", "no usage.model on usage records: estimates are missing");
        var unpriced = _models.Keys.Where(m => _options.Pricing.Match(m).Kind == PriceMatch.Unpriced).ToList();
        var models = string.Join(", ", _models.Select(m => $"{m.Key} ({m.Value})"));
        return unpriced.Count == 0
            ? Pass("P6", "Model name", $"all models priced: {models}")
            : Warn("P6", "Model name", $"not in pricing.json: {string.Join(", ", unpriced)} — billed credits still work; estimates and the long-context premium do not. Models: {models}");
    }

    ProbeCheck TotalsCheck()
    {
        if (_checkpoints == 0 || _checkpointNano < 0)
            return Info("P19", "Totals reconcile", "no session.usage_checkpoint yet: cannot compare per-call credits with Copilot's session total");
        double diff = _checkpointNano == 0 ? (_sumNanoAtCheckpoint == 0 ? 0 : 1) : Math.Abs(_sumNanoAtCheckpoint - _checkpointNano) / (double)_checkpointNano;
        var detail = $"per-call sum {_sumNanoAtCheckpoint / 1e9:N4} vs checkpoint total {_checkpointNano / 1e9:N4} credits";
        return diff <= 0.01
            ? Pass("P19", "Totals reconcile", detail + " (match)")
            : Warn("P19", "Totals reconcile", detail + $" ({diff:P1} apart): some calls may be missing or counted elsewhere");
    }

    (ProbeCheck, JsonObject) UnknownCheck()
    {
        var types = _types.Keys.Where(t => !KnownTypes.Contains(t)).ToList();
        var fields = _types.SelectMany(t => t.Value.Envelope.Keys.Where(f => !EnvelopeFields.Contains(f)).Select(f => $"{t.Key}.{f}"))
            .Concat(_usageFields.Keys.Where(f => !KnownUsageFields.Contains(f)).Select(f => $"session.usage_record.data.usage.{f}"))
            .ToList();
        var json = new JsonObject
        {
            ["eventTypes"] = new JsonArray(types.Select(t => (JsonNode)t).ToArray()),
            ["fields"] = new JsonArray(fields.Select(f => (JsonNode)f).ToArray()),
        };
        if (types.Count + fields.Count == 0)
            return (Pass("P11", "Unknown", "every event type, envelope field and usage field is in the expected set"), json);
        var parts = new List<string>();
        if (types.Count > 0) parts.Add("types: " + string.Join(", ", types.Take(6)));
        if (fields.Count > 0) parts.Add("fields: " + string.Join(", ", fields.Take(6)));
        return (Info("P11", "Unknown", string.Join("; ", parts) + " — listed in the fingerprint for review"), json);
    }

    ProbeCheck WriteDelayCheck(CliSession session)
    {
        var now = DateTimeOffset.UtcNow;
        if (_lastUsage is { } last && (now - last).TotalSeconds is >= 0 and <= 10)
            return Pass("P13", "Write delay", $"the latest model call was on disk at most {(now - last).TotalSeconds:N1} s after it was recorded");

        long offset = File.Exists(session.EventsFile) ? new FileInfo(session.EventsFile).Length : 0;
        var deadline = DateTime.UtcNow + _options.LiveWait;
        var lines = new List<string>();
        while (DateTime.UtcNow < deadline)
        {
            Thread.Sleep(500);
            lines.Clear();
            offset = SafeFile.ReadNewLines(session.EventsFile, offset, lines);
            var seen = DateTimeOffset.UtcNow;
            foreach (var line in lines)
            {
                try
                {
                    using var doc = JsonDocument.Parse(line);
                    if (Str(doc.RootElement, "type") != "session.usage_record" || Str(doc.RootElement, "timestamp") is not { } stamp ||
                        !DateTimeOffset.TryParse(stamp, out var at)) continue;
                    double delay = (seen - at).TotalSeconds;
                    return delay <= 10
                        ? Pass("P13", "Write delay", $"a model call reached the log {delay:N1} s after it was recorded")
                        : Warn("P13", "Write delay", $"a model call reached the log {delay:N1} s late: totals lag");
                }
                catch (JsonException) { }
            }
        }
        return Warn("P13", "Write delay", $"no new model call reached the log within {_options.LiveWait.TotalSeconds:N0} s");
    }

    // ---------- fingerprint ----------

    JsonObject BuildFingerprint(CliSession session, long bytes, List<ProbeCheck> checks, JsonObject unknown)
    {
        var events = new JsonObject();
        foreach (var (type, t) in _types)
        {
            var envelope = new JsonObject();
            foreach (var (k, v) in t.Envelope) envelope[k] = v.ToJson();
            var data = new JsonObject();
            foreach (var (k, v) in t.Attrs) data[k] = v.ToJson();
            events[type] = new JsonObject { ["count"] = t.Count, ["envelope"] = envelope, ["data"] = data };
        }
        var usage = new JsonObject();
        foreach (var (k, v) in _usageFields) usage[k] = v.ToJson();
        var names = new JsonObject();
        foreach (var (k, v) in _names) names[k] = FieldStat.ToJson(v);
        var checkArray = new JsonArray();
        foreach (var c in checks)
            checkArray.Add(new JsonObject { ["id"] = c.Id, ["name"] = c.Name, ["outcome"] = c.Outcome.ToString().ToLowerInvariant(), ["detail"] = c.Detail });

        return new JsonObject
        {
            ["fingerprintVersion"] = 1,
            ["tool"] = "copilot-usage " + Program.Version,
            ["probedAt"] = DateTimeOffset.UtcNow.ToString("o"),
            ["source"] = "copilot-cli-session-state",
            ["expectedFormat"] = ExpectedFrom,
            ["session"] = new JsonObject
            {
                ["id"] = session.Id,
                ["active"] = session.Active,
                ["firstEvent"] = _first?.ToString("o"),
                ["lastEvent"] = _last?.ToString("o"),
                ["startIdMatchesFolder"] = _sessionStartId == session.Id,
            },
            ["copilot"] = new JsonObject { ["copilotVersion"] = _copilotVersion },
            ["file"] = new JsonObject { ["bytes"] = bytes, ["lines"] = _lines, ["badLines"] = _badLines },
            ["events"] = events,
            ["usageFields"] = usage,
            ["usage"] = new JsonObject
            {
                ["records"] = _usage, ["withTokens"] = _usageWithTokens, ["withCacheRead"] = _usageWithCacheRead,
                ["withCacheWrite"] = _usageWithCacheWrite, ["withNanoAiu"] = _usageWithNano, ["byAgent"] = _usageByAgent,
                ["notComplete"] = _usageIncomplete, ["overLongContext"] = _usageLong, ["peakInputTokens"] = _peakInput,
                ["sumNanoAiu"] = _sumNano, ["checkpoints"] = _checkpoints, ["checkpointNanoAiu"] = _checkpointNano,
                ["models"] = FieldStat.ToJson(_models),
            },
            ["tools"] = new JsonObject
            {
                ["starts"] = _toolStarts, ["completes"] = _toolCompletes, ["withResultTokenCount"] = _toolWithTokenCount,
                ["shell"] = _shellCalls, ["shellWithCommand"] = _shellWithCommand,
            },
            ["subagents"] = new JsonObject { ["started"] = _subStarted, ["completed"] = _subCompleted },
            ["names"] = names,
            ["unknown"] = unknown,
            ["checks"] = checkArray,
        };
    }

    // ---------- helpers ----------

    static JsonElement At(JsonElement e, string dotted)
    {
        foreach (var part in dotted.Split('.'))
        {
            if (e.ValueKind != JsonValueKind.Object || !e.TryGetProperty(part, out e)) return default;
        }
        return e;
    }

    static string Kind(JsonElement e) => e.ValueKind switch
    {
        JsonValueKind.String => "string",
        JsonValueKind.Number => "number",
        JsonValueKind.Object => "object",
        JsonValueKind.Array => "array",
        JsonValueKind.True or JsonValueKind.False => "boolean",
        JsonValueKind.Null => "null",
        _ => "undefined",
    };

    static string? Str(JsonElement e, string name) =>
        e.ValueKind == JsonValueKind.Object && e.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;

    static long? Num(JsonElement e, string name)
    {
        if (e.ValueKind != JsonValueKind.Object || !e.TryGetProperty(name, out var v) || v.ValueKind != JsonValueKind.Number) return null;
        return v.TryGetInt64(out var l) ? l : (long)v.GetDouble();
    }

    static void Increment(IDictionary<string, int> d, string key) => d[key] = d.TryGetValue(key, out var n) ? n + 1 : 1;
    static double Share(int part, int whole) => whole == 0 ? 0 : (double)part / whole;

    static ProbeCheck Pass(string id, string name, string detail) => new(id, name, CheckOutcome.Pass, detail);
    static ProbeCheck Warn(string id, string name, string detail) => new(id, name, CheckOutcome.Warn, detail);
    static ProbeCheck Fail(string id, string name, string detail) => new(id, name, CheckOutcome.Fail, detail);
    static ProbeCheck Info(string id, string name, string detail) => new(id, name, CheckOutcome.Info, detail);
    static ProbeCheck Skip(string id, string name, string detail) => new(id, name, CheckOutcome.Skip, detail);
}
