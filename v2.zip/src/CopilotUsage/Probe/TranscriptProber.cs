using System.Text.Json;
using System.Text.Json.Nodes;
using CopilotUsage.Logs;
using CopilotUsage.Pricing;
using CopilotUsage.Storage;

namespace CopilotUsage.Probe;

/// <summary>
/// Probes a VS Code chat transcript (chatSessions/&lt;id&gt;.jsonl). P1–P3 are the gate: the operation log replays,
/// requests have times, and completed requests carry billed credits. Records structure only: operation kinds,
/// request field names with kinds and lengths, response part kinds, and safe names (models, tools, agents).
/// </summary>
public static class TranscriptProber
{
    public const string ExpectedFrom = "VS Code 1.132 chat transcript (chatSessions/*.jsonl), Copilot Chat 0.73 (2026-11-07)";

    static readonly IReadOnlySet<string> KnownOperations = new HashSet<string> { "kind 0", "kind 1", "kind 2", "kind 3" };

    public static ProbeResult Run(TranscriptSession session, ProbeOptions options)
    {
        var replayed = ChatTranscript.Replay(session.File);
        var state = replayed.State;
        var requests = ChatTranscript.Arr(state, "requests")?.OfType<JsonObject>().ToList() ?? [];
        var checks = new List<ProbeCheck>();

        // P1: the file is an operation log that starts with the whole state.
        checks.Add(replayed.StartsWithState && state is not null
            ? new ProbeCheck("P1", "Operation log", CheckOutcome.Pass, $"{replayed.Lines} operations replayed ({Counts(replayed.Operations)})")
            : new ProbeCheck("P1", "Operation log", CheckOutcome.Fail, state is null ? "no full state (kind 0) found" : "the first line is not the full state (kind 0)"));

        // P2: requests with times.
        int timed = requests.Count(r => ChatTranscript.Num(r, "timestamp") is not null);
        checks.Add(requests.Count > 0 && timed == requests.Count
            ? new ProbeCheck("P2", "Requests", CheckOutcome.Pass, $"{requests.Count} requests, all with a timestamp")
            : new ProbeCheck("P2", "Requests", CheckOutcome.Fail, requests.Count == 0 ? "no requests" : $"{requests.Count - timed} of {requests.Count} requests have no timestamp"));

        // P3: every completed request carries Copilot's billed credits (copilotCredits = Σ total_nano_aiu / 1e9).
        var completed = requests.Where(r => r["result"] is JsonObject res && res["errorDetails"] is null).ToList();
        int billed = completed.Count(r => ChatTranscript.Num(r, "copilotCredits") is not null);
        double credits = requests.Sum(r => ChatTranscript.Num(r, "copilotCredits") ?? 0);
        checks.Add(completed.Count > 0 && billed == completed.Count
            ? new ProbeCheck("P3", "Billed credits", CheckOutcome.Pass, $"{billed} of {completed.Count} completed requests: {credits:0.######} credits")
            : new ProbeCheck("P3", "Billed credits", CheckOutcome.Fail,
                completed.Count == 0 ? "no completed requests" : $"{completed.Count - billed} of {completed.Count} completed requests have no copilotCredits"));

        // P4: the state's session ID is the file name.
        var stateId = ChatTranscript.Str(state, "sessionId");
        checks.Add(stateId is not null && stateId.Equals(session.Id, StringComparison.OrdinalIgnoreCase)
            ? new ProbeCheck("P4", "Session ID", CheckOutcome.Pass, "sessionId equals the file name")
            : new ProbeCheck("P4", "Session ID", CheckOutcome.Warn, stateId is null ? "no sessionId in the state" : "sessionId differs from the file name"));

        // P5: tokens of the last model call in each request.
        int withTokens = completed.Count(r => ChatTranscript.Num(r, "promptTokens") is not null && ChatTranscript.Num(r, "completionTokens") is not null);
        checks.Add(new ProbeCheck("P5", "Request tokens", withTokens == completed.Count && completed.Count > 0 ? CheckOutcome.Pass : CheckOutcome.Warn,
            $"{withTokens} of {completed.Count} completed requests have promptTokens and completionTokens (last call's prompt, request output)"));

        // P6: models, for display; credits are billed either way.
        var models = requests.Select(r => ChatTranscript.Str(r["result"]?["metadata"], "resolvedModel")).Where(m => m is not null).Distinct().ToList();
        var unpriced = models.Where(m => options.Pricing.Match(m!).Kind == PriceMatch.Unpriced).ToList();
        checks.Add(models.Count == 0
            ? new ProbeCheck("P6", "Model name", CheckOutcome.Warn, "no resolvedModel on any request")
            : new ProbeCheck("P6", "Model name", unpriced.Count == 0 ? CheckOutcome.Pass : CheckOutcome.Warn,
                (unpriced.Count == 0 ? "all models priced: " : "not in pricing.json (credits are billed, so totals are unaffected): ") + string.Join(", ", unpriced.Count == 0 ? models : unpriced)));

        // P7: sub-agent runs carry their own credits, which never exceed the request's.
        var subs = requests.SelectMany(r => (ChatTranscript.Arr(r, "response")?.OfType<JsonObject>() ?? [])
            .Where(p => ChatTranscript.Str(p["toolSpecificData"], "kind") == "subagent").Select(p => (Request: r, Part: p))).ToList();
        int subsWithCredits = subs.Count(s => ChatTranscript.Num(s.Part["toolSpecificData"], "credits") is not null);
        bool subsFit = requests.All(r => (ChatTranscript.Arr(r, "response")?.OfType<JsonObject>() ?? [])
            .Where(p => ChatTranscript.Str(p["toolSpecificData"], "kind") == "subagent").Sum(p => ChatTranscript.Num(p["toolSpecificData"], "credits") ?? 0)
            <= (ChatTranscript.Num(r, "copilotCredits") ?? double.MaxValue) + 1e-9);
        checks.Add(subs.Count == 0
            ? new ProbeCheck("P7", "Sub-agent credits", CheckOutcome.Info, "no sub-agent runs")
            : new ProbeCheck("P7", "Sub-agent credits", subsWithCredits == subs.Count && subsFit ? CheckOutcome.Pass : CheckOutcome.Warn,
                $"{subsWithCredits} of {subs.Count} sub-agent runs have credits; {(subsFit ? "each request's total includes them" : "some exceed their request's total")}"));

        // P8: operation kinds the tool knows, and lines that could not be applied (skipped and counted).
        var unknown = replayed.UnknownOperations.Where(k => !KnownOperations.Contains(k)).ToList();
        var problems = new List<string>();
        if (unknown.Count > 0) problems.Add("unknown: " + string.Join(", ", unknown));
        if (replayed.BadLines > 0) problems.Add($"{replayed.BadLines} of {replayed.Lines} lines could not be applied (skipped)");
        checks.Add(new ProbeCheck("P8", "Operations", problems.Count == 0 ? CheckOutcome.Pass : CheckOutcome.Warn,
            problems.Count == 0 ? "only kinds 0–3, every line applied" : string.Join("; ", problems)));

        // P9: why the transcript is used: the chat's debug log, if any, has no model calls.
        var debugDir = FindDebugLog(session);
        checks.Add(debugDir is null
            ? new ProbeCheck("P9", "Debug log", CheckOutcome.Info, "no debug log for this chat: the transcript is the only source")
            : TranscriptCatalog.HasModelCalls(debugDir)
                ? new ProbeCheck("P9", "Debug log", CheckOutcome.Info, "the debug log has model calls; reports use it, with per-call detail")
                : new ProbeCheck("P9", "Debug log", CheckOutcome.Info, "the debug log has no model calls: the transcript is the only source"));

        var parsed = TranscriptParser.Parse(session);
        checks.Add(SharedChecks.BudgetStops(parsed, options.EventsDir));
        checks.Add(SharedChecks.McpTools(parsed));

        return new ProbeResult
        {
            Session = session,
            Checks = checks,
            Fingerprint = Fingerprint(session, replayed, requests, checks),
            Title = ChatTranscript.Str(state, "customTitle"),
            FilesSummary = $"{Path.GetFileName(session.File)} ({new FileInfo(session.File).Length:N0} bytes)",
        };
    }

    static string? FindDebugLog(TranscriptSession session)
    {
        if (session.WorkspaceStorageDir is null) return null;
        foreach (var ext in SessionCatalog.ExtensionFolders)
        {
            var dir = Path.Combine(session.WorkspaceStorageDir, ext, SessionCatalog.DebugLogsFolder, session.Id);
            if (Directory.Exists(dir)) return dir;
        }
        return null;
    }

    static string Counts(IDictionary<string, int> d) => string.Join(", ", d.Select(kv => $"{kv.Key}: {kv.Value}"));

    /// <summary>Structure only: field names with JSON kinds and maximum string lengths, and names that are safe to keep.</summary>
    static JsonObject Fingerprint(TranscriptSession session, ChatTranscript.Replayed replayed, List<JsonObject> requests, List<ProbeCheck> checks)
    {
        var requestFields = new SortedDictionary<string, FieldStat>(StringComparer.Ordinal);
        var metaFields = new SortedDictionary<string, FieldStat>(StringComparer.Ordinal);
        var partKinds = new SortedDictionary<string, int>(StringComparer.Ordinal);
        var tools = new SortedDictionary<string, int>(StringComparer.Ordinal);
        var agents = new SortedDictionary<string, int>(StringComparer.Ordinal);
        var models = new SortedDictionary<string, int>(StringComparer.Ordinal);
        foreach (var r in requests)
        {
            Collect(r, requestFields);
            if (r["result"]?["metadata"] is JsonObject meta) Collect(meta, metaFields);
            if (ChatTranscript.Str(r["result"]?["metadata"], "resolvedModel") is { } m) Bump(models, m);
            foreach (var p in ChatTranscript.Arr(r, "response")?.OfType<JsonObject>() ?? [])
            {
                Bump(partKinds, ChatTranscript.Str(p, "kind") ?? "(markdown)");
                if (ChatTranscript.Str(p, "toolId") is { } tool) Bump(tools, tool);
                if (ChatTranscript.Str(p["toolSpecificData"], "agentName") is { } agent) Bump(agents, agent);
            }
        }
        var checksJson = new JsonArray();
        foreach (var c in checks) checksJson.Add(new JsonObject { ["id"] = c.Id, ["outcome"] = c.Outcome.ToString(), ["detail"] = c.Detail });
        return new JsonObject
        {
            ["tool"] = "copilot-usage " + Program.Version,
            ["source"] = session.SourceLabel,
            ["expectedFrom"] = ExpectedFrom,
            ["file"] = new JsonObject { ["name"] = "<session>.jsonl", ["bytes"] = new FileInfo(session.File).Length, ["lines"] = replayed.Lines, ["badLines"] = replayed.BadLines },
            ["operations"] = FieldStat.ToJson(replayed.Operations),
            ["requests"] = requests.Count,
            ["requestFields"] = ToJson(requestFields),
            ["resultMetadataFields"] = ToJson(metaFields),
            ["responsePartKinds"] = FieldStat.ToJson(partKinds),
            ["tools"] = FieldStat.ToJson(tools),
            ["subAgents"] = FieldStat.ToJson(agents),
            ["models"] = FieldStat.ToJson(models),
            ["checks"] = checksJson,
        };
    }

    static void Collect(JsonObject o, SortedDictionary<string, FieldStat> fields)
    {
        foreach (var (name, value) in o)
        {
            if (!fields.TryGetValue(name, out var f)) fields[name] = f = new FieldStat();
            f.Count++;
            var kind = value is null ? "null" : value.GetValueKind().ToString().ToLowerInvariant();
            f.Kinds[kind] = f.Kinds.GetValueOrDefault(kind) + 1;
            if (value is JsonValue v && v.GetValueKind() == JsonValueKind.String) f.MaxLength = Math.Max(f.MaxLength, v.GetValue<string>().Length);
        }
    }

    static void Bump(SortedDictionary<string, int> d, string key) => d[key] = d.GetValueOrDefault(key) + 1;

    static JsonObject ToJson(SortedDictionary<string, FieldStat> fields)
    {
        var o = new JsonObject();
        foreach (var (k, v) in fields) o[k] = v.ToJson();
        return o;
    }
}
