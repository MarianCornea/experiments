using System.Text.Json;
using System.Text.Json.Nodes;
using CopilotUsage.Logs;
using CopilotUsage.Pricing;
using CopilotUsage.Sqlite;
using CopilotUsage.Storage;

namespace CopilotUsage.Probe;

/// <summary>
/// Checks one session against the expected debug-log format (FR-02). Reads structure only:
/// file patterns, event types, attribute names with JSON kinds, and string lengths.
/// Content is never kept beyond the line being parsed.
/// </summary>
public sealed class Prober
{
    const long LongContextTokens = 272_000;
    const long TruncationWarnBytes = 90L * 1024 * 1024; // Copilot cuts a log above 100 MB by default

    readonly ProbeOptions _options;
    readonly SortedDictionary<string, FileStat> _files = new(StringComparer.Ordinal);
    readonly SortedDictionary<string, TypeStat> _types = new(StringComparer.Ordinal);
    readonly SortedDictionary<string, int> _models = new(StringComparer.Ordinal);
    readonly SortedSet<string> _hookNames = new(StringComparer.OrdinalIgnoreCase);
    readonly SortedSet<string> _subagentNames = new(StringComparer.Ordinal);

    int _llmTotal, _llmOk, _llmWithTokens, _llmWithCached, _llmWithNano, _llmLong;
    long _peakInput;
    int _toolTotal, _toolNamed, _toolSubagentCalls, _terminalCalls, _terminalWithArgs, _usageCommandCalls, _toolWithResult, _toolMaxResult;
    int _childRefs, _subagentEvents, _childFiles;
    bool _resumed;
    long _firstTs = long.MaxValue, _lastTs = long.MinValue, _lastLlmEnd = long.MinValue;
    long _largestLogBytes;
    string? _copilotVersion, _vscodeVersion;

    public Prober(ProbeOptions options) => _options = options;

    public static ProbeResult Run(DebugLogSession session, ProbeOptions options) => new Prober(options).Probe(session);

    ProbeResult Probe(DebugLogSession session)
    {
        foreach (var file in SessionCatalog.SafeEnumerateFiles(session.Dir).Order(StringComparer.Ordinal))
            ScanFile(file);

        var checks = new List<ProbeCheck>();
        bool hasMain = File.Exists(session.MainLog);

        checks.Add(hasMain
            ? Pass("P1", "Session folder", $"main.jsonl found ({FormatBytes(_files.GetValueOrDefault("main.jsonl")?.Bytes ?? 0)}, {_files.GetValueOrDefault("main.jsonl")?.Lines ?? 0:N0} lines)")
            : Fail("P1", "Session folder", "main.jsonl not found: debug logs are not written for this session"));

        checks.Add(_llmTotal > 0
            ? Pass("P2", "Model calls", $"{_llmTotal:N0} llm_request events ({_llmTotal - _llmOk:N0} failed)")
            : Fail("P2", "Model calls", "no llm_request events: no cost data"));

        double tokenShare = Share(_llmWithTokens, _llmOk);
        checks.Add(_llmOk > 0 && tokenShare >= 0.9
            ? Pass("P3", "Token fields", $"inputTokens and outputTokens are numbers on {tokenShare:P0} of successful calls")
            : Fail("P3", "Token fields", _llmOk == 0 ? "no successful model calls to check" : $"token numbers on only {tokenShare:P0} of successful calls: cost cannot be computed"));

        double cachedShare = Share(_llmWithCached, _llmOk);
        checks.Add(cachedShare >= 0.9
            ? Pass("P4", "Cache field", $"cachedTokens on {cachedShare:P0} of successful calls")
            : Warn("P4", "Cache field", $"cachedTokens on {cachedShare:P0} of successful calls: cache analysis limited"));

        double nanoShare = Share(_llmWithNano, _llmOk);
        checks.Add(nanoShare >= 0.9
            ? Pass("P5", "Billed cost", $"copilotUsageNanoAiu on {nanoShare:P0} of successful calls")
            : Warn("P5", "Billed cost", $"copilotUsageNanoAiu on {nanoShare:P0} of successful calls: credits are estimated for the rest"));

        checks.Add(ModelCheck());
        checks.Add(SubagentCheck());

        checks.Add(_toolTotal == 0
            ? Warn("P8", "Tool calls", "no tool_call events: no context-growth attribution")
            : _toolNamed == _toolTotal
                ? Pass("P8", "Tool calls", $"{_toolTotal:N0} tool_call events, all named")
                : Warn("P8", "Tool calls", $"{_toolTotal - _toolNamed:N0} of {_toolTotal:N0} tool_call events have no name"));

        checks.Add(_toolWithResult > 0
            ? Info("P9", "Tool sizes", $"tool results logged as text on {_toolWithResult:N0} calls, longest {_toolMaxResult:N0} chars (Copilot caps it at 5,000): growth stays inferred unless P16 passes")
            : Info("P9", "Tool sizes", "no size-like attribute on tool calls: growth stays inferred unless P16 passes"));

        var (titleCheck, title, stateJson) = TitleCheck(session);
        checks.Add(titleCheck);
        var (unknownCheck, unknownJson) = UnknownCheck();
        checks.Add(unknownCheck);
        checks.Add(ToolArgumentsCheck());
        checks.Add(_options.Live ? WriteDelayCheck(session) : Skip("P13", "Write delay", "run with --live from the agent's terminal inside the session"));
        checks.AddRange(HookChecks(session));
        var parsed = Logs.DebugLogParser.Parse(session);
        checks.Add(SharedChecks.BudgetStops(parsed, _options.EventsDir));
        checks.Add(SharedChecks.McpTools(parsed));

        var filesSummary = string.Join(", ", _files.Values.Select(f => f.Count == 1 ? f.Pattern : $"{f.Count} × {f.Pattern}"));
        var fingerprint = BuildFingerprint(session, checks, stateJson, unknownJson);
        return new ProbeResult
        {
            Session = session,
            Checks = checks,
            Fingerprint = fingerprint,
            CopilotVersion = _copilotVersion,
            VsCodeVersion = _vscodeVersion,
            Title = title,
            FilesSummary = filesSummary.Length > 0 ? filesSummary : "no files",
        };
    }

    // ---------- scanning ----------

    void ScanFile(string path)
    {
        var (kind, pattern) = DebugLogFormat.Classify(Path.GetFileName(path));
        if (!_files.TryGetValue(pattern, out var stat))
            _files[pattern] = stat = new FileStat { Pattern = pattern, Kind = kind };
        stat.Count++;
        long bytes = 0;
        try { bytes = new FileInfo(path).Length; } catch (IOException) { }
        stat.Bytes += bytes;
        if (kind == LogFileKind.Child) _childFiles++;
        if (kind is not (LogFileKind.Main or LogFileKind.Child)) return;
        _largestLogBytes = Math.Max(_largestLogBytes, bytes);

        try
        {
            foreach (var line in SafeFile.ReadLines(path))
            {
                if (line.Length == 0) continue;
                stat.Lines++;
                if (!ScanLine(line, kind == LogFileKind.Main)) stat.BadLines++;
            }
        }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException)
        {
            stat.ReadErrors++;
        }
    }

    /// <summary>Records the structure of one event. Returns false for a line that is not a JSON object.</summary>
    internal bool ScanLine(string line, bool isMain)
    {
        JsonDocument doc;
        try { doc = JsonDocument.Parse(line); }
        catch (JsonException) { return false; }
        using (doc)
        {
            var e = doc.RootElement;
            if (e.ValueKind != JsonValueKind.Object) return false;
            string type = Str(e, "type") ?? "<missing>";
            if (!_types.TryGetValue(type, out var ts)) _types[type] = ts = new TypeStat();
            ts.Count++;

            foreach (var p in e.EnumerateObject())
                Record(ts.Envelope, p.Name, p.Value, safeValue: false);

            if (Str(e, "name") is { } name)
            {
                if (DebugLogFormat.TypesWithSafeNames.Contains(type)) Increment(ts.Names, name);
                else ts.UnrecordedNames.Add(name);
            }

            var attrs = e.TryGetProperty("attrs", out var a) && a.ValueKind == JsonValueKind.Object ? a : default;
            if (attrs.ValueKind == JsonValueKind.Object)
                foreach (var p in attrs.EnumerateObject())
                    Record(ts.Attrs, p.Name, p.Value, DebugLogFormat.SafeValueAttrs.Contains(type + "." + p.Name));

            long? tsMs = Num(e, "ts");
            if (tsMs is long t) { _firstTs = Math.Min(_firstTs, t); _lastTs = Math.Max(_lastTs, t); }
            if (e.TryGetProperty("rIdx", out _)) _resumed = true;

            switch (type)
            {
                case "llm_request": ScanLlmRequest(e, attrs, tsMs); break;
                case "tool_call": ScanToolCall(e, attrs); break;
                case "child_session_ref": _childRefs++; if (Str(attrs, "label") is { } label) _subagentNames.Add(label); break;
                case "subagent": _subagentEvents++; if (Str(attrs, "agentName") is { } agent) _subagentNames.Add(agent); break;
                case "hook": if (Str(e, "name") is { } hook) _hookNames.Add(hook); break;
                case "session_start" when isMain && Str(attrs, "parentSessionId") is null:
                    _copilotVersion ??= Str(attrs, "copilotVersion");
                    _vscodeVersion ??= Str(attrs, "vscodeVersion");
                    break;
            }
        }
        return true;
    }

    void ScanLlmRequest(JsonElement e, JsonElement attrs, long? tsMs)
    {
        _llmTotal++;
        bool failed = Str(e, "status") == "error" || (attrs.ValueKind == JsonValueKind.Object && attrs.TryGetProperty("error", out _));
        if (Str(attrs, "model") is { } model) Increment(_models, model);
        if (tsMs is long start && Num(e, "dur") is long dur) _lastLlmEnd = Math.Max(_lastLlmEnd, start + dur);
        if (failed) return;
        _llmOk++;
        long? input = Num(attrs, "inputTokens");
        if (input is not null && Num(attrs, "outputTokens") is not null) _llmWithTokens++;
        if (Num(attrs, "cachedTokens") is not null) _llmWithCached++;
        if (Num(attrs, "copilotUsageNanoAiu") is not null) _llmWithNano++;
        if (input is long i)
        {
            _peakInput = Math.Max(_peakInput, i);
            if (i > LongContextTokens) _llmLong++;
        }
    }

    void ScanToolCall(JsonElement e, JsonElement attrs)
    {
        _toolTotal++;
        var name = Str(e, "name");
        if (string.IsNullOrEmpty(name)) return;
        _toolNamed++;
        if (name.Contains("subagent", StringComparison.OrdinalIgnoreCase)) _toolSubagentCalls++;
        if (Str(attrs, "result") is { } result)
        {
            _toolWithResult++;
            _toolMaxResult = Math.Max(_toolMaxResult, result.Length);
        }
        if (!DebugLogFormat.TerminalTools.Contains(name) && !name.Contains("terminal", StringComparison.OrdinalIgnoreCase)) return;
        _terminalCalls++;
        if (Str(attrs, "args") is { } args)
        {
            _terminalWithArgs++;
            if (Tracking.UsageCommands.IsInvocation(args)) _usageCommandCalls++;
        }
    }

    static void Record(SortedDictionary<string, FieldStat> stats, string name, JsonElement value, bool safeValue)
    {
        if (!stats.TryGetValue(name, out var s)) stats[name] = s = new FieldStat();
        s.Count++;
        Increment(s.Kinds, Kind(value));
        if (value.ValueKind != JsonValueKind.String) return;
        var text = value.GetString() ?? "";
        s.MaxLength = Math.Max(s.MaxLength, text.Length);
        if (safeValue && text.Length <= 120)
        {
            s.Values ??= new SortedDictionary<string, int>(StringComparer.Ordinal);
            if (s.Values.Count < 50 || s.Values.ContainsKey(text)) Increment(s.Values, text);
        }
    }

    // ---------- checks ----------

    ProbeCheck ModelCheck()
    {
        if (_models.Count == 0) return Warn("P6", "Model name", "no attrs.model on llm_request events: estimates are missing");
        var unpriced = new List<string>();
        var utility = new List<string>();
        foreach (var m in _models.Keys)
        {
            var (kind, _) = _options.Pricing.Match(m);
            if (kind == PriceMatch.Unpriced) unpriced.Add(m);
            else if (kind == PriceMatch.Utility) utility.Add(m);
        }
        var models = string.Join(", ", _models.Select(m => $"{m.Key} ({m.Value:N0})"));
        if (unpriced.Count == 0)
            return Pass("P6", "Model name", $"all models priced: {models}" + (utility.Count > 0 ? $"; utility: {string.Join(", ", utility)}" : ""));
        return Warn("P6", "Model name", $"not in pricing table: {string.Join(", ", unpriced)}; estimates fall back to billed only. Models: {models}");
    }

    ProbeCheck SubagentCheck()
    {
        bool evidence = _childFiles > 0 || _childRefs > 0 || _subagentEvents > 0;
        if (evidence)
        {
            var names = _subagentNames.Count > 0 ? ": " + string.Join(", ", _subagentNames.Take(8)) : "";
            var detail = $"{_childFiles} child log files, {_childRefs} child_session_ref, {_subagentEvents} subagent events{names}";
            return _childFiles > 0 && _childRefs > 0 ? Pass("P7", "Sub-agents", detail) : Warn("P7", "Sub-agents", detail + " — sub-agent split by file name only");
        }
        return _toolSubagentCalls > 0
            ? Warn("P7", "Sub-agents", $"{_toolSubagentCalls} sub-agent tool calls but no child logs: sub-agent cost cannot be split")
            : Info("P7", "Sub-agents", "no sub-agents ran in this session");
    }

    (ProbeCheck Check, string? Title, JsonObject State) TitleCheck(DebugLogSession session)
    {
        var state = new JsonObject { ["store"] = session.IsGlobal ? "global" : "workspace" };
        var path = session.StateDbPath;
        if (path is null || !File.Exists(path))
        {
            state["readable"] = false;
            return (Info("P10", "Titles", "state.vscdb not found: list shows session IDs instead of titles"), null, state);
        }
        try
        {
            var db = SqliteFile.Open(path);
            state["readable"] = true;
            state["walFramesApplied"] = db.WalFramesApplied;
            var index = StateDb.GetItem(db, StateDb.SessionIndexKey);
            state["indexKey"] = index is not null;
            if (index is null)
                return (Info("P10", "Titles", $"state.vscdb readable, but no {StateDb.SessionIndexKey} key"), null, state);

            using var doc = JsonDocument.Parse(index);
            state["indexShape"] = Shape(doc.RootElement, depth: 0);
            if (doc.RootElement.TryGetProperty("entries", out var entries) && entries.ValueKind == JsonValueKind.Object &&
                entries.TryGetProperty(session.Id, out var entry))
            {
                state["sessionInIndex"] = true;
                var title = Str(entry, "title");
                return (Pass("P10", "Titles", title is null ? "session found in the index, without a title" : "session title found in state.vscdb"), title, state);
            }
            state["sessionInIndex"] = false;
            return (Info("P10", "Titles", "index readable, but this session is not in it (deleted chat or other window)"), null, state);
        }
        catch (Exception e) when (e is InvalidDataException or IOException or JsonException or UnauthorizedAccessException or IndexOutOfRangeException or ArgumentOutOfRangeException)
        {
            state["readable"] = false;
            state["error"] = e.GetType().Name;
            return (Info("P10", "Titles", $"state.vscdb could not be read ({e.Message}): list shows session IDs"), null, state);
        }
    }

    (ProbeCheck Check, JsonObject Unknown) UnknownCheck()
    {
        var unknownTypes = _types.Keys.Where(t => !DebugLogFormat.AttrsByType.ContainsKey(t)).ToList();
        var unknownFields = new List<string>();
        foreach (var (type, stat) in _types)
        {
            unknownFields.AddRange(stat.Envelope.Keys.Where(f => !DebugLogFormat.EnvelopeFields.Contains(f)).Select(f => $"{type}.{f}"));
            if (DebugLogFormat.AttrsByType.TryGetValue(type, out var expected))
                unknownFields.AddRange(stat.Attrs.Keys.Where(a => !expected.Contains(a)).Select(a => $"{type}.attrs.{a}"));
        }
        var unknownFiles = _files.Values.Where(f => f.Kind == LogFileKind.Other).Select(f => f.Pattern).ToList();
        var json = new JsonObject
        {
            ["eventTypes"] = new JsonArray(unknownTypes.Select(t => (JsonNode)t).ToArray()),
            ["fields"] = new JsonArray(unknownFields.Select(f => (JsonNode)f).ToArray()),
            ["files"] = new JsonArray(unknownFiles.Select(f => (JsonNode)f).ToArray()),
        };
        if (unknownTypes.Count + unknownFields.Count + unknownFiles.Count == 0)
            return (Pass("P11", "Unknown", "every event type, field and file is in the expected set"), json);
        var parts = new List<string>();
        if (unknownTypes.Count > 0) parts.Add("types: " + string.Join(", ", unknownTypes.Take(6)));
        if (unknownFields.Count > 0) parts.Add("fields: " + string.Join(", ", unknownFields.Take(6)) + (unknownFields.Count > 6 ? $" (+{unknownFields.Count - 6})" : ""));
        if (unknownFiles.Count > 0) parts.Add("files: " + string.Join(", ", unknownFiles.Take(4)));
        return (Info("P11", "Unknown", string.Join("; ", parts) + " — listed in the fingerprint for review"), json);
    }

    ProbeCheck ToolArgumentsCheck()
    {
        if (_usageCommandCalls > 0)
            return Pass("P12", "Tool arguments", $"{_usageCommandCalls} logged terminal call(s) to copilot-usage found in tool_call arguments");
        if (_terminalWithArgs > 0)
            return Pass("P12", "Tool arguments", $"terminal tool calls carry their command line ({_terminalWithArgs} of {_terminalCalls})");
        if (_terminalCalls > 0)
            return Warn("P12", "Tool arguments", "terminal tool calls have no arguments logged: fallback commands rely on folder matching");
        return Skip("P12", "Tool arguments", "no terminal tool calls in this session; run copilot-usage from the agent's terminal, then probe again");
    }

    ProbeCheck WriteDelayCheck(DebugLogSession session)
    {
        long now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        // The model call that started this command finished just before it ran; if it is already on disk, the delay is at most its age.
        if (_lastLlmEnd != long.MinValue && now - _lastLlmEnd is >= 0 and <= 10_000)
            return Pass("P13", "Write delay", $"the latest model call was on disk at most {(now - _lastLlmEnd) / 1000.0:N1} s after it finished");

        var path = session.MainLog;
        if (!File.Exists(path)) return Skip("P13", "Write delay", "no main.jsonl to watch");
        long offset = new FileInfo(path).Length;
        var deadline = DateTime.UtcNow + _options.LiveWait;
        var lines = new List<string>();
        while (DateTime.UtcNow < deadline)
        {
            Thread.Sleep(500);
            lines.Clear();
            offset = SafeFile.ReadNewLines(path, offset, lines);
            long seen = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            foreach (var line in lines)
            {
                try
                {
                    using var doc = JsonDocument.Parse(line);
                    var e = doc.RootElement;
                    if (Str(e, "type") != "llm_request" || Num(e, "ts") is not long ts || Num(e, "dur") is not long dur) continue;
                    double delay = (seen - (ts + dur)) / 1000.0;
                    return delay <= 10
                        ? Pass("P13", "Write delay", $"a finished model call reached the log {delay:N1} s after it ended")
                        : Warn("P13", "Write delay", $"a finished model call reached the log {delay:N1} s after it ended: totals lag, summaries mark data as pending");
                }
                catch (JsonException) { }
            }
        }
        return Warn("P13", "Write delay", $"no new model call reached the log within {_options.LiveWait.TotalSeconds:N0} s: totals lag or the session is idle");
    }

    IEnumerable<ProbeCheck> HookChecks(DebugLogSession session)
    {
        var eventsFile = Path.Combine(_options.EventsDir, session.Id + ".jsonl");
        var recorded = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        bool responseLength = false;
        if (File.Exists(eventsFile))
        {
            foreach (var line in SafeFile.ReadLines(eventsFile))
            {
                try
                {
                    using var doc = JsonDocument.Parse(line);
                    var e = doc.RootElement;
                    var name = Str(e, "event") ?? Str(e, "hook_event_name");
                    if (name is null) continue;
                    recorded.Add(name);
                    if (name.Equals("PostToolUse", StringComparison.OrdinalIgnoreCase) && Num(e, "responseLength") is not null) responseLength = true;
                }
                catch (JsonException) { }
            }
        }

        bool Fired(params string[] names) => names.Any(n => recorded.Any(r => Squash(r) == Squash(n)) || _hookNames.Any(h => Squash(h) == Squash(n)));
        bool anyHooks = recorded.Count > 0 || _hookNames.Count > 0;
        if (!anyHooks)
        {
            yield return Skip("P14", "Hooks fire", "no hook events for this session yet (copilot-usage hooks install comes in M2)");
            yield return Skip("P15", "Session match", "needs hook events");
            yield return Skip("P16", "Tool result size", "needs PostToolUse hook events");
            yield break;
        }

        var seen = string.Join(", ", recorded.Concat(_hookNames).Distinct(StringComparer.OrdinalIgnoreCase).Take(8));
        yield return Fired("SessionStart") && Fired("Stop", "agentStop")
            ? Pass("P14", "Hooks fire", $"hook events seen: {seen}")
            : Warn("P14", "Hooks fire", $"SessionStart and Stop not both seen (seen: {seen}): hooks disabled or unsupported; use the agent-driven fallback");

        yield return File.Exists(eventsFile)
            ? Pass("P15", "Session match", "hook session_id equals the debug-log folder name")
            : Warn("P15", "Session match", "hooks ran, but no event file named after this session: match by folder and time");

        yield return responseLength
            ? Pass("P16", "Tool result size", "PostToolUse events record a response length")
            : Info("P16", "Tool result size", "no PostToolUse response lengths: growth per tool stays inferred");
    }

    // ---------- fingerprint ----------

    JsonObject BuildFingerprint(DebugLogSession session, List<ProbeCheck> checks, JsonObject state, JsonObject unknown)
    {
        var files = new JsonArray();
        foreach (var f in _files.Values)
            files.Add(new JsonObject
            {
                ["pattern"] = f.Pattern, ["kind"] = f.Kind.ToString(), ["count"] = f.Count, ["bytes"] = f.Bytes,
                ["lines"] = f.Lines, ["badLines"] = f.BadLines, ["readErrors"] = f.ReadErrors,
            });

        var events = new JsonObject();
        foreach (var (type, t) in _types)
        {
            var envelope = new JsonObject();
            foreach (var (k, v) in t.Envelope) envelope[k] = v.ToJson();
            var attrs = new JsonObject();
            foreach (var (k, v) in t.Attrs) attrs[k] = v.ToJson();
            var o = new JsonObject { ["count"] = t.Count, ["envelope"] = envelope, ["attrs"] = attrs };
            if (t.Names.Count > 0) o["names"] = FieldStat.ToJson(t.Names);
            if (t.UnrecordedNames.Count > 0) o["distinctNames"] = t.UnrecordedNames.Count;
            events[type] = o;
        }

        var checkArray = new JsonArray();
        foreach (var c in checks)
            checkArray.Add(new JsonObject { ["id"] = c.Id, ["name"] = c.Name, ["outcome"] = c.Outcome.ToString().ToLowerInvariant(), ["detail"] = c.Detail });

        return new JsonObject
        {
            ["fingerprintVersion"] = 1,
            ["tool"] = "copilot-usage " + Program.Version,
            ["probedAt"] = DateTimeOffset.UtcNow.ToString("o"),
            ["expectedFormat"] = DebugLogFormat.ExpectedFrom,
            ["session"] = new JsonObject
            {
                ["id"] = session.Id,
                ["root"] = session.Root?.Label ?? "--dir",
                ["store"] = session.IsGlobal ? "global" : "workspace",
                ["firstEvent"] = _firstTs == long.MaxValue ? null : DateTimeOffset.FromUnixTimeMilliseconds(_firstTs).ToString("o"),
                ["lastEvent"] = _lastTs == long.MinValue ? null : DateTimeOffset.FromUnixTimeMilliseconds(_lastTs).ToString("o"),
                ["resumed"] = _resumed,
            },
            ["copilot"] = new JsonObject { ["copilotVersion"] = _copilotVersion, ["vscodeVersion"] = _vscodeVersion },
            ["files"] = files,
            ["largestLogBytes"] = _largestLogBytes,
            ["truncationRisk"] = _largestLogBytes > TruncationWarnBytes,
            ["events"] = events,
            ["llmRequests"] = new JsonObject
            {
                ["total"] = _llmTotal, ["ok"] = _llmOk, ["withTokens"] = _llmWithTokens, ["withCached"] = _llmWithCached,
                ["withNanoAiu"] = _llmWithNano, ["overLongContext"] = _llmLong, ["peakInputTokens"] = _peakInput,
                ["models"] = FieldStat.ToJson(_models),
            },
            ["toolCalls"] = new JsonObject
            {
                ["total"] = _toolTotal, ["named"] = _toolNamed, ["subagentCalls"] = _toolSubagentCalls, ["terminal"] = _terminalCalls,
                ["terminalWithArgs"] = _terminalWithArgs, ["withResultText"] = _toolWithResult, ["maxResultLength"] = _toolMaxResult,
            },
            ["state"] = state,
            ["unknown"] = unknown,
            ["checks"] = checkArray,
        };
    }

    /// <summary>Key names and kinds of a JSON value; ID-like keys collapse to &lt;id&gt; and only the first one is described.</summary>
    static JsonNode Shape(JsonElement e, int depth)
    {
        if (depth > 4) return Kind(e);
        switch (e.ValueKind)
        {
            case JsonValueKind.Object:
                var o = new JsonObject();
                foreach (var p in e.EnumerateObject())
                {
                    var key = LooksLikeId(p.Name) ? "<id>" : p.Name;
                    if (o.ContainsKey(key)) continue;
                    o[key] = Shape(p.Value, depth + 1);
                }
                return o;
            case JsonValueKind.Array:
                var a = new JsonArray();
                foreach (var item in e.EnumerateArray()) { a.Add(Shape(item, depth + 1)); break; }
                return a;
            default:
                return Kind(e);
        }
    }

    static bool LooksLikeId(string key) => key.Length >= 16 && key.All(c => char.IsAsciiHexDigit(c) || c == '-');

    // ---------- helpers ----------

    static string Kind(JsonElement e) => e.ValueKind switch
    {
        JsonValueKind.String => "string",
        JsonValueKind.Number => "number",
        JsonValueKind.Object => "object",
        JsonValueKind.Array => "array",
        JsonValueKind.True or JsonValueKind.False => "boolean",
        JsonValueKind.Null => "null",
        _ => "undefined",
    };

    static string? Str(JsonElement e, string name) =>
        e.ValueKind == JsonValueKind.Object && e.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;

    static long? Num(JsonElement e, string name)
    {
        if (e.ValueKind != JsonValueKind.Object || !e.TryGetProperty(name, out var v) || v.ValueKind != JsonValueKind.Number) return null;
        return v.TryGetInt64(out var l) ? l : (long)v.GetDouble();
    }

    static void Increment(IDictionary<string, int> d, string key) => d[key] = d.TryGetValue(key, out var n) ? n + 1 : 1;
    static double Share(int part, int whole) => whole == 0 ? 0 : (double)part / whole;
    static string Squash(string s) => s.Replace("_", "").Replace("-", "").ToLowerInvariant();

    internal static string FormatBytes(long bytes) => bytes switch
    {
        >= 1L << 20 => $"{bytes / (double)(1L << 20):N1} MB",
        >= 1L << 10 => $"{bytes / (double)(1L << 10):N0} KB",
        _ => $"{bytes} B",
    };

    static ProbeCheck Pass(string id, string name, string detail) => new(id, name, CheckOutcome.Pass, detail);
    static ProbeCheck Warn(string id, string name, string detail) => new(id, name, CheckOutcome.Warn, detail);
    static ProbeCheck Fail(string id, string name, string detail) => new(id, name, CheckOutcome.Fail, detail);
    static ProbeCheck Info(string id, string name, string detail) => new(id, name, CheckOutcome.Info, detail);
    static ProbeCheck Skip(string id, string name, string detail) => new(id, name, CheckOutcome.Skip, detail);
}
