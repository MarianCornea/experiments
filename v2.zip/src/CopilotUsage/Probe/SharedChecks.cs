using CopilotUsage.Analysis;
using CopilotUsage.Model;
using CopilotUsage.Tracking;

namespace CopilotUsage.Probe;

/// <summary>Probe checks that work the same on every source: P17 budget stops and P18 MCP tools.</summary>
public static class SharedChecks
{
    /// <summary>
    /// P17: what the session's log shows after each budget stop the hook gave. A soft stop should be followed by
    /// the agent wrapping up (more model calls); a hard stop should end the session (no model call after it).
    /// Whether the stop reason reached the user or the model is not in the logs, which hold numbers and names only.
    /// </summary>
    public static ProbeCheck BudgetStops(SessionData data, string eventsDir)
    {
        const string name = "Budget stops";
        var stops = HookEvents.Load(data.Session.Id, eventsDir).Where(e => e.Event == "budgetStop").OrderBy(e => e.Ts).ToList();
        if (stops.Count == 0)
            return new ProbeCheck("P17", name, CheckOutcome.Skip,
                "no budget stop in this session; to test, run one with tiny limits: hooks install --soft-budget 0.01 --hard-budget 0.05");

        var calls = data.SuccessfulCalls.ToList();
        var parts = new List<string>();
        bool reliable = true;
        if (stops.FirstOrDefault(s => s.Budget == "soft") is { } soft)
        {
            int after = calls.Count(c => c.Start > soft.Time);
            bool blocked = data.Tools.Any(t => !t.Success && Math.Abs((t.Start - soft.Time).TotalSeconds) <= 10);
            parts.Add($"soft stop at {soft.Time.ToLocalTime():HH:mm:ss}: " +
                      (blocked ? "a tool call was blocked, " : "no blocked tool call in the log, ") +
                      (after > 0 ? $"the agent went on to wrap up ({after} model calls)" : "no model call followed"));
            reliable &= after > 0;
        }
        if (stops.FirstOrDefault(s => s.Budget is "hard" or "error") is { } hard)
        {
            // Allow a few seconds for the call that was already running.
            int after = calls.Count(c => c.Start > hard.Time.AddSeconds(5));
            parts.Add($"{(hard.Budget == "hard" ? "hard stop" : "fail-closed stop")} at {hard.Time.ToLocalTime():HH:mm:ss}: " +
                      (after == 0 ? "the session ended" : $"the session went on ({after} model calls after it): tool calls are denied, but the session was not ended"));
            reliable &= after == 0;
        }
        var detail = string.Join("; ", parts) + ". Whether the stop reason reached the user or the model is not in the logs.";
        return reliable
            ? new ProbeCheck("P17", name, CheckOutcome.Pass, detail)
            : new ProbeCheck("P17", name, CheckOutcome.Warn, detail + " Budget limits cannot be relied on here: keep the limit as a report warning.");
    }

    /// <summary>P18: whether MCP tools can be told apart, and whether their definitions are logged.</summary>
    public static ProbeCheck McpTools(SessionData data)
    {
        const string name = "MCP tools";
        var calledServers = data.Tools.Select(t => McpNames.ServerOf(t.Name)).Where(s => s is not null).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        if (data.PerRequest)
            return new ProbeCheck("P18", name, CheckOutcome.Info, calledServers.Count == 0
                ? "no MCP tools; the chat transcript records tool calls only, no definitions"
                : $"MCP servers by name prefix: {string.Join(", ", calledServers)}; the chat transcript records no definitions or result sizes");

        var defs = data.ToolDefinitions.Values.SelectMany(d => d).ToList();
        var defServers = defs.Select(d => McpNames.ServerOf(d.Name)).Where(s => s is not null).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        if (defs.Count == 0)
            return calledServers.Count == 0
                ? new ProbeCheck("P18", name, CheckOutcome.Info, "no MCP tools called and no per-tool definitions logged")
                : new ProbeCheck("P18", name, CheckOutcome.Warn,
                    $"MCP servers by name prefix: {string.Join(", ", calledServers)}; no per-tool definitions in the logs: definition overhead is shown as one total. Use --mcp-map if a server's tools have no prefix");
        if (defServers.Count == 0)
            return calledServers.Count == 0
                ? new ProbeCheck("P18", name, CheckOutcome.Info, $"{defs.Distinct().Count()} tool definitions logged, none with an MCP server prefix")
                : new ProbeCheck("P18", name, CheckOutcome.Warn, "MCP tools were called but none of the logged definitions has a server prefix: use --mcp-map");
        bool linked = data.Calls.Any(c => c.ToolsFile is not null);
        var counts = defServers.Select(sv => $"{sv} ({defs.Where(d => string.Equals(McpNames.ServerOf(d.Name), sv, StringComparison.OrdinalIgnoreCase)).Select(d => d.Name).Distinct().Count()} tools)");
        return new ProbeCheck("P18", name, linked ? CheckOutcome.Pass : CheckOutcome.Warn,
            $"tools_*.json lists MCP tools with a server prefix: {string.Join(", ", counts)}" +
            (linked ? "" : "; model calls do not name their tools file, so definition overhead cannot be counted per call"));
    }
}
