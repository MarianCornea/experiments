using System.Text.Json.Nodes;
using CopilotUsage.Logs;
using CopilotUsage.Storage;

namespace CopilotUsage.Probe;

public enum CheckOutcome { Pass, Warn, Fail, Info, Skip }

public sealed record ProbeCheck(string Id, string Name, CheckOutcome Outcome, string Detail);

public sealed class ProbeOptions
{
    public bool Live { get; init; }
    public TimeSpan LiveWait { get; init; } = TimeSpan.FromSeconds(15);
    public required Pricing.PricingTable Pricing { get; init; }
    public string EventsDir { get; init; } = ToolPaths.EventsDir;
}

public sealed class ProbeResult
{
    public required ChatSession Session { get; init; }
    public required IReadOnlyList<ProbeCheck> Checks { get; init; }
    public required JsonObject Fingerprint { get; init; }
    public string? CopilotVersion { get; init; }
    public string? VsCodeVersion { get; init; }
    public string? Title { get; init; }
    public required string FilesSummary { get; init; }

    /// <summary>Gate G0: checks P1 to P3 pass.</summary>
    public bool GatePassed => Checks.Where(c => c.Id is "P1" or "P2" or "P3").All(c => c.Outcome == CheckOutcome.Pass);
}

/// <summary>Structure seen for one attribute or envelope field. Holds kinds and lengths, never values (except safe names).</summary>
sealed class FieldStat
{
    public int Count;
    public readonly SortedDictionary<string, int> Kinds = new(StringComparer.Ordinal);
    public int MaxLength = -1;
    public SortedDictionary<string, int>? Values;

    public JsonObject ToJson()
    {
        var o = new JsonObject { ["count"] = Count, ["kinds"] = ToJson(Kinds) };
        if (MaxLength >= 0) o["maxLength"] = MaxLength;
        if (Values is not null) o["values"] = ToJson(Values);
        return o;
    }

    internal static JsonObject ToJson(IDictionary<string, int> d)
    {
        var o = new JsonObject();
        foreach (var (k, v) in d) o[k] = v;
        return o;
    }
}

sealed class TypeStat
{
    public int Count;
    public readonly SortedDictionary<string, FieldStat> Envelope = new(StringComparer.Ordinal);
    public readonly SortedDictionary<string, FieldStat> Attrs = new(StringComparer.Ordinal);
    public readonly SortedDictionary<string, int> Names = new(StringComparer.Ordinal);
    public readonly HashSet<string> UnrecordedNames = new(StringComparer.Ordinal);
}

sealed class FileStat
{
    public required string Pattern;
    public required LogFileKind Kind;
    public int Count;
    public long Bytes;
    public int Lines;
    public int BadLines;
    public int ReadErrors;
}
