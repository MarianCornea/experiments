namespace CopilotUsage.Cli;

/// <summary>Positional arguments plus --name value options and --flag switches.</summary>
public sealed class CliArgs
{
    readonly Dictionary<string, string?> _options = new(StringComparer.OrdinalIgnoreCase);
    readonly HashSet<string> _used = new(StringComparer.OrdinalIgnoreCase);

    public List<string> Positionals { get; } = [];

    /// <param name="flags">Options that take no value.</param>
    public static CliArgs Parse(IEnumerable<string> args, params string[] flags)
    {
        var result = new CliArgs();
        var flagSet = new HashSet<string>(flags, StringComparer.OrdinalIgnoreCase);
        using var e = args.GetEnumerator();
        while (e.MoveNext())
        {
            var a = e.Current;
            if (a.StartsWith("--", StringComparison.Ordinal) && a.Length > 2)
            {
                var name = a[2..];
                string? value = null;
                int eq = name.IndexOf('=');
                if (eq >= 0) { value = name[(eq + 1)..]; name = name[..eq]; }
                else if (!flagSet.Contains(name))
                {
                    if (!e.MoveNext()) throw new CliException($"--{name} needs a value");
                    value = e.Current;
                }
                result._options[name] = value;
            }
            else
            {
                result.Positionals.Add(a);
            }
        }
        return result;
    }

    public string? Get(string name) { _used.Add(name); return _options.GetValueOrDefault(name); }

    public bool Has(string name) { _used.Add(name); return _options.ContainsKey(name); }

    public int? GetInt(string name)
    {
        var v = Get(name);
        if (v is null) return null;
        return int.TryParse(v, out var n) ? n : throw new CliException($"--{name} expects a number, got '{v}'");
    }

    /// <summary>Fails on options the command did not read, so typos are not silently ignored.</summary>
    public void RejectUnknown()
    {
        var unknown = _options.Keys.Where(k => !_used.Contains(k)).ToList();
        if (unknown.Count > 0) throw new CliException("unknown option: " + string.Join(", ", unknown.Select(u => "--" + u)));
    }
}
