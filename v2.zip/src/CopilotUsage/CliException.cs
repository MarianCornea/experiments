namespace CopilotUsage;

/// <summary>An error the user can fix; printed without a stack trace.</summary>
public sealed class CliException(string message, int exitCode = ExitCodes.Error) : Exception(message)
{
    public int ExitCode { get; } = exitCode;
}

public static class ExitCodes
{
    public const int Ok = 0;
    public const int Error = 1;
    public const int BudgetExceeded = 2;
    public const int SessionNotIdentified = 3;
    public const int NoNewData = 4;
}
