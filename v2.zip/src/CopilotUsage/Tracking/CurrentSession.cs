using System.Text;
using CopilotUsage.Storage;
using static CopilotUsage.Logs.Json;

namespace CopilotUsage.Tracking;

public sealed record IdentifiedSession(ChatSession Session, string Method);

/// <summary>
/// Finds the session an in-session command (status, phase) was run from (FR-14), and refuses to guess when
/// more than one session fits (FR-16). Methods, in order:
/// 1. --session; 2. COPILOT_AGENT_SESSION_ID from the Copilot runtime's shell; 3. the preToolUse hook event that
/// recorded this copilot-usage command; 4. a Copilot harness session whose log shows a copilot-usage shell command
/// still running; 5. the session in this folder that changed most recently.
/// </summary>
public sealed class CurrentSession
{
    public static readonly TimeSpan HookWindow = TimeSpan.FromSeconds(120);
    public static readonly TimeSpan ActiveWindow = TimeSpan.FromMinutes(10);
    const int TailBytes = 512 * 1024;

    public required IReadOnlyList<ChatSession> Sessions { get; init; }
    public string EventsDir { get; init; } = ToolPaths.EventsDir;
    public string? EnvironmentSessionId { get; init; } = Environment.GetEnvironmentVariable("COPILOT_AGENT_SESSION_ID");
    public string WorkingDirectory { get; init; } = Directory.GetCurrentDirectory();
    public DateTimeOffset Now { get; init; } = DateTimeOffset.UtcNow;

    public IdentifiedSession Identify(string? sessionOption)
    {
        if (sessionOption is not null)
            return new(SessionSelector.Select(sessionOption, null, Sessions), "--session");

        if (EnvironmentSessionId is { Length: > 0 } envId && FindById(envId) is { } fromEnv)
            return new(fromEnv, "COPILOT_AGENT_SESSION_ID");

        var fromHooks = FromHookEvents();
        if (fromHooks.Count == 1 && FindById(fromHooks[0]) is { } hooked) return new(hooked, "hook event");
        if (fromHooks.Count > 1) throw Ambiguous("copilot-usage ran from more than one session in the last 2 minutes", fromHooks);

        var running = RunningUsageCommands();
        if (running.Count == 1) return new(running[0], "running command in the session log");
        if (running.Count > 1) throw Ambiguous("more than one session is running a copilot-usage command", running.Select(s => s.Id));

        var folder = Path.GetFullPath(WorkingDirectory).TrimEnd('\\', '/');
        var inFolder = Sessions.Where(s => s.WorkspaceFolder is { } f && IsSameOrInside(folder, f)).OrderByDescending(s => s.LastWriteUtc).ToList();
        var active = inFolder.Where(s => Now.UtcDateTime - s.LastWriteUtc < ActiveWindow).ToList();
        if (active.Count > 1) throw Ambiguous($"{active.Count} sessions in {folder} were active in the last 10 minutes", active.Select(s => s.Id));
        if (inFolder.Count > 0) return new(inFolder[0], "most recent session in this folder");

        throw new CliException($"cannot tell which session this is: no hook event, running command or session for {folder}; pass --session <id>",
            ExitCodes.SessionNotIdentified);
    }

    /// <summary>A session-state folder ID, or a sub-agent's own ID that one of the sessions knows as an agent.</summary>
    ChatSession? FindById(string id)
    {
        var direct = Sessions.FirstOrDefault(s => s.Id.Equals(id, StringComparison.OrdinalIgnoreCase));
        if (direct is not null) return direct;
        var alias = Path.Combine(EventsDir, "alias", ToolPaths.Safe(id));
        if (File.Exists(alias) && Sessions.FirstOrDefault(s => s.Id == File.ReadAllText(alias).Trim()) is { } root) return root;
        foreach (var s in Sessions.OfType<CliSession>().Where(IsRecent))
            if (Tail(s.EventsFile).Contains($"\"agentId\":\"{id}\"", StringComparison.Ordinal)) return s;
        return null;
    }

    /// <summary>Root sessions whose preToolUse hook recorded a copilot-usage shell command in the last 2 minutes.</summary>
    List<string> FromHookEvents()
    {
        var ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (!Directory.Exists(EventsDir)) return [];
        foreach (var file in Directory.GetFiles(EventsDir, "*.jsonl"))
        {
            if (Now.UtcDateTime - File.GetLastWriteTimeUtc(file) > HookWindow) continue;
            foreach (var line in Tail(file).Split('\n'))
                if (line.Contains("\"usageCommand\":true", StringComparison.Ordinal) && HookEvent.Parse(line) is { } e &&
                    Now - e.Time < HookWindow && Now - e.Time > TimeSpan.FromSeconds(-5))
                    ids.Add(e.SessionId);
        }
        return ids.ToList();
    }

    /// <summary>Copilot harness sessions whose log shows a copilot-usage shell command started and not yet completed.</summary>
    List<ChatSession> RunningUsageCommands()
    {
        var found = new List<ChatSession>();
        foreach (var s in Sessions.OfType<CliSession>().Where(IsRecent))
        {
            var started = new Dictionary<string, DateTimeOffset>(StringComparer.Ordinal);
            foreach (var line in Tail(s.EventsFile).Split('\n'))
            {
                bool start = line.Contains("\"tool.execution_start\"", StringComparison.Ordinal);
                bool complete = !start && line.Contains("\"tool.execution_complete\"", StringComparison.Ordinal);
                if (!start && !complete) continue;
                using var doc = ParseObject(line);
                if (doc is null || Str(At(doc.RootElement, "data"), "toolCallId") is not { } id) continue;
                if (complete) { started.Remove(id); continue; }
                var command = Str(At(doc.RootElement, "data.arguments"), "command");
                if (UsageCommands.IsInvocation(command) &&
                    Time(doc.RootElement, "timestamp") is { } at && Now - at < ActiveWindow)
                    started[id] = at;
            }
            if (started.Count > 0) found.Add(s);
        }
        return found;
    }

    bool IsRecent(ChatSession s) => Now.UtcDateTime - s.LastWriteUtc < ActiveWindow;

    static bool IsSameOrInside(string folder, string workspace)
    {
        var w = workspace.TrimEnd('\\', '/');
        return folder.Equals(w, StringComparison.OrdinalIgnoreCase) ||
               folder.StartsWith(w + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) ||
               folder.StartsWith(w + "/", StringComparison.OrdinalIgnoreCase);
    }

    static string Tail(string path)
    {
        try
        {
            using var f = SafeFile.OpenRead(path);
            long start = Math.Max(0, f.Length - TailBytes);
            f.Seek(start, SeekOrigin.Begin);
            var bytes = new byte[f.Length - start];
            int n = f.ReadAtLeast(bytes, bytes.Length, throwOnEndOfStream: false);
            var text = Encoding.UTF8.GetString(bytes, 0, n);
            return start > 0 && text.IndexOf('\n') is int nl and >= 0 ? text[(nl + 1)..] : text;
        }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException) { return ""; }
    }

    static CliException Ambiguous(string why, IEnumerable<string> ids) =>
        new($"cannot tell which session this is: {why} ({string.Join(", ", ids.Take(4))}); pass --session <id>", ExitCodes.SessionNotIdentified);
}
