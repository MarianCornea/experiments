using System.Text.Json;
using CopilotUsage.Storage;

namespace CopilotUsage.Tracking;

public sealed record Checkpoint(string Phase, string Kind, long Ts, string? Marker = null)
{
    public const string Start = "start";
    public const string End = "end";
    public DateTimeOffset Time => DateTimeOffset.FromUnixTimeMilliseconds(Ts);
}

/// <summary>One phase between its start and end checkpoints. End is null while it is open.</summary>
public sealed record PhaseSpan(string Name, DateTimeOffset Start, DateTimeOffset? End)
{
    public bool Contains(DateTimeOffset t) => t >= Start && (End is null || t < End);
}

/// <summary>Phase checkpoints (FR-10), stored in the tool's own folder, never in Copilot's.</summary>
public static class Checkpoints
{
    static readonly JsonSerializerOptions Options = new() { PropertyNamingPolicy = JsonNamingPolicy.CamelCase, DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull };

    public static void Add(string sessionId, Checkpoint checkpoint, string? dir = null)
    {
        var file = dir is null ? ToolPaths.CheckpointsFile(sessionId) : Path.Combine(dir, ToolPaths.Safe(sessionId) + ".jsonl");
        Directory.CreateDirectory(Path.GetDirectoryName(file)!);
        File.AppendAllText(file, JsonSerializer.Serialize(checkpoint, Options) + "\n");
    }

    public static List<Checkpoint> Load(string sessionId, string? dir = null)
    {
        var file = dir is null ? ToolPaths.CheckpointsFile(sessionId) : Path.Combine(dir, ToolPaths.Safe(sessionId) + ".jsonl");
        var list = new List<Checkpoint>();
        if (!File.Exists(file)) return list;
        foreach (var line in SafeFile.ReadLines(file))
        {
            if (line.Length == 0) continue;
            try { if (JsonSerializer.Deserialize<Checkpoint>(line, Options) is { } c) list.Add(c); }
            catch (JsonException) { }
        }
        return list.OrderBy(c => c.Ts).ToList();
    }

    /// <summary>Pairs each start with the next end of the same name; a repeated phase gives several spans.</summary>
    public static List<PhaseSpan> Spans(IEnumerable<Checkpoint> checkpoints)
    {
        var open = new Dictionary<string, DateTimeOffset>(StringComparer.Ordinal);
        var spans = new List<PhaseSpan>();
        foreach (var c in checkpoints.OrderBy(c => c.Ts))
        {
            if (c.Kind == Checkpoint.Start)
            {
                if (open.Remove(c.Phase, out var restarted)) spans.Add(new PhaseSpan(c.Phase, restarted, c.Time));
                open[c.Phase] = c.Time;
            }
            else if (c.Kind == Checkpoint.End && open.Remove(c.Phase, out var started))
            {
                spans.Add(new PhaseSpan(c.Phase, started, c.Time));
            }
        }
        spans.AddRange(open.Select(o => new PhaseSpan(o.Key, o.Value, null)));
        return spans.OrderBy(s => s.Start).ToList();
    }

    public static string NewMarker() => "cu-" + Guid.NewGuid().ToString("n")[..6];
}
