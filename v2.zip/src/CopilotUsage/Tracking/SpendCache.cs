using System.Text.Json;
using CopilotUsage.Storage;
using static CopilotUsage.Logs.Json;

namespace CopilotUsage.Tracking;

/// <summary>Running billed total of one session, kept up to date by reading only the log lines added since last time.</summary>
public sealed class SpendState
{
    public string? Dir { get; set; }
    public Dictionary<string, long> Offsets { get; set; } = [];
    public long NanoAiu { get; set; }
    public int Calls { get; set; }
    public int UnbilledCalls { get; set; }
    /// <summary>The soft limit at which the one-time soft stop was given; a higher soft limit re-arms it.</summary>
    public double? SoftStopAt { get; set; }
    public double Credits => NanoAiu / 1e9;
}

/// <summary>
/// Used by the preToolUse budget check, which must answer in well under 200 ms (NFR-11):
/// only billed nanoAIU is summed, and only from lines that name a model call.
/// </summary>
public static class SpendCache
{

    public static SpendState Update(string sessionId, string? cliHome, IReadOnlyList<StorageRoot> roots, string? cacheFile = null)
    {
        cacheFile ??= ToolPaths.SpendCacheFile(sessionId);
        var state = Load(cacheFile) ?? new SpendState();
        if (state.Dir is null || !Directory.Exists(state.Dir)) { state = new SpendState { Dir = FindDir(sessionId, cliHome, roots), SoftStopAt = state.SoftStopAt }; }
        if (state.Dir is null) return state;

        var files = SessionCatalog.SafeEnumerateFiles(state.Dir).Where(f => f.EndsWith(".jsonl", StringComparison.OrdinalIgnoreCase)).ToList();
        // A log that shrank was truncated or replaced: start the count again.
        if (files.Any(f => new FileInfo(f).Length < state.Offsets.GetValueOrDefault(Path.GetFileName(f))))
            state = new SpendState { Dir = state.Dir, SoftStopAt = state.SoftStopAt };

        foreach (var file in files)
        {
            var name = Path.GetFileName(file);
            long offset = state.Offsets.GetValueOrDefault(name);
            var lines = new List<string>();
            state.Offsets[name] = SafeFile.ReadNewLines(file, offset, lines);
            foreach (var line in lines)
            {
                bool cli = line.Contains("\"session.usage_record\"", StringComparison.Ordinal);
                if (!cli && !line.Contains("\"llm_request\"", StringComparison.Ordinal)) continue;
                using var doc = ParseObject(line);
                if (doc is null) continue;
                long? nano = cli
                    ? Long(At(doc.RootElement, "data.usage.copilotUsage"), "totalNanoAiu")
                    : Long(At(doc.RootElement, "attrs"), "copilotUsageNanoAiu");
                if (!cli && (Str(doc.RootElement, "status") == "error" || Has(At(doc.RootElement, "attrs"), "error"))) continue;
                state.Calls++;
                if (nano is long n) state.NanoAiu += n; else state.UnbilledCalls++;
            }
        }
        Save(cacheFile, state);
        return state;
    }

    static string? FindDir(string sessionId, string? cliHome, IReadOnlyList<StorageRoot> roots)
    {
        if (cliHome is not null)
        {
            var cli = Path.Combine(CliSessionCatalog.StateDir(cliHome), sessionId);
            if (File.Exists(Path.Combine(cli, "events.jsonl"))) return cli;
        }
        foreach (var root in roots)
            foreach (var (logsDir, _) in SessionCatalog.DebugLogDirs(root))
            {
                var dir = Path.Combine(logsDir, sessionId);
                if (Directory.Exists(dir)) return dir;
            }
        return null;
    }

    /// <summary>Records that the soft stop was given at this limit, so it is given once (FR-19).</summary>
    public static void MarkSoftStop(string sessionId, double limit, string? cacheFile = null)
    {
        cacheFile ??= ToolPaths.SpendCacheFile(sessionId);
        var state = Load(cacheFile) ?? new SpendState();
        state.SoftStopAt = limit;
        Save(cacheFile, state);
    }

    static SpendState? Load(string file)
    {
        // Hand-written JSON, like HookEvent: no reflection at start-up.
        try
        {
            if (!File.Exists(file)) return null;
            using var doc = ParseObject(File.ReadAllText(file));
            if (doc is null) return null;
            var e = doc.RootElement;
            var state = new SpendState
            {
                Dir = Str(e, "dir"),
                NanoAiu = Long(e, "nanoAiu") ?? 0,
                Calls = (int)(Long(e, "calls") ?? 0),
                UnbilledCalls = (int)(Long(e, "unbilledCalls") ?? 0),
                SoftStopAt = Double(e, "softStopAt"),
            };
            if (e.TryGetProperty("offsets", out var offsets) && offsets.ValueKind == JsonValueKind.Object)
                foreach (var p in offsets.EnumerateObject())
                    if (p.Value.TryGetInt64(out var o)) state.Offsets[p.Name] = o;
            return state;
        }
        catch (IOException) { return null; }
    }

    static void Save(string file, SpendState state)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(file)!);
            var tmp = file + ".tmp";
            using (var stream = File.Create(tmp))
            using (var w = new Utf8JsonWriter(stream))
            {
                w.WriteStartObject();
                if (state.Dir is not null) w.WriteString("dir", state.Dir);
                w.WriteStartObject("offsets");
                foreach (var (name, offset) in state.Offsets) w.WriteNumber(name, offset);
                w.WriteEndObject();
                w.WriteNumber("nanoAiu", state.NanoAiu);
                w.WriteNumber("calls", state.Calls);
                w.WriteNumber("unbilledCalls", state.UnbilledCalls);
                if (state.SoftStopAt is double soft) w.WriteNumber("softStopAt", soft);
                w.WriteEndObject();
            }
            File.Move(tmp, file, overwrite: true);
        }
        catch (IOException) { }
    }
}
