using System.Text.Json;
using CopilotUsage.Storage;
using static CopilotUsage.Logs.Json;

namespace CopilotUsage.Tracking;

/// <summary>
/// One hook event as recorded in %LOCALAPPDATA%\copilot-usage\events\&lt;root session&gt;.jsonl.
/// Only names, IDs, timestamps and lengths: prompts, tool arguments and results are reduced to their length.
/// </summary>
public sealed record HookEvent
{
    public required string Event { get; init; }
    public required long Ts { get; init; }
    public required string SessionId { get; init; }
    /// <summary>Set when the event came from inside a sub-agent (its own session ID), or names the sub-agent for subagentStart/Stop.</summary>
    public string? AgentId { get; init; }
    public string? AgentName { get; init; }
    public string? Tool { get; init; }
    public int? PromptLength { get; init; }
    public int? ResponseLength { get; init; }
    /// <summary>True when a shell tool is about to run a copilot-usage command (identifies the calling session).</summary>
    public bool? UsageCommand { get; init; }
    /// <summary>Working folder, kept for sessionStart only, to link the session to its folder.</summary>
    public string? Cwd { get; init; }
    /// <summary>"copilot" (camelCase input) or "vscode" (snake_case input).</summary>
    public string? Format { get; init; }
    /// <summary>For budgetStop events written by the hook itself: "soft", "hard" or "error" (a failed check under --on-error closed).</summary>
    public string? Budget { get; init; }
    /// <summary>For budgetStop events: the session total and the limit that was reached.</summary>
    public double? Credits { get; init; }
    public double? Limit { get; init; }

    public DateTimeOffset Time => DateTimeOffset.FromUnixTimeMilliseconds(Ts);

    // Written and read by hand: reflection-based serialization costs tens of milliseconds at start-up,
    // and the hook runs before every tool call (NFR-11).
    public string ToJsonLine()
    {
        using var buffer = new MemoryStream();
        using (var w = new Utf8JsonWriter(buffer))
        {
            w.WriteStartObject();
            w.WriteString("event", Event);
            w.WriteNumber("ts", Ts);
            w.WriteString("sessionId", SessionId);
            if (AgentId is not null) w.WriteString("agentId", AgentId);
            if (AgentName is not null) w.WriteString("agentName", AgentName);
            if (Tool is not null) w.WriteString("tool", Tool);
            if (PromptLength is int p) w.WriteNumber("promptLength", p);
            if (ResponseLength is int r) w.WriteNumber("responseLength", r);
            if (UsageCommand is bool u) w.WriteBoolean("usageCommand", u);
            if (Cwd is not null) w.WriteString("cwd", Cwd);
            if (Format is not null) w.WriteString("format", Format);
            if (Budget is not null) w.WriteString("budget", Budget);
            if (Credits is double c) w.WriteNumber("credits", Math.Round(c, 6));
            if (Limit is double l) w.WriteNumber("limit", l);
            w.WriteEndObject();
        }
        return System.Text.Encoding.UTF8.GetString(buffer.ToArray());
    }

    public static HookEvent? Parse(string line)
    {
        using var doc = ParseObject(line);
        if (doc is null) return null;
        var e = doc.RootElement;
        if (Str(e, "event") is not { } name || Str(e, "sessionId") is not { } session || Long(e, "ts") is not long ts) return null;
        return new HookEvent
        {
            Event = name,
            Ts = ts,
            SessionId = session,
            AgentId = Str(e, "agentId"),
            AgentName = Str(e, "agentName"),
            Tool = Str(e, "tool"),
            PromptLength = Long(e, "promptLength") is long p ? (int)p : null,
            ResponseLength = Long(e, "responseLength") is long r ? (int)r : null,
            UsageCommand = e.TryGetProperty("usageCommand", out var u) && u.ValueKind is JsonValueKind.True or JsonValueKind.False ? u.GetBoolean() : null,
            Cwd = Str(e, "cwd"),
            Format = Str(e, "format"),
            Budget = Str(e, "budget"),
            Credits = Double(e, "credits"),
            Limit = Double(e, "limit"),
        };
    }

    /// <summary>Reads a hook's stdin payload (either harness) into an event. Returns null when it has no session ID.</summary>
    public static HookEvent? FromInput(JsonElement input, string? eventName, DateTimeOffset now)
    {
        bool snake = Has(input, "session_id") || Has(input, "hook_event_name");
        var sessionId = Str(input, "sessionId") ?? Str(input, "session_id");
        if (string.IsNullOrEmpty(sessionId)) return null;
        var name = eventName ?? Str(input, "hook_event_name") ?? Str(input, "hookEventName") ?? "unknown";
        long ts = Long(input, "timestamp") is long ms && ms > 1_000_000_000_000 ? ms : now.ToUnixTimeMilliseconds();

        var tool = Str(input, "toolName") ?? Str(input, "tool_name");
        var args = Has(input, "toolArgs") ? At(input, "toolArgs") : At(input, "tool_input");
        // toolArgs may arrive as an object or as a JSON string.
        string? command = Str(args, "command") ?? (args.ValueKind == JsonValueKind.String ? args.GetString() : null);

        return new HookEvent
        {
            Event = name,
            Ts = ts,
            SessionId = sessionId,
            AgentId = Str(input, "agentId") ?? Str(input, "agent_id"),
            AgentName = Str(input, "agentName") ?? Str(input, "agentType") ?? Str(input, "agent_type"),
            Tool = tool,
            PromptLength = (Str(input, "prompt") ?? Str(input, "initialPrompt"))?.Length,
            ResponseLength = ReadResponseLength(input),
            UsageCommand = command is null ? null : UsageCommands.IsInvocation(command),
            Cwd = name.Equals("sessionStart", StringComparison.OrdinalIgnoreCase) ? Str(input, "cwd") : null,
            Format = snake ? "vscode" : "copilot",
        };
    }

    static int? ReadResponseLength(JsonElement input)
    {
        var result = At(input, "toolResult");
        if (Str(result, "textResultForLlm") is { } text) return text.Length;
        if (result.ValueKind == JsonValueKind.String) return result.GetString()!.Length;
        var response = At(input, "tool_response");
        return response.ValueKind switch
        {
            JsonValueKind.String => response.GetString()!.Length,
            JsonValueKind.Object or JsonValueKind.Array => response.GetRawText().Length,
            _ => null,
        };
    }
}

/// <summary>Reads recorded hook events.</summary>
public static class HookEvents
{
    public static List<HookEvent> Load(string sessionId, string? eventsDir = null)
    {
        var file = eventsDir is null ? ToolPaths.EventsFile(sessionId) : Path.Combine(eventsDir, ToolPaths.Safe(sessionId) + ".jsonl");
        var list = new List<HookEvent>();
        if (!File.Exists(file)) return list;
        try
        {
            foreach (var line in SafeFile.ReadLines(file))
                if (line.Length > 0 && HookEvent.Parse(line) is { } e) list.Add(e);
        }
        catch (IOException) { }
        return list;
    }
}
