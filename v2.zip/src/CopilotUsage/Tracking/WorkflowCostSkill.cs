namespace CopilotUsage.Tracking;

/// <summary>The workflow-cost Copilot skill (FR-15): when to measure, how to call the tool, how to act on the result.</summary>
public static class WorkflowCostSkill
{
    public const string FolderName = "workflow-cost";

    public static string Content(string exe) => $$"""
        ---
        name: workflow-cost
        description: Measure and report the credit cost of this workflow while it runs. Use at every phase boundary of a multi-phase workflow, before a step marked as expensive, and whenever the user asks what the run has cost so far.
        ---

        # Workflow cost

        `copilot-usage` reads Copilot's own session logs and reports what this session has cost. Hooks record
        sub-agent runs automatically; these commands add phase boundaries and let you check the spend.

        ## When to measure

        - At the start and end of every phase of the workflow. Use the phase names from the workflow's own phase
          list, exactly as written there, so runs can be compared.
        - Before a step the workflow marks as expensive.
        - Never inside loops, and never more than once per phase boundary: every summary you read is carried in
          every later model call.

        ## Commands

        Run them in the terminal, from the workspace folder:

        ```
        {{exe}} phase start <phase-name>
        {{exe}} phase end <phase-name>
        {{exe}} status
        ```

        Add `--budget <credits>` to `phase end` or `status` when the workflow has a budget. Add `--json` when a script
        reads the result. Each command prints at most 12 lines.

        ## Reading the summary

        - **credits (x% billed)**: what the phase or session cost. Billed numbers come from Copilot itself.
        - **cached**: share of input served from the cache. Under 50% means the start of the prompt changes between
          calls, so the cache cannot be reused; keep instructions and file order stable.
        - **cache write**: credits spent writing new context to the cache. High values mean a lot of new context.
        - **long context**: calls above their model's long-context threshold (272K for most models), which cost up to
          twice as much per token.
          Split the work or summarize before continuing.
        - **context growth**: the tools that added the most context. Large `view` or `read_file` growth means whole
          files were read; read ranges instead.

        ## Exit codes

        - `0`: ok.
        - `2`: the budget is exceeded. Stop, show the summary to the user, and ask before continuing.
        - `3`: the session could not be identified. Note "cost unknown" and carry on.
        - `4`: no new log data yet (the log lags a few seconds). Note "cost pending" and carry on.

        ## Budget stops from the hooks

        When a tool call is blocked with a "copilot-usage: soft budget" message, wrap up: finish no new work, summarize what
        is done and what is left, update the progress file, show `{{exe}} status`, and ask the user before continuing. The
        next tool calls are allowed so you can save your progress. A "hard budget" message means the session is stopped.

        ## Recording

        After each `phase end`, add one line to the workflow's progress file:
        `<phase-name>: <credits> credits, <calls> calls, <duration>`. The progress file then doubles as the run's
        cost log.
        """;
}
