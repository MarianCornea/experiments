using System.Text.RegularExpressions;

namespace CopilotUsage.Tracking;

/// <summary>
/// Tells a shell command that runs copilot-usage from one that merely mentions it
/// (e.g. reading .github/hooks/copilot-usage.json), which must not identify a session.
/// </summary>
public static partial class UsageCommands
{
    public static bool IsInvocation(string? command) => command is not null && Invocation().IsMatch(command);

    // copilot-usage or copilot-usage.exe, optionally quoted or with a path, followed by one of its commands.
    [GeneratedRegex(@"copilot-usage(?:\.exe)?['""]?\s+(?:status|phase|list|probe|doctor|report|compare|hooks?)\b", RegexOptions.IgnoreCase)]
    private static partial Regex Invocation();
}
