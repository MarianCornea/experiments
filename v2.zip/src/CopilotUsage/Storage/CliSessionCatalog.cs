namespace CopilotUsage.Storage;

/// <summary>A Copilot harness / Copilot CLI session folder: ~/.copilot/session-state/&lt;id&gt;/.</summary>
public sealed record CliSession(
    string Id,
    string Dir,
    string? WorkspaceFolder,
    string? Title,
    string? Repository,
    bool Active,
    DateTime LastWriteUtc) : ChatSession(Id, Dir, WorkspaceFolder, LastWriteUtc)
{
    public override SessionSource Source => SessionSource.CopilotCli;
    public string EventsFile => Path.Combine(Dir, "events.jsonl");
}

/// <summary>Finds Copilot harness sessions in the Copilot CLI session store.</summary>
public static class CliSessionCatalog
{
    public const string SessionStateFolder = "session-state";

    /// <summary>~/.copilot, the Copilot CLI home that VS Code's agent host also uses.</summary>
    public static string DefaultHome => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), ".copilot");

    /// <summary>Accepts a Copilot home (~/.copilot) or its session-state folder.</summary>
    public static string StateDir(string home) =>
        Path.GetFileName(home.TrimEnd('\\', '/')).Equals(SessionStateFolder, StringComparison.OrdinalIgnoreCase)
            ? home
            : Path.Combine(home, SessionStateFolder);

    /// <summary>Sessions with an events.jsonl, newest activity first.</summary>
    public static List<CliSession> FindAll(string? home)
    {
        if (home is null) return [];
        var sessions = new List<CliSession>();
        foreach (var dir in SessionCatalog.SafeEnumerateDirectories(StateDir(home)))
            if (File.Exists(Path.Combine(dir, "events.jsonl")))
                sessions.Add(FromDir(dir));
        sessions.Sort((a, b) => b.LastWriteUtc.CompareTo(a.LastWriteUtc));
        return sessions;
    }

    public static CliSession FromDir(string dir)
    {
        var full = Path.GetFullPath(dir);
        var yaml = ReadWorkspaceYaml(Path.Combine(full, "workspace.yaml"));
        // While a session is open, Copilot holds inuse.<pid>.lock in its folder.
        bool active = SessionCatalog.SafeEnumerateFiles(full).Any(f => Path.GetFileName(f).StartsWith("inuse.", StringComparison.OrdinalIgnoreCase));
        return new CliSession(
            Path.GetFileName(full), full,
            yaml.GetValueOrDefault("cwd"),
            yaml.GetValueOrDefault("name") is { Length: > 0 } name ? name : null,
            yaml.GetValueOrDefault("repository"),
            active,
            SessionCatalog.LastWrite(full));
    }

    /// <summary>Reads the flat "key: value" lines of workspace.yaml; nested or list values are ignored.</summary>
    public static Dictionary<string, string> ReadWorkspaceYaml(string path)
    {
        var values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (!File.Exists(path)) return values;
        try
        {
            foreach (var line in SafeFile.ReadLines(path))
            {
                if (line.Length == 0 || char.IsWhiteSpace(line[0]) || line.StartsWith('#') || line.StartsWith('-')) continue;
                int colon = line.IndexOf(':');
                if (colon <= 0) continue;
                var value = line[(colon + 1)..].Trim();
                if (value.Length >= 2 && (value[0] == '"' && value[^1] == '"' || value[0] == '\'' && value[^1] == '\''))
                    value = value[1..^1].Replace("\\\\", "\\").Replace("\\\"", "\"").Replace("''", "'");
                values[line[..colon].Trim()] = value;
            }
        }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException) { }
        return values;
    }
}
