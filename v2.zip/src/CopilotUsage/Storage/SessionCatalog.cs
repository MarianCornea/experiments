namespace CopilotUsage.Storage;

/// <summary>Where a session's data comes from.</summary>
public enum SessionSource
{
    /// <summary>Local harness: Copilot Chat extension debug logs under VS Code storage.</summary>
    DebugLog,
    /// <summary>Copilot harness (VS Code agent host) or Copilot CLI: ~/.copilot/session-state.</summary>
    CopilotCli,
    /// <summary>Local harness without debug-log calls: VS Code's chat transcript (chatSessions/*.jsonl), credits per request.</summary>
    Transcript,
}

/// <summary>One chat session, from either source.</summary>
public abstract record ChatSession(string Id, string Dir, string? WorkspaceFolder, DateTime LastWriteUtc)
{
    public abstract SessionSource Source { get; }
    public string SourceLabel => Source switch
    {
        SessionSource.DebugLog => "Local harness (debug log)",
        SessionSource.Transcript => "Local harness (chat transcript)",
        _ => "Copilot harness (session-state)",
    };
}

/// <summary>One chat session's debug-log folder.</summary>
public sealed record DebugLogSession(
    string Id,
    string Dir,
    StorageRoot? Root,
    string? WorkspaceStorageDir,
    string? WorkspaceFolder,
    DateTime LastWriteUtc) : ChatSession(Id, Dir, WorkspaceFolder, LastWriteUtc)
{
    public override SessionSource Source => SessionSource.DebugLog;
    public string MainLog => Path.Combine(Dir, "main.jsonl");
    public bool IsGlobal => WorkspaceStorageDir is null;

    /// <summary>The state.vscdb that holds this session's title: the workspace's, or the global one.</summary>
    public string? StateDbPath =>
        WorkspaceStorageDir is not null ? Path.Combine(WorkspaceStorageDir, "state.vscdb")
        : Root is not null ? Path.Combine(Root.GlobalStorageDir, "state.vscdb")
        : null;
}

/// <summary>Finds debug-log sessions under the storage roots.</summary>
public static class SessionCatalog
{
    // Copilot uses the extension id as folder name: "GitHub.copilot-chat" in workspaceStorage,
    // lower case in globalStorage. Both are checked; Windows treats them as one folder.
    public static readonly string[] ExtensionFolders = ["GitHub.copilot-chat", "github.copilot-chat"];
    public const string DebugLogsFolder = "debug-logs";

    static readonly StringComparer PathComparer =
        OperatingSystem.IsWindows() || OperatingSystem.IsMacOS() ? StringComparer.OrdinalIgnoreCase : StringComparer.Ordinal;

    /// <summary>All sessions, newest activity first.</summary>
    public static List<DebugLogSession> FindAll(IEnumerable<StorageRoot> roots)
    {
        var seen = new HashSet<string>(PathComparer);
        var sessions = new List<DebugLogSession>();
        foreach (var root in roots)
        {
            foreach (var (logsDir, wsDir) in DebugLogDirs(root))
            {
                if (!seen.Add(Path.GetFullPath(logsDir))) continue;
                var folder = wsDir is null ? null : WorkspaceInfo.ReadFolder(wsDir);
                foreach (var dir in SafeEnumerateDirectories(logsDir))
                    sessions.Add(new DebugLogSession(Path.GetFileName(dir), dir, root, wsDir, folder, LastWrite(dir)));
            }
        }
        sessions.Sort((a, b) => b.LastWriteUtc.CompareTo(a.LastWriteUtc));
        return sessions;
    }

    /// <summary>Every existing debug-logs folder of a root, with the workspace storage folder it belongs to (null = global).</summary>
    public static IEnumerable<(string LogsDir, string? WorkspaceStorageDir)> DebugLogDirs(StorageRoot root)
    {
        // On Windows and macOS both spellings name the same folder; report it once.
        var seen = new HashSet<string>(PathComparer);
        foreach (var wsDir in SafeEnumerateDirectories(root.WorkspaceStorageDir))
            foreach (var ext in ExtensionFolders)
            {
                var logs = Path.Combine(wsDir, ext, DebugLogsFolder);
                if (Directory.Exists(logs) && seen.Add(logs)) yield return (logs, wsDir);
            }
        foreach (var ext in ExtensionFolders)
        {
            var logs = Path.Combine(root.GlobalStorageDir, ext, DebugLogsFolder);
            if (Directory.Exists(logs) && seen.Add(logs)) yield return (logs, null);
        }
    }

    /// <summary>A session folder given directly with --dir (e.g. a copied folder).</summary>
    public static DebugLogSession FromDir(string dir)
    {
        var full = Path.GetFullPath(dir);
        if (!Directory.Exists(full))
            throw new CliException($"--dir {dir}: folder not found", ExitCodes.SessionNotIdentified);

        // Inside workspaceStorage the layout is <hash>/GitHub.copilot-chat/debug-logs/<session>.
        var logsDir = Path.GetDirectoryName(full);
        var extDir = logsDir is null ? null : Path.GetDirectoryName(logsDir);
        var wsDir = extDir is null ? null : Path.GetDirectoryName(extDir);
        bool inWorkspace = wsDir is not null && File.Exists(Path.Combine(wsDir, "workspace.json"));
        return new DebugLogSession(
            Path.GetFileName(full), full, null,
            inWorkspace ? wsDir : null,
            inWorkspace ? WorkspaceInfo.ReadFolder(wsDir!) : null,
            LastWrite(full));
    }

    public static DateTime LastWrite(string dir)
    {
        var latest = Directory.GetLastWriteTimeUtc(dir);
        foreach (var file in SafeEnumerateFiles(dir))
        {
            var t = File.GetLastWriteTimeUtc(file);
            if (t > latest) latest = t;
        }
        return latest;
    }

    public static IEnumerable<string> SafeEnumerateDirectories(string dir)
    {
        try { return Directory.Exists(dir) ? Directory.GetDirectories(dir) : []; }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException) { return []; }
    }

    public static IEnumerable<string> SafeEnumerateFiles(string dir)
    {
        try { return Directory.Exists(dir) ? Directory.GetFiles(dir) : []; }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException) { return []; }
    }
}
