namespace CopilotUsage.Storage;

/// <summary>
/// Resolves a &lt;session&gt; argument (FR-04): a list index (1 = newest), "latest",
/// a full or partial session ID, a session folder, or a workspace folder path.
/// </summary>
public static class SessionSelector
{
    public static ChatSession Select(string? spec, string? dir, IReadOnlyList<ChatSession> sessions)
    {
        if (dir is not null) return FromDir(dir);
        spec ??= "latest";

        if (spec.Equals("latest", StringComparison.OrdinalIgnoreCase))
            return sessions.Count > 0 ? sessions[0] : throw NotFound("no sessions found");

        // A number within the list is an index; any other number may still be the start of an ID (UUIDs often start with digits).
        bool isNumber = int.TryParse(spec, out int index);
        if (isNumber && index >= 1 && index <= sessions.Count)
            return sessions[index - 1];
        if (isNumber && !sessions.Any(s => s.Id.StartsWith(spec, StringComparison.OrdinalIgnoreCase)))
            throw NotFound($"no session number {index}; there are {sessions.Count}");

        if (Directory.Exists(spec))
        {
            if (IsSessionDir(spec)) return FromDir(spec);
            var folder = Path.GetFullPath(spec).TrimEnd('\\', '/');
            var inFolder = sessions.FirstOrDefault(s =>
                s.WorkspaceFolder is not null &&
                string.Equals(s.WorkspaceFolder.TrimEnd('\\', '/'), folder, StringComparison.OrdinalIgnoreCase));
            return inFolder ?? throw NotFound($"no session found for folder {folder}");
        }

        var matches = sessions.Where(s => s.Id.StartsWith(spec, StringComparison.OrdinalIgnoreCase)).ToList();
        return matches.Count switch
        {
            1 => matches[0],
            0 => throw NotFound($"no session ID starts with '{spec}'"),
            _ => throw NotFound($"'{spec}' matches {matches.Count} sessions: " +
                                string.Join(", ", matches.Take(5).Select(m => m.Id)) + (matches.Count > 5 ? ", ..." : "")),
        };
    }

    /// <summary>A copied or given session folder (session-state or debug log), or a chat transcript file (.jsonl).</summary>
    public static ChatSession FromDir(string dir) =>
        IsTranscriptFile(dir) ? TranscriptSession.FromFile(dir)
        : File.Exists(Path.Combine(dir, "events.jsonl")) ? CliSessionCatalog.FromDir(dir) : SessionCatalog.FromDir(dir);

    static bool IsTranscriptFile(string path) => path.EndsWith(".jsonl", StringComparison.OrdinalIgnoreCase) && File.Exists(path);

    static bool IsSessionDir(string dir) =>
        IsTranscriptFile(dir) || File.Exists(Path.Combine(dir, "main.jsonl")) || File.Exists(Path.Combine(dir, "events.jsonl"));

    static CliException NotFound(string message) => new(message, ExitCodes.SessionNotIdentified);
}
