using System.Text.Json;
using CopilotUsage.Sqlite;

namespace CopilotUsage.Storage;

/// <summary>Chat titles of Local harness sessions, from state.vscdb. Each database is read once.</summary>
public sealed class SessionTitles
{
    readonly Dictionary<string, Dictionary<string, string>?> _byDb = new(StringComparer.OrdinalIgnoreCase);

    public string? Lookup(DebugLogSession session) => Lookup(session.Id, session.StateDbPath);

    public string? Lookup(TranscriptSession session) => Lookup(session.Id, session.StateDbPath);

    string? Lookup(string id, string? path)
    {
        if (path is null) return null;
        if (!_byDb.TryGetValue(path, out var titles)) _byDb[path] = titles = Read(path);
        return titles?.GetValueOrDefault(id);
    }

    /// <summary>Session ID → title, or null when the database cannot be read (titles are optional).</summary>
    static Dictionary<string, string>? Read(string path)
    {
        if (!File.Exists(path)) return null;
        try
        {
            var index = StateDb.GetItem(SqliteFile.Open(path), StateDb.SessionIndexKey);
            if (index is null) return null;
            using var doc = JsonDocument.Parse(index);
            var titles = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            if (doc.RootElement.TryGetProperty("entries", out var entries) && entries.ValueKind == JsonValueKind.Object)
                foreach (var entry in entries.EnumerateObject())
                    if (entry.Value.ValueKind == JsonValueKind.Object && entry.Value.TryGetProperty("title", out var t) &&
                        t.ValueKind == JsonValueKind.String && t.GetString() is { Length: > 0 } title)
                        titles[entry.Name] = title;
            return titles;
        }
        catch (Exception e) when (e is InvalidDataException or IOException or JsonException or UnauthorizedAccessException or IndexOutOfRangeException or ArgumentOutOfRangeException)
        {
            return null;
        }
    }
}
