using System.Text;

namespace CopilotUsage.Storage;

/// <summary>
/// Read-only access to VS Code and Copilot files. Every open shares read, write and delete,
/// so VS Code can keep writing, rotating or deleting the file while we read it (NFR-03).
/// </summary>
public static class SafeFile
{
    public static FileStream OpenRead(string path) => new(path, new FileStreamOptions
    {
        Mode = FileMode.Open,
        Access = FileAccess.Read,
        Share = FileShare.ReadWrite | FileShare.Delete,
        Options = FileOptions.SequentialScan,
        BufferSize = 1 << 16,
    });

    public static byte[] ReadAllBytes(string path)
    {
        using var stream = OpenRead(path);
        using var memory = new MemoryStream();
        stream.CopyTo(memory);
        return memory.ToArray();
    }

    public static string ReadAllText(string path)
    {
        using var stream = OpenRead(path);
        using var reader = new StreamReader(stream, Encoding.UTF8, detectEncodingFromByteOrderMarks: true);
        return reader.ReadToEnd();
    }

    public static IEnumerable<string> ReadLines(string path)
    {
        using var stream = OpenRead(path);
        using var reader = new StreamReader(stream, Encoding.UTF8, detectEncodingFromByteOrderMarks: true);
        while (reader.ReadLine() is { } line)
            yield return line;
    }

    /// <summary>Reads complete lines written after <paramref name="offset"/>; returns the new offset.</summary>
    public static long ReadNewLines(string path, long offset, List<string> lines)
    {
        using var stream = OpenRead(path);
        if (stream.Length < offset) offset = 0; // file was truncated or replaced
        stream.Seek(offset, SeekOrigin.Begin);
        var buffer = new byte[stream.Length - offset];
        int read = stream.ReadAtLeast(buffer, buffer.Length, throwOnEndOfStream: false);
        int lastNewline = Array.LastIndexOf(buffer, (byte)'\n', Math.Max(0, read - 1));
        if (read == 0 || lastNewline < 0) return offset;
        foreach (var line in Encoding.UTF8.GetString(buffer, 0, lastNewline).Split('\n'))
            if (line.Length > 0) lines.Add(line.TrimEnd('\r'));
        return offset + lastNewline + 1;
    }
}
