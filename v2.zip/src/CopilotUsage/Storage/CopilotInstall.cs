using System.Text.Json;

namespace CopilotUsage.Storage;

/// <summary>What doctor reports about the Copilot Chat installation and its debug-log setting.</summary>
public static class CopilotInstall
{
    public const string DebugLogSetting = "github.copilot.chat.agentDebugLog.fileLogging.enabled";

    /// <summary>Copilot Chat versions found: bundled with VS Code installs and installed as an extension.</summary>
    public static IReadOnlyList<(string Where, string Version)> FindVersions()
    {
        var found = new List<(string, string)>();
        var home = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        var installDirs = new List<string>();
        if (OperatingSystem.IsWindows())
        {
            var local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            installDirs.AddRange([
                Path.Combine(local, "Programs", "Microsoft VS Code"), Path.Combine(local, "Programs", "Microsoft VS Code Insiders"),
                Path.Combine(programFiles, "Microsoft VS Code"), Path.Combine(programFiles, "Microsoft VS Code Insiders")]);
        }
        else if (OperatingSystem.IsMacOS())
        {
            installDirs.AddRange(["/Applications/Visual Studio Code.app/Contents", "/Applications/Visual Studio Code - Insiders.app/Contents"]);
        }
        else
        {
            installDirs.AddRange(["/usr/share/code", "/usr/share/code-insiders", "/opt/visual-studio-code"]);
        }

        foreach (var dir in installDirs.Where(Directory.Exists))
        {
            // Newer builds keep each version in a hash-named subfolder.
            var candidates = SessionCatalog.SafeEnumerateDirectories(dir).Append(dir);
            foreach (var c in candidates)
                if (ReadVersion(Path.Combine(c, "resources", "app", "extensions", "copilot", "package.json")) is { } v)
                    found.Add(($"bundled ({Path.GetFileName(c)})", v));
        }

        foreach (var extDir in new[] { Path.Combine(home, ".vscode", "extensions"), Path.Combine(home, ".vscode-insiders", "extensions") })
            foreach (var d in SessionCatalog.SafeEnumerateDirectories(extDir).Where(d => Path.GetFileName(d).StartsWith("github.copilot-chat-", StringComparison.OrdinalIgnoreCase)))
                if (ReadVersion(Path.Combine(d, "package.json")) is { } v)
                    found.Add(("extension", v));

        return found.Distinct().ToList();
    }

    static string? ReadVersion(string packageJson)
    {
        if (!File.Exists(packageJson)) return null;
        try
        {
            using var doc = JsonDocument.Parse(SafeFile.ReadAllText(packageJson));
            return doc.RootElement.TryGetProperty("version", out var v) ? v.GetString() : null;
        }
        catch (Exception e) when (e is JsonException or IOException) { return null; }
    }

    /// <summary>The user-level value of the debug-log setting: true, false, or null when not set (default off).</summary>
    public static bool? ReadDebugLogSetting(StorageRoot root)
    {
        if (!File.Exists(root.SettingsFile)) return null;
        try
        {
            using var doc = JsonDocument.Parse(SafeFile.ReadAllText(root.SettingsFile),
                new JsonDocumentOptions { CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true });
            if (doc.RootElement.TryGetProperty(DebugLogSetting, out var v))
                return v.ValueKind switch { JsonValueKind.True => true, JsonValueKind.False => false, _ => null };
        }
        catch (Exception e) when (e is JsonException or IOException) { }
        return null;
    }
}
