namespace CopilotUsage.Storage;

/// <summary>The tool's own data folder. Never inside Copilot's or VS Code's folders.</summary>
public static class ToolPaths
{
    /// <summary>%LOCALAPPDATA%\copilot-usage (Linux: ~/.local/share/copilot-usage). COPILOT_USAGE_HOME overrides it.</summary>
    public static string DataDir =>
        Environment.GetEnvironmentVariable("COPILOT_USAGE_HOME") is { Length: > 0 } home
            ? home
            : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "copilot-usage");

    public static string EventsDir => Path.Combine(DataDir, "events");
    public static string CheckpointsDir => Path.Combine(DataDir, "checkpoints");
    public static string CacheDir => Path.Combine(DataDir, "cache");

    /// <summary>Hook events of one root session.</summary>
    public static string EventsFile(string sessionId) => Path.Combine(EventsDir, Safe(sessionId) + ".jsonl");

    /// <summary>Maps a sub-agent's own session ID to its root session, written when subagentStart fires.</summary>
    public static string AliasFile(string agentSessionId) => Path.Combine(EventsDir, "alias", Safe(agentSessionId));

    public static string CheckpointsFile(string sessionId) => Path.Combine(CheckpointsDir, Safe(sessionId) + ".jsonl");

    /// <summary>Phase checkpoints whose session was not known yet, keyed by their marker.</summary>
    public static string PendingCheckpointsDir => Path.Combine(CheckpointsDir, "pending");

    public static string SpendCacheFile(string sessionId) => Path.Combine(CacheDir, Safe(sessionId) + ".json");

    /// <summary>IDs come from other programs' input: keep them to safe file-name characters.</summary>
    public static string Safe(string id)
    {
        var chars = id.Select(c => char.IsAsciiLetterOrDigit(c) || c is '-' or '_' or '.' ? c : '_').ToArray();
        var s = new string(chars).Trim('.');
        return s.Length is > 0 and <= 100 ? s : "invalid";
    }
}
