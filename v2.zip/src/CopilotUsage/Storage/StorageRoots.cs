namespace CopilotUsage.Storage;

/// <summary>A VS Code "User" data folder, which holds workspaceStorage, globalStorage and settings.json.</summary>
public sealed record StorageRoot(string Label, string UserDir)
{
    public string WorkspaceStorageDir => Path.Combine(UserDir, "workspaceStorage");
    public string GlobalStorageDir => Path.Combine(UserDir, "globalStorage");
    public string SettingsFile => Path.Combine(UserDir, "settings.json");
    public bool Exists => Directory.Exists(WorkspaceStorageDir) || Directory.Exists(GlobalStorageDir);
}

/// <summary>Finds the VS Code storage roots on this machine (FR-01).</summary>
public static class StorageRoots
{
    /// <summary>Every place VS Code may keep its data on this OS, found or not.</summary>
    public static IReadOnlyList<StorageRoot> Candidates()
    {
        var home = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        var list = new List<StorageRoot>();
        if (OperatingSystem.IsWindows())
        {
            var appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            list.Add(new("VS Code", Path.Combine(appData, "Code", "User")));
            list.Add(new("VS Code Insiders", Path.Combine(appData, "Code - Insiders", "User")));
        }
        else if (OperatingSystem.IsMacOS())
        {
            var support = Path.Combine(home, "Library", "Application Support");
            list.Add(new("VS Code", Path.Combine(support, "Code", "User")));
            list.Add(new("VS Code Insiders", Path.Combine(support, "Code - Insiders", "User")));
        }
        else
        {
            var config = Environment.GetEnvironmentVariable("XDG_CONFIG_HOME") is { Length: > 0 } x ? x : Path.Combine(home, ".config");
            list.Add(new("VS Code", Path.Combine(config, "Code", "User")));
            list.Add(new("VS Code Insiders", Path.Combine(config, "Code - Insiders", "User")));
        }
        // Remote and WSL sessions keep their data on the server side.
        list.Add(new("VS Code Server", Path.Combine(home, ".vscode-server", "data", "User")));
        list.Add(new("VS Code Server Insiders", Path.Combine(home, ".vscode-server-insiders", "data", "User")));
        return list;
    }

    /// <summary>The roots that exist, or only the --root override when given.</summary>
    public static IReadOnlyList<StorageRoot> Find(string? overridePath)
    {
        if (overridePath is not null)
        {
            var root = FromOverride(overridePath)
                ?? throw new CliException($"--root {overridePath}: no workspaceStorage or globalStorage folder found there");
            return [root];
        }
        return Candidates().Where(r => r.Exists).ToList();
    }

    /// <summary>Accepts a User folder, its parent (e.g. ...\Code), or a workspaceStorage / globalStorage folder.</summary>
    public static StorageRoot? FromOverride(string path)
    {
        var full = Path.GetFullPath(path).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        string[] tries =
        [
            full,
            Path.Combine(full, "User"),
            Path.Combine(full, "data", "User"),
            Path.GetDirectoryName(full) ?? full,
        ];
        foreach (var dir in tries)
        {
            var root = new StorageRoot("--root", dir);
            if (root.Exists) return root;
        }
        return null;
    }
}
