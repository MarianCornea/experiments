using System.Text.Json;

namespace CopilotUsage.Storage;

/// <summary>Reads workspace.json, which names the folder or .code-workspace file a storage hash belongs to.</summary>
public static class WorkspaceInfo
{
    public static string? ReadFolder(string workspaceStorageDir)
    {
        var file = Path.Combine(workspaceStorageDir, "workspace.json");
        if (!File.Exists(file)) return null;
        try
        {
            using var doc = JsonDocument.Parse(SafeFile.ReadAllText(file));
            foreach (var key in new[] { "folder", "workspace" })
                if (doc.RootElement.TryGetProperty(key, out var value) && value.ValueKind == JsonValueKind.String)
                    return UriToPath(value.GetString()!);
        }
        catch (Exception e) when (e is JsonException or IOException or UnauthorizedAccessException)
        {
        }
        return null;
    }

    /// <summary>file:///c%3A/dev/x → C:\dev\x. Remote URIs (vscode-remote://...) are returned decoded but otherwise unchanged.</summary>
    public static string UriToPath(string uri)
    {
        const string scheme = "file://";
        if (!uri.StartsWith(scheme, StringComparison.OrdinalIgnoreCase))
            return Uri.UnescapeDataString(uri);

        var rest = uri[scheme.Length..];
        int slash = rest.IndexOf('/');
        var host = slash < 0 ? rest : rest[..slash];
        var path = Uri.UnescapeDataString(slash < 0 ? "/" : rest[slash..]);

        if (host.Length > 0)
            return @"\\" + host + path.Replace('/', '\\');
        if (path.Length >= 3 && path[0] == '/' && char.IsLetter(path[1]) && path[2] == ':')
            return char.ToUpperInvariant(path[1]) + path[2..].Replace('/', '\\');
        return path;
    }
}
