namespace CopilotUsage.Storage;

/// <summary>
/// One VS Code chat transcript: chatSessions/&lt;session&gt;.jsonl, the file VS Code reloads a chat from. It records
/// Copilot's billed credits per request but no per-call tokens, so it is used only when the chat's debug log
/// has no model calls (logging was off, or Copilot wrote nothing there).
/// </summary>
public sealed record TranscriptSession(
    string Id,
    string File,
    StorageRoot? Root,
    string? WorkspaceStorageDir,
    string? WorkspaceFolder,
    DateTime LastWriteUtc) : ChatSession(Id, Path.GetDirectoryName(File)!, WorkspaceFolder, LastWriteUtc)
{
    public override SessionSource Source => SessionSource.Transcript;

    /// <summary>The state.vscdb that holds this session's title: the workspace's, or the global one.</summary>
    public string? StateDbPath =>
        WorkspaceStorageDir is not null ? Path.Combine(WorkspaceStorageDir, "state.vscdb")
        : Root is not null ? Path.Combine(Root.GlobalStorageDir, "state.vscdb")
        : null;

    /// <summary>A transcript file given directly with --dir.</summary>
    public static TranscriptSession FromFile(string file)
    {
        var full = Path.GetFullPath(file);
        // Inside workspaceStorage the layout is <hash>/chatSessions/<session>.jsonl.
        var wsDir = Path.GetDirectoryName(Path.GetDirectoryName(full));
        bool inWorkspace = wsDir is not null && System.IO.File.Exists(Path.Combine(wsDir, "workspace.json"));
        return new TranscriptSession(Path.GetFileNameWithoutExtension(full), full, null,
            inWorkspace ? wsDir : null, inWorkspace ? WorkspaceInfo.ReadFolder(wsDir!) : null, System.IO.File.GetLastWriteTimeUtc(full));
    }
}

/// <summary>Finds chat transcripts and merges them with the debug-log sessions of the Local harness.</summary>
public static class TranscriptCatalog
{
    public const string WorkspaceFolderName = "chatSessions";
    public const string EmptyWindowFolderName = "emptyWindowChatSessions";

    /// <summary>
    /// Every transcript in the new format (.jsonl). The older .json format records no usage and is skipped.
    /// </summary>
    public static List<TranscriptSession> FindAll(IEnumerable<StorageRoot> roots)
    {
        var found = new List<TranscriptSession>();
        foreach (var root in roots)
        {
            foreach (var wsDir in SessionCatalog.SafeEnumerateDirectories(root.WorkspaceStorageDir))
            {
                var dir = Path.Combine(wsDir, WorkspaceFolderName);
                var files = SessionCatalog.SafeEnumerateFiles(dir).Where(IsTranscript).ToList();
                if (files.Count == 0) continue;
                var folder = WorkspaceInfo.ReadFolder(wsDir);
                foreach (var f in files) found.Add(new TranscriptSession(Path.GetFileNameWithoutExtension(f), f, root, wsDir, folder, File.GetLastWriteTimeUtc(f)));
            }
            foreach (var f in SessionCatalog.SafeEnumerateFiles(Path.Combine(root.GlobalStorageDir, EmptyWindowFolderName)).Where(IsTranscript))
                found.Add(new TranscriptSession(Path.GetFileNameWithoutExtension(f), f, root, null, null, File.GetLastWriteTimeUtc(f)));
        }
        return found;
    }

    /// <summary>Count of older .json transcripts, which carry no usage (shown by doctor).</summary>
    public static int CountOldFormat(IEnumerable<StorageRoot> roots) =>
        roots.Sum(root => SessionCatalog.SafeEnumerateDirectories(root.WorkspaceStorageDir)
                              .Sum(ws => SessionCatalog.SafeEnumerateFiles(Path.Combine(ws, WorkspaceFolderName)).Count(f => f.EndsWith(".json", StringComparison.OrdinalIgnoreCase)))
                          + SessionCatalog.SafeEnumerateFiles(Path.Combine(root.GlobalStorageDir, EmptyWindowFolderName)).Count(f => f.EndsWith(".json", StringComparison.OrdinalIgnoreCase)));

    static bool IsTranscript(string file) => file.EndsWith(".jsonl", StringComparison.OrdinalIgnoreCase);

    /// <summary>
    /// The Local harness sessions: each debug log, except that a chat whose debug log has no model calls is read
    /// from its transcript instead; transcripts without a debug log are added. Newest activity first.
    /// </summary>
    public static List<ChatSession> Merge(List<DebugLogSession> debugLogs, List<TranscriptSession> transcripts)
    {
        var byId = transcripts.GroupBy(t => t.Id, StringComparer.OrdinalIgnoreCase).ToDictionary(g => g.Key, g => g.MaxBy(t => t.LastWriteUtc)!, StringComparer.OrdinalIgnoreCase);
        var result = new List<ChatSession>();
        foreach (var d in debugLogs)
        {
            if (byId.Remove(d.Id, out var t) && !HasModelCalls(d.Dir)) result.Add(t);
            else result.Add(d);
        }
        result.AddRange(byId.Values);
        result.Sort((a, b) => b.LastWriteUtc.CompareTo(a.LastWriteUtc));
        return result;
    }

    /// <summary>Whether any log file of a debug-log session holds a model call.</summary>
    public static bool HasModelCalls(string debugLogDir)
    {
        foreach (var file in SessionCatalog.SafeEnumerateFiles(debugLogDir).Where(f => f.EndsWith(".jsonl", StringComparison.OrdinalIgnoreCase)))
        {
            try
            {
                if (SafeFile.ReadAllText(file).Contains("\"llm_request\"", StringComparison.Ordinal)) return true;
            }
            catch (IOException) { }
        }
        return false;
    }
}
