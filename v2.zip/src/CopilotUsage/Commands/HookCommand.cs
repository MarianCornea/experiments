using System.Globalization;
using System.Text.Json;
using CopilotUsage.Storage;
using CopilotUsage.Tracking;

namespace CopilotUsage.Commands;

/// <summary>
/// copilot-usage hook --event &lt;name&gt; [--soft-budget &lt;credits&gt;] [--hard-budget &lt;credits&gt;] [--on-error open|closed]:
/// called by VS Code / the Copilot runtime, not by people. Reads one event from stdin and appends it to the session's
/// event file. Computes no cost, except the optional budget check before a tool call (FR-19):
/// <list type="bullet">
/// <item>over the soft limit, the next tool call is blocked once, with a message telling the agent to wrap up;</item>
/// <item>over the hard limit, the session is ended (continue: false) and every tool call is denied.</item>
/// </list>
/// Recording always fails open: an internal error exits 0 with no output, because the Copilot runtime treats a
/// failing preToolUse hook as a denial (NFR-11). Only the budget check honours --on-error closed.
/// </summary>
public static class HookCommand
{
    const int MaxInputChars = 16 * 1024 * 1024;

    public static int Run(IEnumerable<string> args, TextReader stdin, TextWriter stdout, TextWriter stderr)
    {
        string? eventName = null, softText = null, hardText = null, onError = null, eventsDir = null, cliHome = null, cacheFile = null;
        using (var e = args.GetEnumerator())
            while (e.MoveNext())
            {
                switch (e.Current)
                {
                    case "--event" when e.MoveNext(): eventName = e.Current; break;
                    case "--soft-budget" or "--budget" when e.MoveNext(): softText = e.Current; break; // --budget: hook files from before 2026-11-08
                    case "--hard-budget" when e.MoveNext(): hardText = e.Current; break;
                    case "--on-error" when e.MoveNext(): onError = e.Current; break;
                    case "--events-dir" when e.MoveNext(): eventsDir = e.Current; break;  // tests
                    case "--cli-root" when e.MoveNext(): cliHome = e.Current; break;      // tests
                    case "--spend-cache" when e.MoveNext(): cacheFile = e.Current; break; // tests
                }
            }
        double? soft = Credits(softText), hard = Credits(hardText);
        bool closed = string.Equals(onError, "closed", StringComparison.OrdinalIgnoreCase);
        bool budgetSet = soft is not null || hard is not null;
        // Before the input is read, a failed check can only be told apart by --event (VS Code input names the event itself).
        bool checkBudget = budgetSet && (eventName is null || IsName(eventName, "preToolUse"));
        eventsDir ??= ToolPaths.EventsDir;

        HookEvent? ev = null;
        try
        {
            var input = ReadCapped(stdin).TrimStart('﻿', ' ', '\r', '\n', '\t');
            if (input.Length == 0) return checkBudget && closed ? Stop(null, "error", 0, 0, "the hook received no input", stdout, eventsDir) : ExitCodes.Ok;
            using var doc = JsonDocument.Parse(input);
            ev = HookEvent.FromInput(doc.RootElement, eventName, DateTimeOffset.UtcNow);
            if (ev is null) return checkBudget && closed ? Stop(null, "error", 0, 0, "the hook input names no session", stdout, eventsDir) : ExitCodes.Ok;
            ev = ResolveRoot(ev, eventsDir);
            Record(ev, eventsDir);
        }
        catch (Exception e)
        {
            // Never fail the agent because recording failed. Keep the reason for doctor.
            LogError(e);
            if (ev is null)
                return checkBudget && closed ? Stop(null, "error", 0, 0, $"the hook could not read its input ({e.GetType().Name})", stdout, eventsDir) : ExitCodes.Ok;
        }

        if (!budgetSet || !IsEvent(ev, "preToolUse")) return ExitCodes.Ok;
        try
        {
            var spend = SpendCache.Update(ev.SessionId, cliHome ?? CliSessionCatalog.DefaultHome, StorageRoots.Find(null), cacheFile);
            if (hard is double h && spend.Credits >= h)
                return Stop(ev, "hard", spend.Credits, h, null, stdout, eventsDir);
            // The soft stop is given once per soft limit: the agent needs its tools to save its progress afterwards.
            if (soft is double s && spend.Credits >= s && !(spend.SoftStopAt >= s))
            {
                SpendCache.MarkSoftStop(ev.SessionId, s, cacheFile);
                return SoftStop(ev, spend.Credits, s, hard, stdout, stderr, eventsDir);
            }
        }
        catch (Exception e)
        {
            LogError(e);
            if (closed) return Stop(ev, "error", 0, 0, $"the budget check failed ({e.GetType().Name}: {e.Message})", stdout, eventsDir);
        }
        return ExitCodes.Ok;
    }

    public static string ErrorLog => Path.Combine(ToolPaths.DataDir, "hook-errors.log");

    static double? Credits(string? text) =>
        text is not null && double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var v) && v > 0 ? v : null;

    static void Record(HookEvent ev, string eventsDir)
    {
        Directory.CreateDirectory(eventsDir);
        if (IsEvent(ev, "subagentStart") && ev.AgentId is { Length: > 0 } agentId)
        {
            var alias = Path.Combine(eventsDir, "alias", ToolPaths.Safe(agentId));
            Directory.CreateDirectory(Path.GetDirectoryName(alias)!);
            File.WriteAllText(alias, ev.SessionId);
        }
        File.AppendAllText(Path.Combine(eventsDir, ToolPaths.Safe(ev.SessionId) + ".jsonl"), ev.ToJsonLine() + "\n");
    }

    /// <summary>A budgetStop event, so reports and probe P17 can tell what the hook decided and when.</summary>
    static void RecordStop(HookEvent? ev, string kind, double credits, double limit, string eventsDir)
    {
        if (ev is null) return;
        try
        {
            Record(ev with { Event = "budgetStop", Ts = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(), Budget = kind, Credits = credits, Limit = limit,
                             PromptLength = null, ResponseLength = null, UsageCommand = null, Cwd = null }, eventsDir);
        }
        catch (Exception e) { LogError(e); }
    }

    static void LogError(Exception e)
    {
        try
        {
            Directory.CreateDirectory(ToolPaths.DataDir);
            if (File.Exists(ErrorLog) && new FileInfo(ErrorLog).Length > 256 * 1024) File.Delete(ErrorLog);
            File.AppendAllText(ErrorLog, $"{DateTimeOffset.Now:o} {e.GetType().Name}: {e.Message}\n");
        }
        catch (Exception) { }
    }

    /// <summary>Reads stdin up to a cap; a larger payload (a huge tool result) is ignored rather than buffered.</summary>
    static string ReadCapped(TextReader stdin)
    {
        var sb = new System.Text.StringBuilder();
        var chunk = new char[64 * 1024];
        int n;
        while ((n = stdin.Read(chunk, 0, chunk.Length)) > 0)
        {
            if (sb.Length + n > MaxInputChars) return "";
            sb.Append(chunk, 0, n);
        }
        return sb.ToString();
    }

    /// <summary>Events from inside a sub-agent carry the sub-agent's own session ID; file them under the root session.</summary>
    static HookEvent ResolveRoot(HookEvent ev, string eventsDir)
    {
        var alias = Path.Combine(eventsDir, "alias", ToolPaths.Safe(ev.SessionId));
        if (!File.Exists(alias)) return ev;
        var root = File.ReadAllText(alias).Trim();
        return root.Length == 0 || root == ev.SessionId ? ev : ev with { SessionId = root, AgentId = ev.AgentId ?? ev.SessionId };
    }

    /// <summary>Soft limit: block this one tool call and tell the agent to wrap up.</summary>
    static int SoftStop(HookEvent ev, double used, double soft, double? hard, TextWriter stdout, TextWriter stderr, string eventsDir)
    {
        var reason = $"copilot-usage: soft budget of {soft:N2} credits reached ({used:N2} used). Wrap up now: stop starting new work, " +
                     "summarize what is done and what is left, update the progress file, show the cost (copilot-usage status) and ask the user before continuing." +
                     (hard is double h ? $" At {h:N2} credits the session is ended." : "");
        RecordStop(ev, "soft", used, soft, eventsDir);
        WriteJson(stdout, reason, endSession: false);
        // The Copilot runtime reads the JSON and wants exit 0; VS Code's Claude-style protocol blocks on exit 2 with the reason on stderr.
        if (ev.Format == "vscode")
        {
            stderr.Write(reason);
            return ExitCodes.BudgetExceeded;
        }
        return ExitCodes.Ok;
    }

    /// <summary>
    /// Hard limit, or a failed check under --on-error closed: end the session (continue: false, VS Code) and deny the
    /// tool call (the Copilot runtime has no continue field, so there every further tool call is denied).
    /// </summary>
    static int Stop(HookEvent? ev, string kind, double used, double limit, string? error, TextWriter stdout, string eventsDir)
    {
        var reason = error is null
            ? $"copilot-usage: hard budget of {limit:N2} credits reached ({used:N2} used). The session is stopped. " +
              "To continue, raise the limits with copilot-usage hooks install and resume."
            : $"copilot-usage: {error}. The budget is set to fail closed (--on-error closed), so the session is stopped.";
        RecordStop(ev, kind, used, limit, eventsDir);
        WriteJson(stdout, reason, endSession: true);
        return ExitCodes.Ok;
    }

    static void WriteJson(TextWriter stdout, string reason, bool endSession)
    {
        using var buffer = new MemoryStream();
        using (var w = new Utf8JsonWriter(buffer))
        {
            w.WriteStartObject();
            if (endSession)
            {
                w.WriteBoolean("continue", false);
                w.WriteString("stopReason", reason);
            }
            w.WriteString("permissionDecision", "deny");
            w.WriteString("permissionDecisionReason", reason);
            w.WriteStartObject("hookSpecificOutput");
            w.WriteString("hookEventName", "PreToolUse");
            w.WriteString("permissionDecision", "deny");
            w.WriteString("permissionDecisionReason", reason);
            w.WriteEndObject();
            w.WriteEndObject();
        }
        stdout.Write(System.Text.Encoding.UTF8.GetString(buffer.ToArray()));
    }

    static bool IsName(string? name, string expected) =>
        name is not null && (name.Equals(expected, StringComparison.OrdinalIgnoreCase) || name.Replace("_", "").Equals(expected, StringComparison.OrdinalIgnoreCase));

    static bool IsEvent(HookEvent ev, string name) => IsName(ev.Event, name);
}
