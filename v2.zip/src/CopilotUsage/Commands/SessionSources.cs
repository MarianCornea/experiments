using CopilotUsage.Cli;
using CopilotUsage.Storage;

namespace CopilotUsage.Commands;

/// <summary>
/// Reads --root (VS Code data, Local harness) and --cli-root (Copilot home, Copilot harness).
/// Without either, both default locations are searched; with one, only the given source is,
/// so a copied folder is never mixed with this machine's sessions.
/// </summary>
public sealed class SessionSources
{
    public IReadOnlyList<StorageRoot> VsCodeRoots { get; private init; } = [];
    public string? CliHome { get; private init; }

    public static SessionSources FromArgs(CliArgs args)
    {
        var root = args.Get("root");
        var cliRoot = args.Get("cli-root");
        bool overridden = root is not null || cliRoot is not null;
        if (cliRoot is not null && !Directory.Exists(CliSessionCatalog.StateDir(cliRoot)))
            throw new CliException($"--cli-root {cliRoot}: no session-state folder found there");
        return new SessionSources
        {
            VsCodeRoots = root is not null ? StorageRoots.Find(root) : overridden ? [] : StorageRoots.Find(null),
            CliHome = cliRoot ?? (overridden ? null : CliSessionCatalog.DefaultHome),
        };
    }

    /// <summary>Sessions from both sources, newest activity first.</summary>
    public List<ChatSession> FindAll()
    {
        var all = new List<ChatSession>();
        all.AddRange(TranscriptCatalog.Merge(SessionCatalog.FindAll(VsCodeRoots), TranscriptCatalog.FindAll(VsCodeRoots)));
        all.AddRange(CliSessionCatalog.FindAll(CliHome));
        all.Sort((a, b) => b.LastWriteUtc.CompareTo(a.LastWriteUtc));
        return all;
    }
}
