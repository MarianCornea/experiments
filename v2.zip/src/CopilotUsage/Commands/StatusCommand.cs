using System.Text.Json;
using CopilotUsage.Analysis;
using CopilotUsage.Cli;
using CopilotUsage.Model;
using static CopilotUsage.Commands.InSession;

namespace CopilotUsage.Commands;

/// <summary>
/// copilot-usage status: the session total so far, the current context size and the cost of each agent run (FR-12, FR-18).
/// At most 12 lines, because the agent carries the output in every later call (NFR-10).
/// </summary>
public static class StatusCommand
{
    public static int Run(CliArgs args, TextWriter o)
    {
        var s = InSession.FromArgs(args, "status");
        var data = s.Load();
        var calls = data.SuccessfulCalls.ToList();
        if (calls.Count == 0)
        {
            o.WriteLine($"SESSION {Short(s.Session.Id)}: no model calls logged yet (the log lags a few seconds)");
            return ExitCodes.NoNewData;
        }

        double total = data.TotalCredits;
        var mainCalls = calls.Where(c => c.AgentRunId == AgentRun.MainId).ToList();
        long contextNow = (mainCalls.Count > 0 ? mainCalls : calls)[^1].Input;
        var runs = Breakdown.By(data, Dimension.AgentRun);
        var phases = Breakdown.By(data, Dimension.Phase).Where(r => r.Key != Breakdown.NoPhase).ToList();
        var duration = (data.LastEvent ?? DateTimeOffset.UtcNow) - (data.FirstEvent ?? DateTimeOffset.UtcNow);
        var (exit, budgetLine) = s.BudgetCheck(total);

        if (s.Json)
        {
            o.WriteLine(JsonSerializer.Serialize(new
            {
                session = s.Session.Id,
                identifiedBy = s.Identified.Method,
                credits = Math.Round(total, 4),
                billedShare = Math.Round(BilledShare(calls), 4),
                calls = calls.Count,
                durationSeconds = (int)duration.TotalSeconds,
                contextNow,
                usableContext = (mainCalls.Count > 0 ? mainCalls : calls)[^1].MaxPromptTokens,
                peakContext = calls.Max(c => c.Input),
                overLongContext = calls.Count(c => c.Cost.LongContext),
                cachedShare = Math.Round(calls.Sum(c => (double)c.CacheRead) / Math.Max(1, calls.Sum(c => c.Input)), 4),
                agentRuns = runs.Select(r => new { run = r.Key, calls = r.Calls, credits = Math.Round(r.Credits, 4) }),
                phases = phases.Select(r => new { phase = r.Key, calls = r.Calls, credits = Math.Round(r.Credits, 4) }),
                budget = s.Budget,
                budgetExceeded = exit == ExitCodes.BudgetExceeded,
            }));
            return exit;
        }

        o.WriteLine($"SESSION {Short(s.Session.Id)}  {Credits(total)} credits ({Percent(BilledShare(calls))} billed)  {data.ModelCallCountText} calls  {InSession.Duration(duration)}");
        var lastCall = (mainCalls.Count > 0 ? mainCalls : calls)[^1];
        var usable = lastCall.MaxPromptTokens is long u && u > 0 ? $" of {Tokens(u)} usable" : "";
        o.WriteLine($"context now {Tokens(contextNow)}{usable} | peak {Tokens(calls.Max(c => c.Input))} | long context: {calls.Count(c => c.Cost.LongContext)} | " +
                    (data.PerRequest ? "cached n/a (chat transcript)" : $"cached {Percent(calls.Sum(c => (double)c.CacheRead) / Math.Max(1, calls.Sum(c => c.Input)))}"));
        o.WriteLine("agent runs: " + Join(runs.Select(r => (r.Key, r.Credits)), 5));
        if (phases.Count > 0) o.WriteLine("phases: " + Join(phases.Select(r => (r.Key + (data.Phases.Any(p => p.Name == r.Key && p.End is null) ? " (open)" : ""), r.Credits)), 5));
        if (!data.PerRequest) o.WriteLine("cost by cause: " + Causes(calls));
        if (budgetLine is not null) o.WriteLine(budgetLine);
        return exit;
    }

    internal static string Join(IEnumerable<(string Name, double Credits)> items, int max)
    {
        var list = items.ToList();
        var shown = string.Join(" · ", list.Take(max).Select(i => $"{i.Name} {Credits(i.Credits)}"));
        return list.Count > max ? shown + $" · +{list.Count - max} more" : shown;
    }

    internal static string Short(string id) => id.Length > 8 ? id[..8] : id;
}
