using System.Globalization;
using System.Text.Json;
using System.Text.Json.Nodes;
using CopilotUsage.Cli;
using CopilotUsage.Storage;
using CopilotUsage.Tracking;

namespace CopilotUsage.Commands;

/// <summary>
/// copilot-usage hooks install|remove --scope repo|user: writes the hook file that points the hook events at
/// "copilot-usage hook" (FR-17). One Copilot-CLI-format file works for both harnesses: the Copilot runtime reads
/// it directly and VS Code maps its camelCase event names.
/// </summary>
public static class HooksCommand
{
    public const string FileName = "copilot-usage.json";

    /// <summary>Events recorded by default. preToolUse also identifies the calling session and runs the budget check.</summary>
    public static readonly string[] DefaultEvents =
        ["sessionStart", "userPromptSubmitted", "preToolUse", "subagentStart", "subagentStop", "agentStop", "preCompact", "sessionEnd"];

    public static int Run(CliArgs args, TextWriter o)
    {
        var action = args.Positionals.FirstOrDefault() ?? throw new CliException("usage: copilot-usage hooks install|remove --scope repo|user");
        var scope = args.Get("scope") ?? "repo";
        var softText = args.Get("soft-budget") ?? args.Get("budget"); // --budget: the single limit before 2026-11-08
        var hardText = args.Get("hard-budget");
        var onError = args.Get("on-error") ?? "open";
        bool toolSizes = args.Has("tool-sizes");
        bool noPreTool = args.Has("no-pre-tool");
        bool skill = args.Has("skill");
        var exeOverride = args.Get("exe");
        var target = args.Get("dir"); // the repository (repo scope) or Copilot home (user scope) to write into
        args.RejectUnknown();

        if (scope is not ("repo" or "user")) throw new CliException("--scope must be repo or user");
        var limits = new BudgetLimits(Credits(softText, "--soft-budget"), Credits(hardText, "--hard-budget"), onError.ToLowerInvariant());
        if (limits.OnError is not ("open" or "closed")) throw new CliException("--on-error must be open or closed");
        if (limits.Soft is double sl && limits.Hard is double hl && hl <= sl) throw new CliException("--hard-budget must be higher than --soft-budget");
        if (limits.OnError == "closed" && !limits.Any) throw new CliException("--on-error applies to the budget check: set --soft-budget or --hard-budget");

        var baseDir = target ?? (scope == "repo" ? RepoRoot(Directory.GetCurrentDirectory()) : CliSessionCatalog.DefaultHome);
        var hookFile = HookFilePath(scope, baseDir);
        var skillFile = SkillFilePath(scope, baseDir);

        switch (action)
        {
            case "install":
            {
                var exe = exeOverride ?? DefaultExe();
                var events = DefaultEvents.Where(e => !(noPreTool && e == "preToolUse") || limits.Any).ToList();
                if (toolSizes) events.Add("postToolUse");
                Directory.CreateDirectory(Path.GetDirectoryName(hookFile)!);
                File.WriteAllText(hookFile, BuildHookFile(exe, events, limits) + Environment.NewLine);
                o.WriteLine($"Hooks written: {hookFile}");
                o.WriteLine($"  events: {string.Join(", ", events)}");
                if (limits.Any)
                    o.WriteLine($"  budget (checked before each tool call): {limits.Describe()}");
                o.WriteLine($"  command: {exe} hook --event <name>");
                if (skill)
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(skillFile)!);
                    File.WriteAllText(skillFile, WorkflowCostSkill.Content(exe) + Environment.NewLine);
                    o.WriteLine($"Skill written: {skillFile}");
                }
                o.WriteLine("Start a new chat (or reload the window) so Copilot loads them. Events are recorded in " + ToolPaths.EventsDir);
                return ExitCodes.Ok;
            }
            case "remove":
            {
                bool removed = false;
                foreach (var f in new[] { hookFile, skillFile })
                    if (File.Exists(f)) { File.Delete(f); o.WriteLine($"Removed {f}"); removed = true; }
                var skillDir = Path.GetDirectoryName(skillFile)!;
                if (Directory.Exists(skillDir) && !Directory.EnumerateFileSystemEntries(skillDir).Any()) Directory.Delete(skillDir);
                if (!removed) o.WriteLine($"Nothing to remove: {hookFile} does not exist");
                return ExitCodes.Ok;
            }
            default:
                throw new CliException($"unknown hooks action '{action}': use install or remove");
        }
    }

    public static string HookFilePath(string scope, string baseDir) =>
        scope == "repo" ? Path.Combine(baseDir, ".github", "hooks", FileName) : Path.Combine(baseDir, "hooks", FileName);

    public static string SkillFilePath(string scope, string baseDir) =>
        scope == "repo"
            ? Path.Combine(baseDir, ".github", "skills", WorkflowCostSkill.FolderName, "SKILL.md")
            : Path.Combine(baseDir, "skills", WorkflowCostSkill.FolderName, "SKILL.md");

    static double? Credits(string? text, string option) =>
        text is null ? null
        : double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var v) && v > 0 ? v
        : throw new CliException($"{option} expects a positive number of credits");

    public static string BuildHookFile(string exe, IEnumerable<string> events, BudgetLimits? limits = null)
    {
        var hooks = new JsonObject();
        foreach (var e in events)
        {
            var extra = e == "preToolUse" && limits is { Any: true } ? limits.HookArguments() : "";
            hooks[e] = new JsonArray(new JsonObject
            {
                ["type"] = "command",
                ["bash"] = $"{BashQuote(exe)} hook --event {e}{extra}",
                ["powershell"] = $"& {PowerShellQuote(exe)} hook --event {e}{extra}",
                ["timeoutSec"] = 5,
            });
        }
        return new JsonObject { ["version"] = 1, ["hooks"] = hooks }.ToJsonString(new JsonSerializerOptions
        {
            WriteIndented = true,
            Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping, // keep & and quotes readable
        });
    }

    /// <summary>The running executable when it is copilot-usage itself (a published or built binary), else the name on PATH.</summary>
    static string DefaultExe()
    {
        var path = Environment.ProcessPath;
        return path is not null && Path.GetFileNameWithoutExtension(path).Equals("copilot-usage", StringComparison.OrdinalIgnoreCase)
            ? path
            : "copilot-usage";
    }

    /// <summary>The git root above the folder, or the folder itself.</summary>
    public static string RepoRoot(string start)
    {
        for (var dir = new DirectoryInfo(start); dir is not null; dir = dir.Parent)
            if (Directory.Exists(Path.Combine(dir.FullName, ".git")) || File.Exists(Path.Combine(dir.FullName, ".git")))
                return dir.FullName;
        return start;
    }

    static string PowerShellQuote(string s) => s.Contains(' ') || s.Contains('\\') ? "'" + s.Replace("'", "''") + "'" : s;

    static string BashQuote(string s)
    {
        // C:\x\y.exe → /c/x/y.exe for Git Bash / MSYS shells.
        if (s.Length > 2 && s[1] == ':' && char.IsLetter(s[0])) s = "/" + char.ToLowerInvariant(s[0]) + s[2..].Replace('\\', '/');
        return s.Contains(' ') || s.Contains('\'') ? "'" + s.Replace("'", "'\\''") + "'" : s;
    }
}

/// <summary>The two session budget limits and the error mode, stored as arguments on the preToolUse hook command (FR-19).</summary>
public sealed record BudgetLimits(double? Soft, double? Hard, string OnError = "open")
{
    public bool Any => Soft is not null || Hard is not null;

    public string HookArguments()
    {
        var s = "";
        if (Soft is double soft) s += " --soft-budget " + soft.ToString(System.Globalization.CultureInfo.InvariantCulture);
        if (Hard is double hard) s += " --hard-budget " + hard.ToString(System.Globalization.CultureInfo.InvariantCulture);
        if (OnError == "closed") s += " --on-error closed";
        return s;
    }

    public string Describe() =>
        string.Join("; ", new[]
        {
            Soft is double s ? $"soft {s:N2} credits (blocks the next tool call once, so the agent wraps up)" : null,
            Hard is double h ? $"hard {h:N2} credits (ends the session)" : null,
            OnError == "closed" ? "a failed check stops the session (--on-error closed)" : "a failed check lets the call through",
        }.Where(x => x is not null));
}
