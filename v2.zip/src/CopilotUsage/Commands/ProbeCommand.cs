using System.Text.Json;
using CopilotUsage.Cli;
using CopilotUsage.Pricing;
using CopilotUsage.Probe;
using CopilotUsage.Storage;

namespace CopilotUsage.Commands;

/// <summary>copilot-usage probe &lt;session&gt;: checks a session against the expected format and writes a fingerprint.</summary>
public static class ProbeCommand
{
    public static int Run(CliArgs args, TextWriter o)
    {
        var dir = args.Get("dir");
        var outPath = args.Get("out");
        var pricingPath = args.Get("pricing");
        bool live = args.Has("live");
        var sources = SessionSources.FromArgs(args);
        args.RejectUnknown();
        if (args.Positionals.Count > 1) throw new CliException("probe takes one <session>");

        var pricing = PricingTable.Load(pricingPath);
        var sessions = dir is null ? sources.FindAll() : [];
        var session = SessionSelector.Select(args.Positionals.FirstOrDefault(), dir, sessions);

        var options = new ProbeOptions { Live = live, Pricing = pricing };
        var result = session switch
        {
            DebugLogSession d => Prober.Run(d, options),
            CliSession c => CliProber.Run(c, options),
            TranscriptSession t => TranscriptProber.Run(t, options),
            _ => throw new CliException("unsupported session type"),
        };

        outPath ??= Path.Combine(Directory.GetCurrentDirectory(), $"probe-{session.Id}.json");
        File.WriteAllText(outPath, result.Fingerprint.ToJsonString(new JsonSerializerOptions { WriteIndented = true }) + Environment.NewLine);

        Print(result, outPath, o);
        return result.GatePassed ? ExitCodes.Ok : ExitCodes.Error;
    }

    static void Print(ProbeResult r, string outPath, TextWriter o)
    {
        var s = r.Session;
        var versions = string.Join(", ", new[] { r.CopilotVersion is null ? null : "Copilot " + r.CopilotVersion, r.VsCodeVersion is null ? null : "VS Code " + r.VsCodeVersion }.Where(v => v is not null));
        o.WriteLine($"Probe   {s.Id}{(versions.Length > 0 ? "  (" + versions + ")" : "")}");
        o.WriteLine($"Source  {s.SourceLabel}");
        if (r.Title is not null) o.WriteLine($"Title   {r.Title}");
        if (s.WorkspaceFolder is not null) o.WriteLine($"Folder  {s.WorkspaceFolder}");
        o.WriteLine($"Files   {r.FilesSummary}");
        o.WriteLine();
        foreach (var c in r.Checks)
            o.WriteLine($"{Label(c.Outcome),-5} {c.Id,-4} {c.Name,-17} {c.Detail}");
        o.WriteLine();
        o.WriteLine(r.GatePassed
            ? "Gate G0 passed: P1–P3 hold, so the session format can be trusted."
            : "Gate G0 failed: " + string.Join(", ", r.Checks.Where(c => c.Outcome == CheckOutcome.Fail).Select(c => c.Id)) + " did not pass; reports cannot be built on this data.");
        o.WriteLine($"Fingerprint: {outPath} (structure only, no content; safe to share)");
    }

    static string Label(CheckOutcome outcome) => outcome switch
    {
        CheckOutcome.Pass => "PASS",
        CheckOutcome.Warn => "WARN",
        CheckOutcome.Fail => "FAIL",
        CheckOutcome.Info => "INFO",
        _ => "SKIP",
    };
}
