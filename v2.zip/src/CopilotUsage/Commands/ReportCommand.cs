using System.Diagnostics;
using CopilotUsage.Analysis;
using CopilotUsage.Cli;
using CopilotUsage.Pricing;
using CopilotUsage.Probe;
using CopilotUsage.Report;
using CopilotUsage.Storage;

namespace CopilotUsage.Commands;

/// <summary>copilot-usage report &lt;session&gt; [--out file] [--open] [--pricing file]: writes the HTML report for one session (FR-09).</summary>
public static class ReportCommand
{
    public static int Run(CliArgs args, TextWriter o)
    {
        var dir = args.Get("dir");
        var outPath = args.Get("out");
        bool open = args.Has("open");
        var pricing = PricingTable.Load(args.Get("pricing"));
        var mcpMap = args.Get("mcp-map") is { } mapPath ? McpMap.Load(mapPath) : null;
        var sources = SessionSources.FromArgs(args);
        args.RejectUnknown();
        if (args.Positionals.Count > 1) throw new CliException("report takes one <session>");

        var session = SessionSelector.Select(args.Positionals.FirstOrDefault(), dir, dir is null ? sources.FindAll() : []);
        var data = SessionLoader.Load(session, pricing);
        var probeOptions = new ProbeOptions { Pricing = pricing };
        var probe = session switch
        {
            DebugLogSession d => Prober.Run(d, probeOptions),
            CliSession c => CliProber.Run(c, probeOptions),
            TranscriptSession t => TranscriptProber.Run(t, probeOptions),
            _ => null,
        };

        outPath ??= DefaultPath(session);
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(outPath))!);
        File.WriteAllText(outPath, HtmlReport.Build(data, pricing, probe, mcpMap: mcpMap));

        var calls = data.ModelCallCountText;
        o.WriteLine($"Report: {Path.GetFullPath(outPath)}");
        o.WriteLine($"  {data.Title ?? session.Id}: {Findings.Cr(data.TotalCredits)} credits, {calls} calls{(probe is { GatePassed: false } ? " — format check FAILED, see the report header" : "")}");
        if (open) Open(outPath);
        return ExitCodes.Ok;
    }

    /// <summary>%LOCALAPPDATA%\copilot-usage\reports\&lt;id8&gt;-&lt;yyyyMMdd-HHmm&gt;.html: the tool's own folder, never the workspace.</summary>
    static string DefaultPath(ChatSession s) =>
        Path.Combine(ToolPaths.DataDir, "reports", $"{s.Id[..Math.Min(8, s.Id.Length)]}-{DateTime.Now:yyyyMMdd-HHmm}.html");

    static void Open(string path)
    {
        try
        {
            var full = Path.GetFullPath(path);
            if (OperatingSystem.IsWindows()) Process.Start(new ProcessStartInfo(full) { UseShellExecute = true });
            else if (OperatingSystem.IsMacOS()) Process.Start("open", full);
            else Process.Start("xdg-open", full);
        }
        catch (Exception e) when (e is System.ComponentModel.Win32Exception or InvalidOperationException)
        {
            throw new CliException($"report written, but it could not be opened: {e.Message}");
        }
    }
}
