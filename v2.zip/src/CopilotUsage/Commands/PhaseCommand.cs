using System.Text.Json;
using CopilotUsage.Analysis;
using CopilotUsage.Cli;
using CopilotUsage.Model;
using CopilotUsage.Tracking;
using static CopilotUsage.Commands.InSession;

namespace CopilotUsage.Commands;

/// <summary>
/// copilot-usage phase start|end &lt;name&gt;: the agent-driven fallback for phases that hooks cannot see (FR-10, FR-12).
/// start saves a checkpoint; end adds up every call in the session between the two, across all agents.
/// </summary>
public static class PhaseCommand
{
    public static int Run(CliArgs args, TextWriter o)
    {
        if (args.Positionals.Count != 2 || args.Positionals[0] is not ("start" or "end"))
            throw new CliException("usage: copilot-usage phase start|end <name>");
        var action = args.Positionals[0];
        var name = args.Positionals[1].Trim();
        if (name.Length is 0 or > 80) throw new CliException("phase name must be 1 to 80 characters");

        var s = InSession.FromArgs(args, "phase " + action);
        var now = DateTimeOffset.UtcNow;

        if (action == "start")
        {
            var marker = Checkpoints.NewMarker();
            Checkpoints.Add(s.Session.Id, new Checkpoint(name, Checkpoint.Start, now.ToUnixTimeMilliseconds(), marker));
            if (s.Json)
                o.WriteLine(JsonSerializer.Serialize(new { phase = name, started = now, session = s.Session.Id, identifiedBy = s.Identified.Method, marker }));
            else
                o.WriteLine($"PHASE {name} started {now.ToLocalTime():HH:mm:ss} | session {StatusCommand.Short(s.Session.Id)} ({s.Identified.Method}) | {marker}");
            return ExitCodes.Ok;
        }

        var started = Checkpoints.Spans(Checkpoints.Load(s.Session.Id)).LastOrDefault(p => p.Name == name && p.End is null)
            ?? throw new CliException($"phase '{name}' was not started in this session (run: copilot-usage phase start {name})");
        Checkpoints.Add(s.Session.Id, new Checkpoint(name, Checkpoint.End, now.ToUnixTimeMilliseconds()));

        var data = s.Load();
        var span = new PhaseSpan(name, started.Start, now);
        var calls = data.SuccessfulCalls.Where(c => span.Contains(c.Start)).ToList();
        double sessionTotal = data.TotalCredits;
        var (exit, budgetLine) = s.BudgetCheck(sessionTotal);
        if (calls.Count == 0)
        {
            o.WriteLine($"PHASE {name}: no model calls logged between {span.Start.ToLocalTime():HH:mm:ss} and now yet (the log lags a few seconds)");
            return exit == ExitCodes.BudgetExceeded ? exit : ExitCodes.NoNewData;
        }

        var phaseData = Subset(data, calls);
        var growth = ContextGrowth.Analyze(phaseData).Tools.Where(t => t.InferredGrowth > 0).Take(3).ToList();
        var agents = Breakdown.By(phaseData, Dimension.AgentRun);
        double credits = calls.Sum(c => c.Cost.Credits);
        var duration = now - span.Start;

        if (s.Json)
        {
            o.WriteLine(JsonSerializer.Serialize(new
            {
                phase = name,
                session = s.Session.Id,
                credits = Math.Round(credits, 4),
                billedShare = Math.Round(BilledShare(calls), 4),
                calls = calls.Count,
                durationSeconds = (int)duration.TotalSeconds,
                inputTokens = calls.Sum(c => c.Input),
                cachedShare = Math.Round(calls.Sum(c => (double)c.CacheRead) / Math.Max(1, calls.Sum(c => c.Input)), 4),
                outputTokens = calls.Sum(c => c.Output),
                peakContext = calls.Max(c => c.Input),
                overLongContext = calls.Count(c => c.Cost.LongContext),
                agentRuns = agents.Select(r => new { run = r.Key, credits = Math.Round(r.Credits, 4) }),
                contextGrowth = growth.Select(g => new { tool = g.Tool, tokens = (long)g.InferredGrowth }),
                sessionCredits = Math.Round(sessionTotal, 4),
                budget = s.Budget,
                budgetExceeded = exit == ExitCodes.BudgetExceeded,
            }));
            return exit;
        }

        long input = calls.Sum(c => c.Input);
        o.WriteLine($"PHASE {name}  {Credits(credits)} credits ({Percent(BilledShare(calls))} billed)  {calls.Count} calls  {InSession.Duration(duration)}");
        o.WriteLine($"input {Tokens(input)} tokens, {Percent(calls.Sum(c => (double)c.CacheRead) / Math.Max(1, input))} cached | output {Tokens(calls.Sum(c => c.Output))} | " +
                    $"peak context {Tokens(calls.Max(c => c.Input))} | long context: {calls.Count(c => c.Cost.LongContext)}");
        o.WriteLine("cost by cause: " + Causes(calls));
        if (agents.Count > 1) o.WriteLine("by agent run: " + StatusCommand.Join(agents.Select(r => (r.Key, r.Credits)), 4));
        if (growth.Count > 0) o.WriteLine("context growth: " + string.Join(", ", growth.Select(g => $"{g.Tool} +{Tokens(g.InferredGrowth)}")));
        o.WriteLine($"session so far: {Credits(sessionTotal)} credits" + (budgetLine is null ? "" : " | " + budgetLine));
        return exit;
    }

    /// <summary>A copy of the session holding only the given calls, so the breakdowns and growth run on the phase alone.</summary>
    static SessionData Subset(SessionData data, List<ModelCall> calls)
    {
        var sub = new SessionData { Session = data.Session };
        sub.Calls.AddRange(calls);
        var first = calls.Min(c => c.Start);
        var last = calls.Max(c => c.End);
        sub.Tools.AddRange(data.Tools.Where(t => t.Start >= first && t.Start <= last));
        foreach (var (id, run) in data.Runs) sub.Runs[id] = run;
        return sub;
    }
}
