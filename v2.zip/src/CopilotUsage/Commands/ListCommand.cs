using System.Globalization;
using CopilotUsage.Analysis;
using CopilotUsage.Cli;
using CopilotUsage.Model;
using CopilotUsage.Pricing;
using CopilotUsage.Storage;

namespace CopilotUsage.Commands;

/// <summary>copilot-usage list: sessions newest first, with status, calls and credits (FR-03).</summary>
public static class ListCommand
{
    /// <summary>A session is active when its log changed within this window (spec decision, adjustable).</summary>
    public static readonly TimeSpan ActiveWindow = TimeSpan.FromMinutes(10);

    public static int Run(CliArgs args, TextWriter o)
    {
        int limit = args.GetInt("limit") ?? 20;
        int? days = args.GetInt("days");
        var folder = args.Get("folder");
        bool includeEmpty = args.Has("include-empty");
        var pricing = PricingTable.Load(args.Get("pricing"));
        var sources = SessionSources.FromArgs(args);
        args.RejectUnknown();
        if (limit < 1) throw new CliException("--limit must be at least 1");

        var sessions = sources.FindAll();
        var now = DateTime.UtcNow;
        var titles = new SessionTitles();
        var rows = new List<(int Index, ChatSession Session, SessionData Data)>();
        int hiddenEmpty = 0;

        for (int i = 0; i < sessions.Count && rows.Count < limit; i++)
        {
            var s = sessions[i];
            if (days is int d && s.LastWriteUtc < now.AddDays(-d)) break; // newest first: the rest are older
            if (folder is not null && !(s.WorkspaceFolder ?? "").Contains(folder, StringComparison.OrdinalIgnoreCase)) continue;
            var data = SessionLoader.Load(s, pricing, titles);
            if (!includeEmpty && !data.SuccessfulCalls.Any()) { hiddenEmpty++; continue; }
            rows.Add((i + 1, s, data));
        }

        if (rows.Count == 0)
        {
            o.WriteLine(sessions.Count == 0 ? "No sessions found. Run copilot-usage doctor to see where it looked." : "No sessions match.");
            if (hiddenEmpty > 0) o.WriteLine($"{hiddenEmpty} sessions without model calls hidden; add --include-empty to show them.");
            return ExitCodes.Ok;
        }

        o.WriteLine($"{"#",-3} {"Last activity",-16}  {"Started",-16}  {"Status",-6}  {"Harness",-7}  {"Calls",5}  {"Credits",8}  {"Folder",-28}  Title");
        bool anyEstimated = false;
        foreach (var (index, s, data) in rows)
        {
            var calls = data.ModelCallCountText;
            bool estimated = data.Calls.Any(c => c.Cost.Source is CostSource.Estimated or CostSource.Unpriced);
            anyEstimated |= estimated;
            var credits = data.TotalCredits.ToString("N2", CultureInfo.InvariantCulture) + (estimated ? "*" : " ");
            o.WriteLine(
                $"{index,-3} {Local(s.LastWriteUtc),-16}  {(data.FirstEvent is { } f ? Local(f.UtcDateTime) : ""),-16}  " +
                $"{(now - s.LastWriteUtc < ActiveWindow ? "active" : "idle"),-6}  {(s.Source == SessionSource.CopilotCli ? "Copilot" : "Local"),-7}  " +
                $"{calls,5}  {credits,8}  {Clip(s.WorkspaceFolder ?? "", 28, keepEnd: true),-28}  {Clip(data.Title ?? s.Id, 60)}");
        }
        if (anyEstimated) o.WriteLine("* includes estimated or unpriced calls; other totals are billed credits");
        if (hiddenEmpty > 0) o.WriteLine($"{hiddenEmpty} sessions without model calls hidden; add --include-empty to show them.");
        return ExitCodes.Ok;
    }

    static string Local(DateTime utc) => DateTime.SpecifyKind(utc, DateTimeKind.Utc).ToLocalTime().ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture);

    internal static string Clip(string s, int width, bool keepEnd = false) =>
        s.Length <= width ? s : keepEnd ? "…" + s[^(width - 1)..] : s[..(width - 1)] + "…";
}
