using System.Diagnostics;
using CopilotUsage.Analysis;
using CopilotUsage.Cli;
using CopilotUsage.Pricing;
using CopilotUsage.Report;
using CopilotUsage.Storage;

namespace CopilotUsage.Commands;

/// <summary>copilot-usage compare &lt;A&gt; &lt;B&gt;: one HTML report explaining why run B cost more or less than run A (FR-11).</summary>
public static class CompareCommand
{
    public static int Run(CliArgs args, TextWriter o)
    {
        var labelA = args.Get("label-a") ?? "A";
        var labelB = args.Get("label-b") ?? "B";
        var byText = args.Get("by") ?? "agent";
        var outPath = args.Get("out");
        bool open = args.Has("open");
        var pricing = PricingTable.Load(args.Get("pricing"));
        var mcpMap = args.Get("mcp-map") is { } mapPath ? McpMap.Load(mapPath) : null;
        var sources = SessionSources.FromArgs(args);
        args.RejectUnknown();
        if (args.Positionals.Count != 2) throw new CliException("usage: copilot-usage compare <A> <B> [--label-a <name>] [--label-b <name>] [--by phase|agent|skill|model] [--mcp-map <file>]");
        var by = byText.ToLowerInvariant() switch
        {
            "agent" => Dimension.Agent,
            "phase" => Dimension.Phase,
            "skill" => Dimension.Skill,
            "model" => Dimension.Model,
            _ => throw new CliException("--by must be phase, agent, skill or model"),
        };

        var sessions = sources.FindAll();
        var titles = new SessionTitles();
        var a = SessionLoader.Load(SessionSelector.Select(args.Positionals[0], null, sessions), pricing, titles);
        var b = SessionLoader.Load(SessionSelector.Select(args.Positionals[1], null, sessions), pricing, titles);
        var comparison = Comparison.Build(a, b, by, labelA, labelB, pricing, mcpMap);

        outPath ??= Path.Combine(ToolPaths.DataDir, "reports",
            $"compare-{Short(a.Session.Id)}-{Short(b.Session.Id)}-{DateTime.Now:yyyyMMdd-HHmm}.html");
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(outPath))!);
        File.WriteAllText(outPath, CompareReport.Build(comparison));

        o.WriteLine($"Comparison: {Path.GetFullPath(outPath)}");
        o.WriteLine($"  {labelA} {Findings.Cr(comparison.TotalA)} → {labelB} {Findings.Cr(comparison.TotalB)} credits " +
                    $"({(comparison.Delta >= 0 ? "+" : "−")}{Findings.Cr(Math.Abs(comparison.Delta))})");
        if (comparison.ChangeFindings.FirstOrDefault() is { } top) o.WriteLine("  " + top.Text);
        if (comparison.Warnings.Count > 0) o.WriteLine($"  {comparison.Warnings.Count} comparability warning(s): see the report");
        if (open)
        {
            try
            {
                var full = Path.GetFullPath(outPath);
                if (OperatingSystem.IsWindows()) Process.Start(new ProcessStartInfo(full) { UseShellExecute = true });
                else Process.Start(OperatingSystem.IsMacOS() ? "open" : "xdg-open", full);
            }
            catch (Exception e) when (e is System.ComponentModel.Win32Exception or InvalidOperationException)
            {
                throw new CliException($"comparison written, but it could not be opened: {e.Message}");
            }
        }
        return ExitCodes.Ok;
    }

    static string Short(string id) => id[..Math.Min(8, id.Length)];
}
