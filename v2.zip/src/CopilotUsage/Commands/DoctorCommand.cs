using CopilotUsage.Cli;
using CopilotUsage.Storage;

namespace CopilotUsage.Commands;

/// <summary>copilot-usage doctor: storage roots, sessions with debug logs, the debug-log setting and hooks.</summary>
public static class DoctorCommand
{
    public static int Run(CliArgs args, TextWriter o)
    {
        var rootOverride = args.Get("root");
        var cliRoot = args.Get("cli-root");
        args.RejectUnknown();
        bool overridden = rootOverride is not null || cliRoot is not null;

        var roots = rootOverride is not null ? StorageRoots.Find(rootOverride) : overridden ? [] : StorageRoots.Candidates();
        var cliHome = cliRoot ?? (overridden ? null : CliSessionCatalog.DefaultHome);
        o.WriteLine("Local harness (VS Code storage, debug logs)");
        int totalSessions = 0, totalChatFiles = 0;
        bool anyRoot = false;
        foreach (var root in roots)
        {
            if (!root.Exists) { o.WriteLine($"  {root.Label,-24} not found"); continue; }
            anyRoot = true;
            int workspaces = SessionCatalog.SafeEnumerateDirectories(root.WorkspaceStorageDir).Count();
            int withChat = 0, chatFiles = 0;
            foreach (var ws in SessionCatalog.SafeEnumerateDirectories(root.WorkspaceStorageDir))
            {
                int n = SessionCatalog.SafeEnumerateFiles(Path.Combine(ws, "chatSessions")).Count();
                if (n > 0) withChat++;
                chatFiles += n;
            }
            int sessions = SessionCatalog.DebugLogDirs(root).Sum(d => SessionCatalog.SafeEnumerateDirectories(d.LogsDir).Count());
            totalSessions += sessions;
            totalChatFiles += chatFiles;
            o.WriteLine($"  {root.Label,-24} {root.UserDir}");
            o.WriteLine($"  {"",-24} {workspaces} workspaces, {withChat} with chat history ({chatFiles} chats), {sessions} sessions with debug logs");
            int transcripts = TranscriptCatalog.FindAll([root]).Count, oldFormat = TranscriptCatalog.CountOldFormat([root]);
            o.WriteLine($"  {"",-24} {transcripts} chat transcripts with usage (read when a chat's debug log has no calls), {oldFormat} older ones without usage");
            var setting = CopilotInstall.ReadDebugLogSetting(root);
            o.WriteLine($"  {"",-24} debug logging ({CopilotInstall.DebugLogSetting}): {setting switch { true => "on", false => "off", null => "not set (default off)" }}");
        }
        if (!anyRoot && roots.Count > 0) o.WriteLine("  No VS Code data folder found. Use --root <path> for a copied or remote folder.");
        if (roots.Count == 0) o.WriteLine("  not searched (--cli-root given)");

        o.WriteLine();
        o.WriteLine("Copilot harness (agent host / Copilot CLI session-state)");
        int cliSessions = 0;
        if (cliHome is null)
        {
            o.WriteLine("  not searched (--root given)");
        }
        else
        {
            var stateDir = CliSessionCatalog.StateDir(cliHome);
            var sessions = CliSessionCatalog.FindAll(cliHome);
            cliSessions = sessions.Count;
            o.WriteLine(Directory.Exists(stateDir)
                ? $"  {stateDir}   {sessions.Count} sessions, {sessions.Count(s => s.Active)} open"
                : $"  {stateDir}   not found");
        }

        o.WriteLine();
        o.WriteLine("Copilot Chat");
        var versions = CopilotInstall.FindVersions();
        if (versions.Count == 0) o.WriteLine("  no installation found");
        foreach (var (where, version) in versions) o.WriteLine($"  {version,-10} {where}");

        o.WriteLine();
        o.WriteLine("Hooks");
        var repoRoot = HooksCommand.RepoRoot(Directory.GetCurrentDirectory());
        var repoHook = HooksCommand.HookFilePath("repo", repoRoot);
        var userHook = HooksCommand.HookFilePath("user", cliHome ?? CliSessionCatalog.DefaultHome);
        o.WriteLine($"  repository  {(File.Exists(repoHook) ? "installed: " + repoHook : "not installed in " + repoRoot)}");
        o.WriteLine($"  user        {(File.Exists(userHook) ? "installed: " + userHook : "not installed")}");
        int eventFiles = Directory.Exists(ToolPaths.EventsDir) ? Directory.GetFiles(ToolPaths.EventsDir, "*.jsonl").Length : 0;
        o.WriteLine($"  tool data   {ToolPaths.DataDir}{(Directory.Exists(ToolPaths.DataDir) ? $" ({eventFiles} sessions with hook events)" : " (not created yet)")}");
        if (File.Exists(HookCommand.ErrorLog))
            o.WriteLine($"  hook errors {File.ReadLines(HookCommand.ErrorLog).Count()} logged in {HookCommand.ErrorLog} (the hook never fails the agent, so check here)");
        if (!File.Exists(repoHook) && !File.Exists(userHook))
            o.WriteLine("  to record agent runs and phases: copilot-usage hooks install --scope user --skill");

        o.WriteLine();
        if (totalSessions + cliSessions > 0)
            o.WriteLine($"Next: copilot-usage probe latest   ({totalSessions} Local harness sessions with debug logs, {cliSessions} Copilot harness sessions)");
        else if (totalChatFiles > 0)
            o.WriteLine($"No debug logs yet, but {totalChatFiles} chats exist. Set \"{CopilotInstall.DebugLogSetting}\": true in VS Code settings, reload the window, run the workflow once, then: copilot-usage probe latest");
        else
            o.WriteLine("No Copilot Chat sessions found on this machine.");
        return ExitCodes.Ok;
    }
}
