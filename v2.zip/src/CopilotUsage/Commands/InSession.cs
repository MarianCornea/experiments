using System.Globalization;
using CopilotUsage.Analysis;
using CopilotUsage.Cli;
using CopilotUsage.Model;
using CopilotUsage.Pricing;
using CopilotUsage.Storage;
using CopilotUsage.Tracking;

namespace CopilotUsage.Commands;

/// <summary>Shared by status and phase: options, session identification, and short number formats.</summary>
internal sealed class InSession
{
    public required IdentifiedSession Identified { get; init; }
    public required PricingTable Pricing { get; init; }
    public double? Budget { get; init; }
    public bool Json { get; init; }

    public ChatSession Session => Identified.Session;

    public static string IdentifyLog => Path.Combine(ToolPaths.DataDir, "in-session.log");

    public static InSession FromArgs(CliArgs args, string command)
    {
        var result = Create(args);
        // One line per in-session command: how the session was found, so a misidentification can be traced later.
        try
        {
            Directory.CreateDirectory(ToolPaths.DataDir);
            if (File.Exists(IdentifyLog) && new FileInfo(IdentifyLog).Length > 256 * 1024) File.Delete(IdentifyLog);
            var env = Environment.GetEnvironmentVariable("COPILOT_AGENT_SESSION_ID");
            File.AppendAllText(IdentifyLog,
                $"{DateTimeOffset.Now:o} {command} session={result.Session.Id} method=\"{result.Identified.Method}\" " +
                $"env={(string.IsNullOrEmpty(env) ? "absent" : env.Equals(result.Session.Id, StringComparison.OrdinalIgnoreCase) ? "matches" : "other")}\n");
        }
        catch (IOException) { }
        return result;
    }

    static InSession Create(CliArgs args)
    {
        var sessionOption = args.Get("session");
        var budgetText = args.Get("budget");
        bool json = args.Has("json");
        var pricing = PricingTable.Load(args.Get("pricing"));
        var sources = SessionSources.FromArgs(args);
        args.RejectUnknown();
        double? budget = budgetText is null ? null
            : double.TryParse(budgetText, NumberStyles.Float, CultureInfo.InvariantCulture, out var b) && b > 0 ? b
            : throw new CliException("--budget expects a positive number of credits");
        var identified = new CurrentSession { Sessions = sources.FindAll() }.Identify(sessionOption);
        return new InSession { Identified = identified, Pricing = pricing, Budget = budget, Json = json };
    }

    public SessionData Load() => SessionLoader.Load(Session, Pricing);

    public static string Tokens(double n) => n switch
    {
        >= 1e6 => (n / 1e6).ToString("0.0", CultureInfo.InvariantCulture) + "M",
        >= 1e3 => (n / 1e3).ToString("0", CultureInfo.InvariantCulture) + "K",
        _ => n.ToString("0", CultureInfo.InvariantCulture),
    };

    public static string Credits(double c) => c.ToString(c >= 100 ? "N1" : "N2", CultureInfo.InvariantCulture);

    public static string Duration(TimeSpan t) =>
        t.TotalHours >= 1 ? $"{(int)t.TotalHours}h {t.Minutes:00}m" : t.TotalMinutes >= 1 ? $"{(int)t.TotalMinutes}m {t.Seconds:00}s" : $"{t.Seconds}s";

    public static string Percent(double share) => (share * 100).ToString("0", CultureInfo.InvariantCulture) + "%";

    /// <summary>"output 42% · cache write 29% · cache read 17% · fresh input 12%"</summary>
    public static string Causes(IEnumerable<ModelCall> calls)
    {
        var split = calls.Aggregate(CostSplit.Zero, (s, c) => s + c.Cost.Split);
        if (split.Total <= 0) return "no cost yet";
        var parts = new (string, double)[]
        {
            ("output", split.Output), ("cache write", split.CacheWrite), ("cache read", split.CacheRead),
            ("fresh input", split.FreshInput), ("unsplit", split.Unsplit),
        };
        return string.Join(" · ", parts.Where(p => p.Item2 > 0).OrderByDescending(p => p.Item2).Select(p => $"{p.Item1} {Percent(p.Item2 / split.Total)}"));
    }

    public static double BilledShare(IEnumerable<ModelCall> calls)
    {
        var list = calls.ToList();
        double total = list.Sum(c => c.Cost.Credits);
        return total == 0 ? 1 : list.Where(c => c.Cost.Source == CostSource.Billed).Sum(c => c.Cost.Credits) / total;
    }

    /// <summary>Exit 2 and a closing line when the session total reached the budget (FR-12).</summary>
    public (int Exit, string? Line) BudgetCheck(double sessionCredits)
    {
        if (Budget is not double b) return (ExitCodes.Ok, null);
        var line = $"budget {Credits(b)}: {Percent(sessionCredits / b)} used";
        return sessionCredits >= b
            ? (ExitCodes.BudgetExceeded, line + " — BUDGET EXCEEDED: stop and ask the user before continuing")
            : (ExitCodes.Ok, line);
    }
}
