using CopilotUsage.Model;

namespace CopilotUsage.Pricing;

/// <summary>Credits per token by type.</summary>
public sealed record Rates(double FreshInput, double CacheRead, double CacheWrite, double Output)
{
    public CostSplit Estimate(ModelCall c) =>
        new(c.FreshInput * FreshInput, c.CacheRead * CacheRead, c.CacheWrite * CacheWrite, c.Output * Output);
}

/// <summary>
/// Credits per call (FR-06). Billed nanoAIU always wins; estimates fill gaps and explain the split.
/// Rates come from pricing.json, or else from prices Copilot itself billed for that model earlier in the
/// session (its billing details), so models missing from pricing.json can still be split and estimated.
/// </summary>
public sealed class CostEngine(PricingTable pricing)
{
    public const double NanoPerCredit = 1e9;
    public const long DefaultLongContextThreshold = 272_000;

    public void Apply(SessionData session)
    {
        var observed = ObservedRates(session.Calls);
        foreach (var call in session.Calls)
        {
            call.Cost = Price(call, observed);
            if (call.Cost.Source == CostSource.Unpriced && call.Rounds is null) session.Diagnostics.UnpricedModels.Add(call.Model);
        }
    }

    CallCost Price(ModelCall call, IReadOnlyDictionary<string, Rates> observed)
    {
        if (call.Failed) return new CallCost { Source = CostSource.Failed };

        // A chat-transcript record sums several model calls and knows only the last prompt's size: keep the billed
        // credits whole (unsplit) and never estimate, since its tokens would undercount.
        if (call.Rounds is not null)
            return call.NanoAiu is long sum
                ? new CallCost { Credits = sum / NanoPerCredit, Source = CostSource.Billed, Split = new CostSplit(0, 0, 0, 0, sum / NanoPerCredit) }
                : new CallCost { Source = CostSource.Unpriced };

        var (kind, price) = pricing.Match(call.Model);
        // A listed model with a single price tier has no long-context surcharge; an unlisted one is assumed to use 272K.
        long? threshold = price is null ? DefaultLongContextThreshold
            : price.LongContextThreshold ?? (price.Tiers.Count > 1 ? price.Tiers[0].MaxInput : null);
        bool longContext = call.Input > threshold;

        // Rates for this call's own tier, and for the default tier (to price the long-context premium).
        Rates? tierRates = price is not null ? FromTier(TierFor(price, call.Input)) : null;
        Rates? defaultRates = price is not null ? FromTier(price.Tiers[0]) : null;
        string? rateSource = price is not null ? "pricing.json" : null;
        if (price is null && observed.TryGetValue(call.Model, out var seen))
        {
            defaultRates = seen;
            tierRates = longContext ? null : seen; // observed rates come from default-tier calls only
            rateSource = "observed rates";
        }

        if (call.NanoAiu is long nano)
        {
            double credits = nano / NanoPerCredit;
            CostSplit split;
            if (call.BilledSplitNano is { } billedSplit && billedSplit.Total > 0)
            {
                split = billedSplit.Scale(credits / billedSplit.Total);
                rateSource = "billing details";
            }
            else if (tierRates is not null && tierRates.Estimate(call) is { Total: > 0 } estimate)
            {
                split = estimate.Scale(credits / estimate.Total);
            }
            else
            {
                split = new CostSplit(0, 0, 0, 0, credits);
            }
            double? premium = longContext && defaultRates is not null ? Math.Max(0, credits - defaultRates.Estimate(call).Total) : null;
            return new CallCost { Credits = credits, Source = CostSource.Billed, Split = split, LongContext = longContext, LongContextThreshold = threshold, LongContextPremium = premium, RateSource = rateSource };
        }

        if (kind == PriceMatch.Utility)
            return new CallCost { Source = CostSource.Utility, LongContext = longContext, LongContextThreshold = threshold };

        if (tierRates is not null)
        {
            var estimate = tierRates.Estimate(call);
            double? premium = longContext && defaultRates is not null ? Math.Max(0, estimate.Total - defaultRates.Estimate(call).Total) : null;
            return new CallCost { Credits = estimate.Total, Source = CostSource.Estimated, Split = estimate, LongContext = longContext, LongContextThreshold = threshold, LongContextPremium = premium, RateSource = rateSource };
        }

        return new CallCost { Source = CostSource.Unpriced, LongContext = longContext, LongContextThreshold = threshold };
    }

    /// <summary>Credits per token for a call's tier, from pricing.json or the session's observed rates; null when neither knows the model.</summary>
    public Rates? RatesFor(ModelCall call, IReadOnlyDictionary<string, Rates>? observed = null)
    {
        var (_, price) = pricing.Match(call.Model);
        if (price is not null) return FromTier(TierFor(price, call.Input));
        return observed is not null && observed.TryGetValue(call.Model, out var r) ? r : null;
    }

    static PriceTier TierFor(ModelPrice price, long input) =>
        price.Tiers.FirstOrDefault(t => t.MaxInput is null || input <= t.MaxInput) ?? price.Tiers[^1];

    /// <summary>USD per 1M tokens → credits per token.</summary>
    Rates FromTier(PriceTier t)
    {
        double perToken(decimal usdPerMillion) => (double)usdPerMillion / 1e6 / (double)pricing.CreditUsd;
        return new Rates(perToken(t.Input), perToken(t.Cached), perToken(t.CacheWriteOrDefault), perToken(t.Output));
    }

    /// <summary>
    /// Per-type rates Copilot billed for each model, from calls under the long-context threshold that carry billing details.
    /// The median keeps one odd call from skewing them.
    /// </summary>
    public static IReadOnlyDictionary<string, Rates> ObservedRates(IEnumerable<ModelCall> calls)
    {
        var result = new Dictionary<string, Rates>(StringComparer.Ordinal);
        foreach (var group in calls.Where(c => !c.Failed && c.BilledSplitNano is not null && c.Input <= DefaultLongContextThreshold).GroupBy(c => c.Model))
        {
            double? Median(Func<ModelCall, (double Nano, long Tokens)> pick)
            {
                var values = group.Select(pick).Where(v => v.Tokens > 0).Select(v => v.Nano / v.Tokens / NanoPerCredit).Order().ToList();
                return values.Count == 0 ? null : values[values.Count / 2];
            }
            var fresh = Median(c => (c.BilledSplitNano!.FreshInput, c.FreshInput));
            var read = Median(c => (c.BilledSplitNano!.CacheRead, c.CacheRead));
            var write = Median(c => (c.BilledSplitNano!.CacheWrite, c.CacheWrite));
            var output = Median(c => (c.BilledSplitNano!.Output, c.Output));
            if (fresh is null || output is null) continue;
            result[group.Key] = new Rates(fresh.Value, read ?? fresh.Value, write ?? fresh.Value * (double)PriceTier.DefaultCacheWriteRatio, output.Value);
        }
        return result;
    }
}
