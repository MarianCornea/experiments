using System.Text.Json;
using CopilotUsage.Storage;

namespace CopilotUsage.Pricing;

/// <param name="CacheWrite">Null when the price list gives none; then 1.25 × input, the ratio Copilot bills for every
/// model that lists one and for the models seen without one.</param>
public sealed record PriceTier(long? MaxInput, decimal Input, decimal Cached, decimal Output, decimal? CacheWrite = null)
{
    public const decimal DefaultCacheWriteRatio = 1.25m;

    public decimal CacheWriteOrDefault => CacheWrite ?? Input * DefaultCacheWriteRatio;
}

public sealed record ModelPrice(string Id, IReadOnlyList<string> Aliases, long? LongContextThreshold, IReadOnlyList<PriceTier> Tiers);

public enum PriceMatch { Priced, Utility, Unpriced }

/// <summary>Model prices in USD per 1M tokens, loaded from pricing.json so they can be replaced without rebuilding (NFR-08).</summary>
public sealed class PricingTable
{
    public string Source { get; init; } = "";
    public string FilePath { get; init; } = "";
    public decimal CreditUsd { get; init; } = 0.01m;
    public IReadOnlyList<ModelPrice> Models { get; init; } = [];
    public IReadOnlySet<string> UtilityModels { get; init; } = new HashSet<string>();

    public static string DefaultPath => Path.Combine(AppContext.BaseDirectory, "pricing.json");

    public static PricingTable Load(string? path = null)
    {
        path ??= DefaultPath;
        if (!File.Exists(path)) throw new CliException($"pricing file not found: {path}");
        try
        {
            using var doc = JsonDocument.Parse(SafeFile.ReadAllText(path), new JsonDocumentOptions { CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true });
            var root = doc.RootElement;
            var models = new List<ModelPrice>();
            foreach (var m in root.GetProperty("models").EnumerateArray())
            {
                var tiers = m.GetProperty("tiers").EnumerateArray().Select(t => new PriceTier(
                    t.TryGetProperty("maxInput", out var max) && max.ValueKind == JsonValueKind.Number ? max.GetInt64() : null,
                    t.GetProperty("input").GetDecimal(),
                    t.GetProperty("cached").GetDecimal(),
                    t.GetProperty("output").GetDecimal(),
                    t.TryGetProperty("cacheWrite", out var cw) && cw.ValueKind == JsonValueKind.Number ? cw.GetDecimal() : null)).ToList();
                var aliases = m.TryGetProperty("aliases", out var a) ? a.EnumerateArray().Select(x => x.GetString()!).ToList() : [];
                long? threshold = m.TryGetProperty("longContextThreshold", out var th) && th.ValueKind == JsonValueKind.Number ? th.GetInt64() : null;
                models.Add(new ModelPrice(m.GetProperty("id").GetString()!, aliases, threshold, tiers));
            }
            var utility = root.TryGetProperty("utilityModels", out var u)
                ? u.EnumerateArray().Select(x => Normalize(x.GetString()!)).ToHashSet()
                : [];
            return new PricingTable
            {
                Source = root.TryGetProperty("source", out var s) ? s.GetString() ?? "" : "",
                FilePath = path,
                CreditUsd = root.TryGetProperty("creditUsd", out var c) ? c.GetDecimal() : 0.01m,
                Models = models,
                UtilityModels = utility,
            };
        }
        catch (Exception e) when (e is JsonException or KeyNotFoundException or InvalidOperationException or FormatException)
        {
            throw new CliException($"pricing file {path} is not valid: {e.Message}");
        }
    }

    public (PriceMatch Kind, ModelPrice? Price) Match(string model)
    {
        var name = Normalize(model);
        var ids = Models.SelectMany(m => m.Aliases.Prepend(m.Id).Select(id => (Id: Normalize(id), Model: m))).ToList();
        // An exact match first; else a dated or suffixed variant such as gpt-6.1-sol-2026-09-01, longest ID first so
        // claude-opus-4.8-fast is not priced as claude-opus-4.8.
        if (ids.FirstOrDefault(x => x.Id == name).Model is { } exact) return (PriceMatch.Priced, exact);
        if (ids.Where(x => name.StartsWith(x.Id + "-", StringComparison.Ordinal)).OrderByDescending(x => x.Id.Length)
                .Select(x => x.Model).FirstOrDefault() is { } variant)
            return (PriceMatch.Priced, variant);
        if (UtilityModels.Any(u => name == u || name.StartsWith(u + "-", StringComparison.Ordinal)))
            return (PriceMatch.Utility, null);
        return (PriceMatch.Unpriced, null);
    }

    public static string Normalize(string model)
    {
        var m = model.Trim().ToLowerInvariant().Replace(' ', '-');
        foreach (var prefix in new[] { "copilot/", "github/", "openai/", "azure/" })
            if (m.StartsWith(prefix, StringComparison.Ordinal)) m = m[prefix.Length..];
        return m;
    }
}
