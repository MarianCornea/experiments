using CopilotUsage.Storage;

namespace CopilotUsage.Model;

public enum CallKind { Request, Compaction, Title }

/// <summary>How a call's credits were found (NFR-07).</summary>
public enum CostSource
{
    /// <summary>Copilot logged the billed nanoAIU (zero included).</summary>
    Billed,
    /// <summary>No billed value; estimated from pricing.json or prices observed in this session.</summary>
    Estimated,
    /// <summary>Utility model without a billed value: 0 credits, shown separately.</summary>
    Utility,
    /// <summary>Unknown model and no billed value: 0 credits, listed in diagnostics.</summary>
    Unpriced,
    /// <summary>A failed request: counted, not priced.</summary>
    Failed,
}

/// <summary>Credits by cause. Unsplit holds billed credits whose split is unknown.</summary>
public sealed record CostSplit(double FreshInput, double CacheRead, double CacheWrite, double Output, double Unsplit = 0)
{
    public static readonly CostSplit Zero = new(0, 0, 0, 0);
    public double Total => FreshInput + CacheRead + CacheWrite + Output + Unsplit;
    public CostSplit Scale(double f) => new(FreshInput * f, CacheRead * f, CacheWrite * f, Output * f, Unsplit * f);
    public static CostSplit operator +(CostSplit a, CostSplit b) =>
        new(a.FreshInput + b.FreshInput, a.CacheRead + b.CacheRead, a.CacheWrite + b.CacheWrite, a.Output + b.Output, a.Unsplit + b.Unsplit);
}

public sealed class CallCost
{
    public double Credits { get; init; }
    public CostSource Source { get; init; }
    public CostSplit Split { get; init; } = CostSplit.Zero;
    /// <summary>Extra credits paid because the call was above the long-context threshold; null when it cannot be computed.</summary>
    public double? LongContextPremium { get; init; }
    public bool LongContext { get; init; }
    /// <summary>Input tokens above which this call's model costs more; null when its price has no long-context tier.</summary>
    public long? LongContextThreshold { get; init; }
    /// <summary>Where the split and rates came from: "billing details", "pricing.json", "observed rates", or null.</summary>
    public string? RateSource { get; init; }

    public static readonly CallCost None = new() { Source = CostSource.Unpriced };
}

/// <summary>One model invocation with its token counts. Holds no content.</summary>
public sealed class ModelCall
{
    public int Index { get; set; }
    public DateTimeOffset Start { get; set; }
    public DateTimeOffset End { get; set; }
    public string Agent { get; set; } = AgentRun.MainName;
    public string AgentRunId { get; set; } = AgentRun.MainId;
    public string Model { get; set; } = "unknown";
    public long Input { get; set; }
    public long CacheRead { get; set; }
    public long CacheWrite { get; set; }
    public long Output { get; set; }
    public long Reasoning { get; set; }
    public long? NanoAiu { get; set; }
    /// <summary>Billed nanoAIU per token type, from Copilot's own billing details, when logged.</summary>
    public CostSplit? BilledSplitNano { get; set; }
    public CallKind Kind { get; set; }
    public bool Failed { get; set; }
    public string? Skill { get; set; }
    public string? Phase { get; set; }
    /// <summary>Tokens of the tool definitions sent with the call (Copilot harness: usage.toolTokenCount).</summary>
    public long? ToolDefinitionTokens { get; set; }
    /// <summary>
    /// The prompt size this call could reach: the context window minus the output Copilot reserves (128K for most models),
    /// or the harness's own cap (Copilot harness: usage.maxPromptTokens; debug logs: models.json). Null when not logged.
    /// </summary>
    public long? MaxPromptTokens { get; set; }
    /// <summary>How long Copilot keeps this call's prompt cache, counted from the call's start (Copilot harness: usage.cacheTtlSeconds, 1800).</summary>
    public int? CacheTtlSeconds { get; set; }
    /// <summary>The tools_N.json file whose definitions the call carried (Local harness debug log: attrs.toolsFile).</summary>
    public string? ToolsFile { get; set; }
    /// <summary>1-based user turn (prompt to next prompt) the call belongs to; null before the first prompt.</summary>
    public int? Turn { get; set; }
    /// <summary>
    /// Set when this record sums several model calls (chat transcript: one request or one sub-agent run). Its credits
    /// are billed, but Input is only the last call's prompt and the cache use is unknown, so it cannot be split by cause.
    /// </summary>
    public int? Rounds { get; set; }
    public CallCost Cost { get; set; } = CallCost.None;

    /// <summary>Input not served from or written to the cache.</summary>
    public long FreshInput => Math.Max(0, Input - CacheRead - CacheWrite);
}

/// <summary>One tool invocation. Only its name, timing and size are kept.</summary>
public sealed class ToolCall
{
    public DateTimeOffset Start { get; set; }
    public DateTimeOffset End { get; set; }
    public string Agent { get; set; } = AgentRun.MainName;
    public string AgentRunId { get; set; } = AgentRun.MainId;
    public string Name { get; set; } = "";
    public bool Success { get; set; } = true;
    /// <summary>Measured size of the result in tokens, when Copilot logs it.</summary>
    public long? ResultTokens { get; set; }
    /// <summary>Its share of the next model call's context growth (set by ContextGrowth), used when no size was measured.</summary>
    public double? InferredTokens { get; set; }
    /// <summary>Result size × the later calls of the same agent run that still carried it, up to the next reset (set by ContextGrowth).</summary>
    public long CarriedTokens { get; set; }
    /// <summary>The result size used for carried tokens: measured, else inferred.</summary>
    public long? SizeTokens => ResultTokens ?? (InferredTokens is double i ? (long)Math.Round(i) : null);
}

/// <summary>One invocation of an agent: the main agent, or one sub-agent run.</summary>
public sealed class AgentRun
{
    public const string MainId = "main";
    public const string MainName = "main";

    public required string Id { get; init; }
    public required string Name { get; set; }
    public DateTimeOffset? Start { get; set; }
    public DateTimeOffset? End { get; set; }
    public string? Model { get; set; }
    public bool IsMain => Id == MainId;
}

public sealed class SkillUse
{
    public DateTimeOffset At { get; init; }
    public required string Name { get; init; }
}

public sealed class ParseDiagnostics
{
    public List<(string File, int Lines, int BadLines)> Files { get; } = [];
    public SortedDictionary<string, int> EventCounts { get; } = new(StringComparer.Ordinal);
    public SortedSet<string> UnknownEventTypes { get; } = new(StringComparer.Ordinal);
    public SortedSet<string> UnpricedModels { get; } = new(StringComparer.Ordinal);
    public int BadLines => Files.Sum(f => f.BadLines);
    public int FailedRequests { get; set; }
    /// <summary>Calls inside more than one phase (parallel or nested phases); each is counted in the latest-started one.</summary>
    public int OverlappingPhaseCalls { get; set; }
}

/// <summary>Everything the reports need from one session: numbers and names only.</summary>
public sealed class SessionData
{
    public required ChatSession Session { get; init; }
    public string? Title { get; set; }
    public string? CopilotVersion { get; set; }
    public List<ModelCall> Calls { get; } = [];
    public List<ToolCall> Tools { get; } = [];
    public Dictionary<string, AgentRun> Runs { get; } = new(StringComparer.Ordinal);
    public List<SkillUse> Skills { get; } = [];
    /// <summary>When each user prompt to the main agent arrived; a turn runs until the next one.</summary>
    public List<DateTimeOffset> TurnStarts { get; } = [];
    /// <summary>Phases from checkpoints (phase start / end), set by the loader.</summary>
    public List<Tracking.PhaseSpan> Phases { get; } = [];
    public ParseDiagnostics Diagnostics { get; } = new();
    /// <summary>Tool definitions per tools_N.json file (Local harness): name and size of each tool. Empty when not logged.</summary>
    public Dictionary<string, IReadOnlyList<ToolDefinition>> ToolDefinitions { get; } = new(StringComparer.OrdinalIgnoreCase);
    /// <summary>Budget stops the hook gave in this session (budgetStop hook events), set by the loader.</summary>
    public List<Tracking.HookEvent> BudgetStops { get; } = [];
    /// <summary>Prompt artifact files (system_prompt_*.json, tools_*.json) and their sizes: the fixed overhead Copilot sends.</summary>
    public List<(string File, long Bytes)> PromptArtifacts { get; } = [];
    /// <summary>
    /// True when the data has one record per request instead of one per model call (chat transcript): no per-call
    /// tokens, so context-per-call, context growth and the cause split are not available.
    /// </summary>
    public bool PerRequest { get; set; }
    /// <summary>Copilot's own running session total from its last usage checkpoint (Copilot harness only).</summary>
    public long? CheckpointNanoAiu { get; set; }
    public DateTimeOffset? FirstEvent { get; set; }
    public DateTimeOffset? LastEvent { get; set; }

    public IEnumerable<ModelCall> SuccessfulCalls => Calls.Where(c => !c.Failed);

    /// <summary>Model calls made: one per record, or for per-request data the calls each record sums (a sub-agent run counts 0: unknown).</summary>
    public int ModelCallCount => PerRequest ? SuccessfulCalls.Sum(c => c.Rounds ?? 1) : SuccessfulCalls.Count();

    /// <summary>The call count with "+" when some calls are not counted (sub-agent runs in a chat transcript).</summary>
    public string ModelCallCountText => ModelCallCount.ToString(System.Globalization.CultureInfo.InvariantCulture) + (PerRequest && SuccessfulCalls.Any(c => c.Rounds == 0) ? "+" : "");
    public double TotalCredits => Calls.Sum(c => c.Cost.Credits);
    public double BilledCredits => Calls.Where(c => c.Cost.Source == CostSource.Billed).Sum(c => c.Cost.Credits);
    public double EstimatedCredits => Calls.Where(c => c.Cost.Source == CostSource.Estimated).Sum(c => c.Cost.Credits);

    internal void SeeTimestamp(DateTimeOffset at)
    {
        if (FirstEvent is null || at < FirstEvent) FirstEvent = at;
        if (LastEvent is null || at > LastEvent) LastEvent = at;
    }

    internal AgentRun MainRun()
    {
        if (!Runs.TryGetValue(AgentRun.MainId, out var main))
            Runs[AgentRun.MainId] = main = new AgentRun { Id = AgentRun.MainId, Name = AgentRun.MainName };
        return main;
    }

    /// <summary>Sorts calls by start time, numbers them, and assigns the active skill (the last slash command before each call).</summary>
    internal void Finish()
    {
        Calls.Sort((a, b) => a.Start.CompareTo(b.Start));
        Tools.Sort((a, b) => a.Start.CompareTo(b.Start));
        Skills.Sort((a, b) => a.At.CompareTo(b.At));
        TurnStarts.Sort();
        int s = -1, turn = 0;
        for (int i = 0; i < Calls.Count; i++)
        {
            var call = Calls[i];
            call.Index = i + 1;
            while (s + 1 < Skills.Count && Skills[s + 1].At <= call.Start) s++;
            call.Skill = s >= 0 ? Skills[s].Name : null;
            while (turn < TurnStarts.Count && TurnStarts[turn] <= call.Start) turn++;
            call.Turn = turn > 0 ? turn : null;
        }
        var main = MainRun();
        main.Start ??= FirstEvent;
        main.End ??= LastEvent;
        // Names are resolved last: a run's start event may be logged after its first call.
        foreach (var c in Calls) c.Agent = Runs.TryGetValue(c.AgentRunId, out var r) ? r.Name : c.Agent;
        foreach (var t in Tools) t.Agent = Runs.TryGetValue(t.AgentRunId, out var r) ? r.Name : t.Agent;
        foreach (var run in Runs.Values.Where(r => !r.IsMain))
        {
            var mine = Calls.Where(c => c.AgentRunId == run.Id).ToList();
            if (mine.Count == 0) continue;
            run.Start ??= mine.Min(c => c.Start);
            run.End ??= mine.Max(c => c.End);
            run.Model ??= mine[0].Model;
        }
        Diagnostics.FailedRequests = Calls.Count(c => c.Failed);
    }
}

/// <summary>One tool definition sent to the model: its name and size (about 4 bytes per token). Holds no description or schema text.</summary>
public sealed record ToolDefinition(string Name, long Tokens);
