using System.Globalization;
using System.Text;
using System.Text.Json;

namespace CopilotUsage.Report;

/// <summary>Small helpers for writing SVG and HTML by hand: invariant numbers, escaping, nice axis ticks, tooltip payloads.</summary>
internal static class Svg
{
    public static string F(double v) => v.ToString("0.##", CultureInfo.InvariantCulture);

    public static string Esc(string? s) => System.Net.WebUtility.HtmlEncode(s ?? "");

    /// <summary>Tooltip content as a data attribute: a title and value/label rows, read by the page script with textContent.</summary>
    public static string Tip(string title, params (string Value, string Label)[] rows)
    {
        var json = JsonSerializer.Serialize(new { t = title, r = rows.Select(r => new[] { r.Value, r.Label }) });
        return $" data-tip=\"{Esc(json)}\"";
    }

    /// <summary>Round axis maximum and step: 1, 2 or 5 × 10^n, about four steps.</summary>
    public static (double Max, double Step) NiceScale(double max, int steps = 4)
    {
        if (max <= 0) return (1, 0.25);
        double raw = max / steps;
        double mag = Math.Pow(10, Math.Floor(Math.Log10(raw)));
        double norm = raw / mag;
        double step = (norm <= 1 ? 1 : norm <= 2 ? 2 : norm <= 5 ? 5 : 10) * mag;
        return (Math.Ceiling(max / step) * step, step);
    }

    /// <summary>Axis tick text: in full under 10,000, compact above (10K, 1.2M), one style per axis.</summary>
    public static string Tick(double v, double axisMax, bool credits = false)
    {
        if (credits) return v.ToString(axisMax >= 10 ? "0" : axisMax >= 1 ? "0.0" : "0.00", CultureInfo.InvariantCulture);
        if (v == 0) return "0";
        if (axisMax < 10_000) return v.ToString("#,0", CultureInfo.InvariantCulture);
        return v >= 1e6 ? (v / 1e6).ToString("0.#", CultureInfo.InvariantCulture) + "M" : (v / 1e3).ToString("0", CultureInfo.InvariantCulture) + "K";
    }

    /// <summary>A column segment with a 4px rounded top (the data end) and a square bottom.</summary>
    public static string RoundedTopRect(double x, double y, double w, double h, string cls, string extra = "")
    {
        double r = Math.Min(4, Math.Min(w / 2, h));
        if (r < 1) return $"<rect class=\"{cls}\" x=\"{F(x)}\" y=\"{F(y)}\" width=\"{F(w)}\" height=\"{F(h)}\"{extra}/>";
        var d = new StringBuilder();
        d.Append($"M{F(x)},{F(y + h)}V{F(y + r)}Q{F(x)},{F(y)} {F(x + r)},{F(y)}H{F(x + w - r)}Q{F(x + w)},{F(y)} {F(x + w)},{F(y + r)}V{F(y + h)}Z");
        return $"<path class=\"{cls}\" d=\"{d}\"{extra}/>";
    }
}
