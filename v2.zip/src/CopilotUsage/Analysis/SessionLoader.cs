using CopilotUsage.Logs;
using CopilotUsage.Model;
using CopilotUsage.Pricing;
using CopilotUsage.Storage;
using CopilotUsage.Tracking;

namespace CopilotUsage.Analysis;

/// <summary>Where the tool's own data lives; tests point these at temporary folders.</summary>
public sealed record ToolData(string CheckpointsDir, string EventsDir)
{
    public static ToolData Default => new(ToolPaths.CheckpointsDir, ToolPaths.EventsDir);
}

/// <summary>Parses a session from either source, prices every call, and applies phases and hook data.</summary>
public static class SessionLoader
{
    public static SessionData Load(ChatSession session, PricingTable pricing, SessionTitles? titles = null, ToolData? tool = null)
    {
        tool ??= ToolData.Default;
        var data = session switch
        {
            DebugLogSession d => DebugLogParser.Parse(d),
            CliSession c => CliSessionParser.Parse(c),
            TranscriptSession t => TranscriptParser.Parse(t),
            _ => throw new CliException("unsupported session type"),
        };
        if (data.Title is null && session is DebugLogSession debug)
            data.Title = (titles ?? new SessionTitles()).Lookup(debug);
        if (data.Title is null && session is TranscriptSession transcript)
            data.Title = (titles ?? new SessionTitles()).Lookup(transcript);
        new CostEngine(pricing).Apply(data);
        ApplyPhases(data, Checkpoints.Spans(Checkpoints.Load(session.Id, tool.CheckpointsDir)));
        var events = HookEvents.Load(session.Id, tool.EventsDir);
        ApplyToolSizes(data, events);
        data.BudgetStops.AddRange(events.Where(e => e.Event == "budgetStop").OrderBy(e => e.Ts));
        return data;
    }

    /// <summary>A call belongs to the phase whose span contains its start; with nested or parallel phases, the latest-started one.</summary>
    public static void ApplyPhases(SessionData data, IReadOnlyList<PhaseSpan> spans)
    {
        data.Phases.Clear();
        data.Phases.AddRange(spans);
        int overlapping = 0;
        foreach (var call in data.Calls)
        {
            var matching = spans.Where(s => s.Contains(call.Start)).ToList();
            call.Phase = matching.Count == 0 ? null : matching.MaxBy(s => s.Start)!.Name;
            if (matching.Count > 1) overlapping++;
        }
        data.Diagnostics.OverlappingPhaseCalls = overlapping;
    }

    /// <summary>
    /// FR-19: where Copilot logged no result size (Local harness), use the postToolUse hook's response length,
    /// matched by tool name and time, at about 4 characters per token.
    /// </summary>
    static void ApplyToolSizes(SessionData data, IReadOnlyList<HookEvent> events)
    {
        var posts = events.Where(e => e.ResponseLength is not null && e.Tool is not null &&
                                      e.Event.Equals("postToolUse", StringComparison.OrdinalIgnoreCase)).ToList();
        if (posts.Count == 0) return;
        var used = new HashSet<HookEvent>();
        foreach (var tool in data.Tools.Where(t => t.ResultTokens is null))
        {
            var match = posts
                .Where(p => !used.Contains(p) && p.Tool!.Equals(tool.Name, StringComparison.OrdinalIgnoreCase) &&
                            Math.Abs((p.Time - tool.End).TotalSeconds) <= 10)
                .MinBy(p => Math.Abs((p.Time - tool.End).TotalMilliseconds));
            if (match is null) continue;
            used.Add(match);
            tool.ResultTokens = (match.ResponseLength!.Value + 3) / 4;
        }
    }
}
