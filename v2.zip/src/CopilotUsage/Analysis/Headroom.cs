using CopilotUsage.Model;

namespace CopilotUsage.Analysis;

/// <summary>One agent run's context against the prompt size its model allows.</summary>
public sealed record HeadroomRow(string Run, string Agent, string Model, long? Usable, long Peak, int Drops, double Credits)
{
    /// <summary>Peak input as a share of the usable prompt; null when the limit is not logged.</summary>
    public double? Share => Usable is long u && u > 0 ? (double)Peak / u : null;
}

/// <summary>
/// Context headroom per agent run. Copilot keeps room for the model's longest answer inside the context window
/// (128K tokens for most models), so the usable prompt is the window minus that reservation, or the harness's own
/// cap where it sets one (the Copilot harness caps gpt-6-luna at 272K). Near that limit Copilot compacts.
/// </summary>
public static class Headroom
{
    public static IReadOnlyList<HeadroomRow> By(SessionData s) =>
        s.SuccessfulCalls.Where(c => c.Kind != CallKind.Title && c.Input > 0)
            .GroupBy(c => c.AgentRunId)
            .Select(g =>
            {
                var calls = g.OrderBy(c => c.Start).ToList();
                var peak = calls.MaxBy(c => c.Input)!;
                int drops = 0;
                for (int i = 1; i < calls.Count; i++) if (calls[i].Input < calls[i - 1].Input) drops++;
                var label = s.Runs.TryGetValue(g.Key, out var run) ? Breakdown.RunLabel(s, run) : g.Key;
                return new HeadroomRow(label, peak.Agent, peak.Model, peak.MaxPromptTokens ?? calls.Max(c => c.MaxPromptTokens), peak.Input, drops,
                    calls.Sum(c => c.Cost.Credits));
            })
            .OrderByDescending(r => r.Share ?? -1).ThenByDescending(r => r.Peak)
            .ToList();
}
