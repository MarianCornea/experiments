using CopilotUsage.Model;

namespace CopilotUsage.Analysis;

/// <summary>One headline measure for both runs.</summary>
public sealed record MetricRow(string Name, double A, double B, string Format)
{
    public double Change => B - A;
    public double? ChangeShare => A == 0 ? null : (B - A) / A;
}

/// <summary>One step of a credit bridge (waterfall). Steps add up exactly to B − A.</summary>
public sealed record BridgeStep(string Name, double A, double B, string? Note = null)
{
    public double Delta => B - A;
}

/// <summary>One matched group (agent, phase or skill) or tool, side by side.</summary>
public sealed record GroupRow(string Name, int CallsA, int CallsB, int RunsA, int RunsB, double CreditsA, double CreditsB, double CachedA, double CachedB)
{
    public double Delta => CreditsB - CreditsA;
    public bool OnlyInA => CallsB == 0 && CallsA > 0;
    public bool OnlyInB => CallsA == 0 && CallsB > 0;
}

public sealed record ToolChangeRow(string Tool, int CallsA, int CallsB, double GrowthA, double GrowthB)
{
    public double GrowthDelta => GrowthB - GrowthA;
}

/// <summary>One MCP server in both runs: tools used and loaded, definition and result tokens carried (FR-11, FR-21).</summary>
public sealed record McpChangeRow(string Server, int UsedA, int? LoadedA, int UsedB, int? LoadedB, long? DefinitionsA, long? DefinitionsB,
    long ResultsCarriedA, long ResultsCarriedB, int CallsA, int CallsB, bool InA, bool InB);

public sealed record OverheadRow(string Agent, long? FirstCallA, long? FirstCallB, long? ToolDefsA, long? ToolDefsB);

/// <summary>Context curves of one agent: one line per run of it, input tokens per call, x = progress through that run (0–1).</summary>
public sealed record Curve(string Agent, IReadOnlyList<IReadOnlyList<(double X, long Input)>> A, IReadOnlyList<IReadOnlyList<(double X, long Input)>> B);

/// <summary>
/// Compares two runs (FR-11) with the same parser and cost engine as the single-run report. Runs are matched by name,
/// never by call number: phases by phase name, agents by agent name (repeated runs compared as a total), then skills,
/// models, tools and call kinds.
/// </summary>
public sealed class Comparison
{
    public required SessionData A { get; init; }
    public required SessionData B { get; init; }
    public required string LabelA { get; init; }
    public required string LabelB { get; init; }
    public required Dimension By { get; init; }
    public required IReadOnlyList<MetricRow> Headline { get; init; }
    public required IReadOnlyList<GroupRow> Groups { get; init; }
    public required IReadOnlyList<BridgeStep> BridgeByGroup { get; init; }
    public required IReadOnlyList<BridgeStep> BridgeByCause { get; init; }
    public required IReadOnlyList<GroupRow> Models { get; init; }
    public required IReadOnlyList<GroupRow> Kinds { get; init; }
    public required IReadOnlyList<ToolChangeRow> Tools { get; init; }
    public IReadOnlyList<McpChangeRow> Mcp { get; init; } = [];
    public required IReadOnlyList<OverheadRow> Overhead { get; init; }
    public required IReadOnlyList<Curve> Curves { get; init; }
    public required IReadOnlyList<string> Warnings { get; init; }
    public IReadOnlyList<Finding> ChangeFindings { get; private set; } = [];

    public double TotalA => A.TotalCredits;
    public double TotalB => B.TotalCredits;
    public double Delta => TotalB - TotalA;

    public const int MaxBridgeSteps = 8;

    public static Comparison Build(SessionData a, SessionData b, Dimension by, string labelA = "A", string labelB = "B",
        Pricing.PricingTable? pricing = null, McpMap? mcpMap = null)
    {
        if (by is not (Dimension.Agent or Dimension.Phase or Dimension.Skill or Dimension.Model))
            throw new CliException("--by must be phase, agent, skill or model");
        var growthA = ContextGrowth.Analyze(a);
        var growthB = ContextGrowth.Analyze(b);
        var groups = Match(a, b, by);
        var cmp = new Comparison
        {
            A = a, B = b, LabelA = labelA, LabelB = labelB, By = by,
            Headline = HeadlineRows(a, b),
            Groups = groups,
            BridgeByGroup = GroupBridge(groups),
            BridgeByCause = CauseBridge(a, b),
            Models = Match(a, b, Dimension.Model),
            Kinds = Match(a, b, Dimension.Kind),
            Tools = ToolRows(growthA, growthB),
            Mcp = McpRows(McpStats.Analyze(a, pricing ?? Pricing.PricingTable.Load(), mcpMap), McpStats.Analyze(b, pricing ?? Pricing.PricingTable.Load(), mcpMap)),
            Overhead = OverheadRows(a, b, growthA, growthB),
            Curves = BuildCurves(a, b),
            Warnings = Warn(a, b),
        };
        cmp.ChangeFindings = CompareFindings(cmp);
        return cmp;
    }

    // ---------- headline ----------

    static IReadOnlyList<MetricRow> HeadlineRows(SessionData a, SessionData b)
    {
        static (double Credits, int Calls, long Input, double Cached, long Write, long Output, long Peak, int Long, int Compactions, double Minutes, int SubRuns) M(SessionData s)
        {
            var c = s.SuccessfulCalls.ToList();
            long input = c.Sum(x => x.Input);
            return (s.TotalCredits, s.ModelCallCount, input, input == 0 ? 0 : (double)c.Sum(x => x.CacheRead) / input, c.Sum(x => x.CacheWrite),
                c.Sum(x => x.Output), c.Count == 0 ? 0 : c.Max(x => x.Input), c.Count(x => x.Cost.LongContext), c.Count(x => x.Kind == CallKind.Compaction),
                ((s.LastEvent ?? default) - (s.FirstEvent ?? default)).TotalMinutes,
                s.Runs.Values.Count(r => !r.IsMain && c.Any(x => x.AgentRunId == r.Id)));
        }
        var x = M(a);
        var y = M(b);
        return
        [
            new("Credits", x.Credits, y.Credits, "credits"),
            new("Model calls", x.Calls, y.Calls, "count"),
            new("Input tokens", x.Input, y.Input, "tokens"),
            new("Served from cache", x.Cached, y.Cached, "share"),
            new("Written to cache", x.Write, y.Write, "tokens"),
            new("Output tokens", x.Output, y.Output, "tokens"),
            new("Peak context", x.Peak, y.Peak, "tokens"),
            new("Long-context calls", x.Long, y.Long, "count"),
            new("Compactions", x.Compactions, y.Compactions, "count"),
            new("Sub-agent runs", x.SubRuns, y.SubRuns, "count"),
            new("Duration", x.Minutes, y.Minutes, "minutes"),
        ];
    }

    // ---------- matching and bridges ----------

    /// <summary>Groups matched by name across both runs; a name in only one run is kept with zeros on the other side.</summary>
    public static IReadOnlyList<GroupRow> Match(SessionData a, SessionData b, Dimension by)
    {
        var ra = Breakdown.By(a, by).ToDictionary(r => r.Key);
        var rb = Breakdown.By(b, by).ToDictionary(r => r.Key);
        int Runs(SessionData s, string name) => by == Dimension.Agent ? s.SuccessfulCalls.Where(c => c.Agent == name).Select(c => c.AgentRunId).Distinct().Count() : 0;
        return ra.Keys.Union(rb.Keys)
            .Select(k =>
            {
                var x = ra.GetValueOrDefault(k);
                var y = rb.GetValueOrDefault(k);
                return new GroupRow(k, x?.Calls ?? 0, y?.Calls ?? 0, Runs(a, k), Runs(b, k), x?.Credits ?? 0, y?.Credits ?? 0, x?.CachedShare ?? 0, y?.CachedShare ?? 0);
            })
            .OrderByDescending(r => Math.Abs(r.Delta)).ThenBy(r => r.Name, StringComparer.Ordinal)
            .ToList();
    }

    /// <summary>The largest changes as their own steps, the rest folded into "other", so the bridge stays readable and still adds up.</summary>
    static IReadOnlyList<BridgeStep> GroupBridge(IReadOnlyList<GroupRow> groups)
    {
        var steps = groups.Take(MaxBridgeSteps - 1)
            .Select(g => new BridgeStep(g.Name, g.CreditsA, g.CreditsB, g.OnlyInA ? $"only in A" : g.OnlyInB ? "only in B" : g.RunsA != g.RunsB ? $"{g.RunsA} → {g.RunsB} runs" : null))
            .ToList();
        var rest = groups.Skip(MaxBridgeSteps - 1).ToList();
        if (rest.Count > 0) steps.Add(new BridgeStep($"{rest.Count} others", rest.Sum(r => r.CreditsA), rest.Sum(r => r.CreditsB)));
        return steps;
    }

    static IReadOnlyList<BridgeStep> CauseBridge(SessionData a, SessionData b)
    {
        var x = a.SuccessfulCalls.Aggregate(CostSplit.Zero, (s, c) => s + c.Cost.Split);
        var y = b.SuccessfulCalls.Aggregate(CostSplit.Zero, (s, c) => s + c.Cost.Split);
        static double Premium(SessionData s) => s.SuccessfulCalls.Sum(c => c.Cost.LongContextPremium ?? 0);
        var steps = new List<BridgeStep>
        {
            new("Fresh input", x.FreshInput, y.FreshInput),
            new("Cache read", x.CacheRead, y.CacheRead),
            new("Cache write", x.CacheWrite, y.CacheWrite),
            new("Output", x.Output, y.Output),
        };
        if (x.Unsplit > 0 || y.Unsplit > 0) steps.Add(new("Not split", x.Unsplit, y.Unsplit));
        double pa = Premium(a), pb = Premium(b);
        // The long-context premium is part of the steps above, so it is a note, not a step: the bridge must add up.
        if (pa > 0 || pb > 0) steps[0] = steps[0] with { Note = $"long-context premium inside these steps: {Findings.Cr(pa)} → {Findings.Cr(pb)}" };
        return steps;
    }

    static IReadOnlyList<McpChangeRow> McpRows(McpResult a, McpResult b)
    {
        var sa = a.Servers.ToDictionary(s => s.Server, StringComparer.OrdinalIgnoreCase);
        var sb = b.Servers.ToDictionary(s => s.Server, StringComparer.OrdinalIgnoreCase);
        return sa.Keys.Union(sb.Keys, StringComparer.OrdinalIgnoreCase)
            .Select(k =>
            {
                var x = sa.GetValueOrDefault(k);
                var y = sb.GetValueOrDefault(k);
                return new McpChangeRow(k, x?.ToolsUsed ?? 0, x?.ToolsLoaded, y?.ToolsUsed ?? 0, y?.ToolsLoaded,
                    x?.DefinitionTokensCarried, y?.DefinitionTokensCarried, x?.ResultCarried ?? 0, y?.ResultCarried ?? 0,
                    x?.Calls ?? 0, y?.Calls ?? 0, x is not null, y is not null);
            })
            .OrderByDescending(r => Math.Abs((r.DefinitionsB ?? 0) + r.ResultsCarriedB - (r.DefinitionsA ?? 0) - r.ResultsCarriedA))
            .ThenBy(r => r.Server, StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    static IReadOnlyList<ToolChangeRow> ToolRows(ContextGrowthResult a, ContextGrowthResult b)
    {
        var ta = a.Tools.ToDictionary(t => t.Tool);
        var tb = b.Tools.ToDictionary(t => t.Tool);
        return ta.Keys.Union(tb.Keys)
            .Select(k => new ToolChangeRow(k, ta.GetValueOrDefault(k)?.Calls ?? 0, tb.GetValueOrDefault(k)?.Calls ?? 0,
                ta.GetValueOrDefault(k)?.InferredGrowth ?? 0, tb.GetValueOrDefault(k)?.InferredGrowth ?? 0))
            .OrderByDescending(r => Math.Abs(r.GrowthDelta)).ThenByDescending(r => Math.Abs(r.CallsB - r.CallsA)).ThenBy(r => r.Tool, StringComparer.Ordinal)
            .ToList();
    }

    /// <summary>First-call size per agent (the first run of each agent name) and tool-definition tokens, A vs B.</summary>
    static IReadOnlyList<OverheadRow> OverheadRows(SessionData a, SessionData b, ContextGrowthResult ga, ContextGrowthResult gb)
    {
        static Dictionary<string, (long First, long? Tools)> Firsts(SessionData s) =>
            s.SuccessfulCalls.Where(c => c.Kind != CallKind.Title).GroupBy(c => c.Agent)
                .ToDictionary(g => g.Key, g => { var first = g.OrderBy(c => c.Start).First(); return (first.Input, first.ToolDefinitionTokens); });
        var fa = Firsts(a);
        var fb = Firsts(b);
        var rows = fa.Keys.Union(fb.Keys)
            .Select(k => new OverheadRow(k, fa.TryGetValue(k, out var x) ? x.First : null, fb.TryGetValue(k, out var y) ? y.First : null,
                fa.TryGetValue(k, out var x2) ? x2.Tools : null, fb.TryGetValue(k, out var y2) ? y2.Tools : null))
            .OrderBy(r => r.Agent == AgentRun.MainName ? 0 : 1).ThenBy(r => r.Agent, StringComparer.Ordinal)
            .ToList();
        // Prompt artifacts (Local harness) by name pattern: total size per pattern.
        long Bytes(SessionData s, string prefix) => s.PromptArtifacts.Where(p => p.File.StartsWith(prefix, StringComparison.Ordinal)).Sum(p => p.Bytes);
        if (a.PromptArtifacts.Count + b.PromptArtifacts.Count > 0)
        {
            rows.Add(new OverheadRow("system prompt files (bytes)", Bytes(a, "system_prompt_"), Bytes(b, "system_prompt_"), null, null));
            rows.Add(new OverheadRow("tool definition files (bytes)", Bytes(a, "tools_"), Bytes(b, "tools_"), null, null));
        }
        return rows;
    }

    /// <summary>One curve per agent name present in both runs (most expensive first, at most six).</summary>
    static IReadOnlyList<Curve> BuildCurves(SessionData a, SessionData b)
    {
        // Parallel runs of one agent interleave in time, so each run is its own line.
        static IReadOnlyList<IReadOnlyList<(double, long)>> Points(SessionData s, string agent) =>
            s.SuccessfulCalls.Where(c => c.Agent == agent && c.Kind != CallKind.Title).GroupBy(c => c.AgentRunId)
                .Select(run =>
                {
                    var calls = run.OrderBy(c => c.Start).ToList();
                    return (IReadOnlyList<(double, long)>)calls.Select((c, i) => (calls.Count == 1 ? 0.0 : (double)i / (calls.Count - 1), c.Input)).ToList();
                })
                .ToList();
        var names = a.SuccessfulCalls.Select(c => c.Agent).Union(b.SuccessfulCalls.Select(c => c.Agent))
            .OrderByDescending(n => a.SuccessfulCalls.Where(c => c.Agent == n).Sum(c => c.Cost.Credits) + b.SuccessfulCalls.Where(c => c.Agent == n).Sum(c => c.Cost.Credits))
            .Take(6);
        return names.Select(n => new Curve(n, Points(a, n), Points(b, n))).ToList();
    }

    // ---------- comparability ----------

    static IReadOnlyList<string> Warn(SessionData a, SessionData b)
    {
        var w = new List<string>();
        var ma = a.SuccessfulCalls.Select(c => c.Model).ToHashSet();
        var mb = b.SuccessfulCalls.Select(c => c.Model).ToHashSet();
        if (!ma.SetEquals(mb))
            w.Add($"Different models: A used {string.Join(", ", ma.Order())}; B used {string.Join(", ", mb.Order())}. Prices per token differ between models.");
        double ea = a.TotalCredits == 0 ? 0 : a.EstimatedCredits / a.TotalCredits, eb = b.TotalCredits == 0 ? 0 : b.EstimatedCredits / b.TotalCredits;
        if (Math.Abs(ea - eb) > 0.05)
            w.Add($"Different billed/estimated mix: {Findings.Pct(ea)} of A and {Findings.Pct(eb)} of B are estimated.");
        var sa = a.SuccessfulCalls.Where(c => c.AgentRunId != AgentRun.MainId).Select(c => c.Agent).ToHashSet();
        var sb = b.SuccessfulCalls.Where(c => c.AgentRunId != AgentRun.MainId).Select(c => c.Agent).ToHashSet();
        var onlyA = sa.Except(sb).Order().ToList();
        var onlyB = sb.Except(sa).Order().ToList();
        if (onlyA.Count + onlyB.Count > 0)
            w.Add("Sub-agents present in only one run: " + string.Join("; ", new[] { onlyA.Count > 0 ? "A: " + string.Join(", ", onlyA) : null, onlyB.Count > 0 ? "B: " + string.Join(", ", onlyB) : null }.Where(s => s is not null)) + ".");
        foreach (var (s, label) in new[] { (a, "A"), (b, "B") })
            if (DateTime.UtcNow - s.Session.LastWriteUtc < TimeSpan.FromMinutes(10))
                w.Add($"Run {label} changed in the last 10 minutes and may still be running: its totals can grow.");
        if (a.Session.Source != b.Session.Source)
            w.Add($"The runs come from different harnesses ({a.Session.SourceLabel} vs {b.Session.SourceLabel}): their logs measure differently.");
        else if (a.CopilotVersion is not null && b.CopilotVersion is not null && a.CopilotVersion != b.CopilotVersion)
            w.Add($"Different Copilot versions ({a.CopilotVersion} vs {b.CopilotVersion}): the log format or the agent may have changed.");
        foreach (var (s, label) in new[] { (a, "A"), (b, "B") })
            if (s.PerRequest)
                w.Add($"Run {label} comes from a chat transcript: credits are billed, but tokens, cache use and context per call are not recorded, so those rows and the cause bridge cannot be compared.");
        if (a.Session.Id == b.Session.Id) w.Add("A and B are the same session.");
        return w;
    }

    // ---------- findings ----------

    static IReadOnlyList<Finding> CompareFindings(Comparison c)
    {
        var list = new List<Finding>();
        double d = c.Delta;
        string Who(string name) => c.By switch
        {
            Dimension.Agent => name == AgentRun.MainName ? "the main agent" : $"sub-agent {name}",
            Dimension.Phase => $"phase {name}",
            Dimension.Skill => $"skill {name}",
            _ => name,
        };
        if (Math.Abs(d) < 1e-9)
        {
            list.Add(new Finding(FindingTopic.Driver, $"{c.LabelB} cost the same as {c.LabelA} ({Findings.Cr(c.TotalA)} credits).", 0));
            return list;
        }
        string verb = d < 0 ? "saved" : "cost";
        string amount = d < 0 ? Findings.Cr(-d) : Findings.Cr(d) + " more";
        string pct = c.TotalA > 0 ? $" ({(d > 0 ? "+" : "−")}{Findings.Pct(Math.Abs(d) / c.TotalA)})" : "";

        var top = c.Groups.FirstOrDefault(g => Math.Abs(g.Delta) > 1e-9);
        if (top is not null)
        {
            string cache = c.By is Dimension.Agent or Dimension.Phase && !top.OnlyInA && !top.OnlyInB && Math.Abs(top.CachedB - top.CachedA) >= 0.1
                ? $", its cached share going from {Findings.Pct(top.CachedA)} to {Findings.Pct(top.CachedB)}" : "";
            string presence = top.OnlyInA ? $", which ran only in {c.LabelA}" : top.OnlyInB ? $", which ran only in {c.LabelB}" : "";
            list.Add(new Finding(FindingTopic.Driver,
                $"{c.LabelB} {verb} {amount}{pct}. The largest step was {Who(top.Name)}: {Findings.Cr(top.CreditsA)} → {Findings.Cr(top.CreditsB)}{cache}{presence}.",
                Math.Abs(d)));
        }
        else
        {
            list.Add(new Finding(FindingTopic.Driver, $"{c.LabelB} {verb} {amount}{pct}.", Math.Abs(d)));
        }

        var cause = c.BridgeByCause.OrderByDescending(s => Math.Abs(s.Delta)).First();
        list.Add(new Finding(FindingTopic.Cause,
            $"By cause, {cause.Name.ToLowerInvariant()} changed the most: {Findings.Cr(cause.A)} → {Findings.Cr(cause.B)} ({(cause.Delta >= 0 ? "+" : "−")}{Findings.Cr(Math.Abs(cause.Delta))}).",
            Math.Abs(cause.Delta)));

        var cached = c.Headline.Single(h => h.Name == "Served from cache");
        if (Math.Abs(cached.Change) >= 0.1)
            list.Add(new Finding(FindingTopic.Cache, $"The cached share of input went from {Findings.Pct(cached.A)} to {Findings.Pct(cached.B)}.",
                Math.Abs(c.BridgeByCause.Where(s => s.Name is "Fresh input" or "Cache write").Sum(s => s.Delta))));

        var calls = c.Headline.Single(h => h.Name == "Model calls");
        if (calls.A > 0 && Math.Abs(calls.Change) / calls.A >= 0.2)
            list.Add(new Finding(FindingTopic.Driver, $"{c.LabelB} made {calls.B:0} model calls against {calls.A:0} in {c.LabelA}.", Math.Abs(d) * 0.3));

        var main = c.Overhead.FirstOrDefault(o => o.Agent == AgentRun.MainName);
        if (main is { FirstCallA: long fa, FirstCallB: long fb } && Math.Abs(fb - fa) >= Math.Max(1000, 0.1 * fa))
            list.Add(new Finding(FindingTopic.Overhead,
                $"The main agent's fixed overhead went from {Findings.Tok(fa)} to {Findings.Tok(fb)} tokens per call (instructions, tools, skills).",
                Math.Abs(d) * 0.2));

        var tool = c.Tools.FirstOrDefault(t => Math.Abs(t.GrowthDelta) >= 1000);
        if (tool is not null)
            list.Add(new Finding(FindingTopic.Growth,
                $"{tool.Tool} context growth went from {Findings.Tok(tool.GrowthA)} to {Findings.Tok(tool.GrowthB)} tokens ({tool.CallsA} → {tool.CallsB} calls).",
                Math.Abs(d) * 0.2));

        var lc = c.Headline.Single(h => h.Name == "Long-context calls");
        if (lc.Change != 0)
            list.Add(new Finding(FindingTopic.LongContext, $"Long-context calls went from {lc.A:0} to {lc.B:0}.", Math.Abs(d) * 0.25));

        // The overall change always leads; the rest are ranked by credits at stake.
        return list.Take(1).Concat(list.Skip(1).OrderByDescending(f => f.AtStake)).ToList();
    }
}
