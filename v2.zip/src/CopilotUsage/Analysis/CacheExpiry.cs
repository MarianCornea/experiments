using CopilotUsage.Model;
using CopilotUsage.Pricing;

namespace CopilotUsage.Analysis;

/// <summary>A call that found its prompt cache expired after a pause longer than the cache's lifetime.</summary>
public sealed record CacheExpiryRow(
    int CallIndex,
    string Run,
    string Model,
    DateTimeOffset PreviousStart,
    DateTimeOffset Start,
    double PauseMinutes,
    int TtlMinutes,
    /// <summary>True when the lifetime was not logged and Copilot's usual 30 minutes was assumed.</summary>
    bool TtlAssumed,
    /// <summary>Tokens the call could have read from the cache but had to send again.</summary>
    long LostTokens,
    /// <summary>Credits paid for those tokens (cache write, or fresh input) minus what reading them would have cost; null when unpriced.</summary>
    double? ExtraCredits);

/// <summary>
/// Copilot keeps a prompt cache for its lifetime (30 minutes on the Copilot harness) after the last call that used it;
/// every call restarts it. A pause longer than that, within one agent run and model, loses the cache: the next call
/// writes its context again (or sends it fresh) instead of reading it. A pause counts only when the call really read
/// little from the cache, so a cache that survived is never flagged.
/// </summary>
public static class CacheExpiry
{
    public const int DefaultTtlSeconds = 1800;

    public static IReadOnlyList<CacheExpiryRow> Find(SessionData s, PricingTable pricing)
    {
        if (s.PerRequest) return [];
        var engine = new CostEngine(pricing);
        var observed = CostEngine.ObservedRates(s.Calls);
        var rows = new List<CacheExpiryRow>();
        foreach (var group in s.SuccessfulCalls.Where(c => c.Kind != CallKind.Title).GroupBy(c => (c.AgentRunId, c.Model)))
        {
            var calls = group.OrderBy(c => c.Start).ToList();
            for (int i = 1; i < calls.Count; i++)
            {
                var prev = calls[i - 1];
                var cur = calls[i];
                int ttl = prev.CacheTtlSeconds ?? DefaultTtlSeconds;
                double pause = (cur.Start - prev.Start).TotalSeconds;
                if (pause <= ttl) continue;
                long reusable = Math.Min(prev.Input, cur.Input);
                // Evidence that the cache was gone: under half of what the previous call held was read back.
                if (reusable <= 0 || cur.CacheRead >= reusable * 0.5) continue;
                long lost = reusable - cur.CacheRead;
                double? extra = engine.RatesFor(cur, observed) is { } r
                    ? lost * ((cur.CacheWrite > 0 ? r.CacheWrite : r.FreshInput) - r.CacheRead)
                    : null;
                var label = s.Runs.TryGetValue(group.Key.AgentRunId, out var run) ? Breakdown.RunLabel(s, run) : group.Key.AgentRunId;
                rows.Add(new CacheExpiryRow(cur.Index, label, cur.Model, prev.Start, cur.Start, pause / 60, ttl / 60, prev.CacheTtlSeconds is null, lost,
                    extra is double e ? Math.Max(0, e) : null));
            }
        }
        return rows.OrderBy(r => r.Start).ToList();
    }
}
