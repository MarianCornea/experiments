using System.Text.Json;
using System.Text.RegularExpressions;
using CopilotUsage.Model;
using CopilotUsage.Pricing;
using CopilotUsage.Storage;

namespace CopilotUsage.Analysis;

/// <summary>
/// --mcp-map file (FR-22): a JSON object of tool-name patterns to server names, "*" matching any text, e.g.
/// {"jira_*": "jira", "search_code": "code-search", "github-pull-request_*": null}. A null server marks the tools
/// as not MCP (an extension tool whose name happens to look like a prefix). The first matching pattern wins.
/// </summary>
public sealed class McpMap
{
    readonly List<(Regex Pattern, string Server)> _rules = [];

    public static McpMap Load(string path)
    {
        if (!File.Exists(path)) throw new CliException($"--mcp-map {path}: file not found");
        try
        {
            using var doc = JsonDocument.Parse(SafeFile.ReadAllText(path), new JsonDocumentOptions { CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true });
            if (doc.RootElement.ValueKind != JsonValueKind.Object) throw new CliException($"--mcp-map {path}: expected a JSON object of \"tool pattern\": \"server\"");
            var map = new McpMap();
            foreach (var p in doc.RootElement.EnumerateObject())
            {
                if (p.Value.ValueKind == JsonValueKind.Null) { map.Add(p.Name, ""); continue; }
                if (p.Value.ValueKind != JsonValueKind.String || p.Value.GetString() is not { Length: > 0 } server)
                    throw new CliException($"--mcp-map {path}: the server for \"{p.Name}\" must be a name, or null for a tool that is not MCP");
                map.Add(p.Name, server);
            }
            return map;
        }
        catch (JsonException e)
        {
            throw new CliException($"--mcp-map {path} is not valid JSON: {e.Message}");
        }
    }

    public McpMap Add(string pattern, string server)
    {
        _rules.Add((new Regex("^" + Regex.Escape(pattern).Replace("\\*", ".*") + "$", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant), server));
        return this;
    }

    /// <summary>The mapped server; "" when the map says the tool is not MCP; null when no pattern matches.</summary>
    public string? Match(string tool) => _rules.FirstOrDefault(r => r.Pattern.IsMatch(tool)).Server;
}

/// <summary>Which MCP server a tool belongs to, from its name (FR-22).</summary>
public static class McpNames
{
    /// <summary>
    /// The map first; then the prefixes the clients use: VS Code "mcp_&lt;server&gt;_&lt;tool&gt;" (server label cut to 13
    /// characters), Claude-style "mcp__&lt;server&gt;__&lt;tool&gt;", and the Copilot runtime's "&lt;server&gt;-&lt;tool&gt;"
    /// (e.g. github-mcp-server-get_issue). Built-in tools have none of these, so they return null.
    /// </summary>
    public static string? ServerOf(string tool, McpMap? map = null)
    {
        if (map?.Match(tool) is { } mapped) return mapped.Length == 0 ? null : mapped;
        if (tool.StartsWith("mcp__", StringComparison.OrdinalIgnoreCase))
        {
            int end = tool.IndexOf("__", 5, StringComparison.Ordinal);
            return end > 5 ? tool[5..end] : null;
        }
        if (tool.StartsWith("mcp_", StringComparison.OrdinalIgnoreCase))
        {
            int end = tool.IndexOf('_', 4);
            return end > 4 ? tool[4..end] : null;
        }
        int dash = tool.LastIndexOf('-');
        return dash > 0 && dash < tool.Length - 1 ? tool[..dash] : null;
    }
}

public sealed record McpToolStats(string Tool, bool Loaded, int Calls, double DurationMs, int Failures, long? ResultTokens, long CarriedTokens, IReadOnlyList<string> CalledBy);

public sealed record McpServerStats(
    string Server,
    /// <summary>Tool definitions of this server the session sent; null when the logs carry no definitions.</summary>
    int? ToolsLoaded,
    IReadOnlyList<string> UnusedTools,
    /// <summary>Size of the server's definitions per call (the largest set seen); null when not logged.</summary>
    long? DefinitionTokensPerCall,
    long? DefinitionTokensCarried,
    int CallsCarrying,
    /// <summary>Credits for the carried definitions: all cached (low), each call's cached share (point), all fresh (high).</summary>
    (double Low, double Point, double High)? DefinitionCost,
    IReadOnlyList<McpToolStats> Tools,
    long ResultTokens,
    long ResultCarried,
    /// <summary>Definition plus carried result tokens as a share of all input tokens.</summary>
    double ShareOfSession,
    IReadOnlyList<string> LoadedBy,
    IReadOnlyList<string> CalledBy)
{
    public int ToolsUsed => Tools.Count(t => t.Calls > 0);
    public int Calls => Tools.Sum(t => t.Calls);
    public int Failures => Tools.Sum(t => t.Failures);
}

public sealed record McpResult(
    IReadOnlyList<McpServerStats> Servers,
    /// <summary>True when per-tool definitions were logged (Local harness tools_N.json).</summary>
    bool DefinitionsLogged,
    /// <summary>All tool definitions carried, when only a per-call total is logged (Copilot harness toolTokenCount).</summary>
    long? AllDefinitionTokensCarried,
    long TotalInputTokens)
{
    public static readonly McpResult Empty = new([], false, null, 0);
}

/// <summary>Each MCP server's cost account (FR-21): what its definitions and its results cost the session.</summary>
public static class McpStats
{
    public static McpResult Analyze(SessionData s, PricingTable pricing, McpMap? map = null)
    {
        if (s.PerRequest) return McpResult.Empty with { Servers = ToolsOnly(s, map) };
        var calls = s.SuccessfulCalls.Where(c => c.Kind != CallKind.Title).ToList();
        long totalInput = calls.Sum(c => c.Input);
        bool logged = s.ToolDefinitions.Count > 0;

        // Definitions: per tools file, each server's tools and their size.
        var defsByFile = s.ToolDefinitions.ToDictionary(kv => kv.Key,
            kv => kv.Value.Select(d => (d.Name, d.Tokens, Server: McpNames.ServerOf(d.Name, map))).Where(d => d.Server is not null).ToList(),
            StringComparer.OrdinalIgnoreCase);
        var engine = new CostEngine(pricing);
        var observed = CostEngine.ObservedRates(s.Calls);

        var servers = defsByFile.Values.SelectMany(d => d.Select(x => x.Server!))
            .Concat(s.Tools.Select(t => McpNames.ServerOf(t.Name, map)).Where(x => x is not null).Select(x => x!))
            .Distinct(StringComparer.OrdinalIgnoreCase).Order(StringComparer.OrdinalIgnoreCase).ToList();

        var result = new List<McpServerStats>();
        foreach (var server in servers)
        {
            bool Mine(string? sv) => string.Equals(sv, server, StringComparison.OrdinalIgnoreCase);
            var loadedNames = defsByFile.Values.SelectMany(d => d).Where(d => Mine(d.Server)).Select(d => d.Name).Distinct(StringComparer.OrdinalIgnoreCase).ToList();

            long? perCall = null, carried = null;
            int carrying = 0;
            double low = 0, point = 0, high = 0;
            bool priced = true;
            var loadedBy = new SortedSet<string>(StringComparer.Ordinal);
            if (logged)
            {
                carried = 0;
                foreach (var c in calls)
                {
                    if (c.ToolsFile is null || !defsByFile.TryGetValue(c.ToolsFile, out var defs)) continue;
                    long tokens = defs.Where(d => Mine(d.Server)).Sum(d => d.Tokens);
                    if (tokens == 0) continue;
                    carrying++;
                    carried += tokens;
                    perCall = Math.Max(perCall ?? 0, tokens);
                    loadedBy.Add(c.Agent);
                    if (engine.RatesFor(c, observed) is { } r)
                    {
                        double cachedShare = c.Input == 0 ? 0 : Math.Clamp((double)c.CacheRead / c.Input, 0, 1);
                        low += tokens * r.CacheRead;
                        high += tokens * r.FreshInput;
                        point += tokens * (cachedShare * r.CacheRead + (1 - cachedShare) * r.FreshInput);
                    }
                    else priced = false;
                }
            }

            var mine = s.Tools.Where(t => Mine(McpNames.ServerOf(t.Name, map))).ToList();
            var tools = mine.GroupBy(t => t.Name, StringComparer.OrdinalIgnoreCase)
                .Select(g => new McpToolStats(g.Key, loadedNames.Contains(g.Key, StringComparer.OrdinalIgnoreCase), g.Count(),
                    g.Sum(t => (t.End - t.Start).TotalMilliseconds), g.Count(t => !t.Success),
                    g.Any(t => t.SizeTokens is not null) ? g.Sum(t => t.SizeTokens ?? 0) : null,
                    g.Sum(t => t.CarriedTokens), g.Select(t => t.Agent).Distinct().Order(StringComparer.Ordinal).ToList()))
                .Concat(loadedNames.Where(n => !mine.Any(t => t.Name.Equals(n, StringComparison.OrdinalIgnoreCase)))
                    .Select(n => new McpToolStats(n, true, 0, 0, 0, null, 0, [])))
                .OrderByDescending(t => t.CarriedTokens).ThenByDescending(t => t.Calls).ThenBy(t => t.Tool, StringComparer.OrdinalIgnoreCase)
                .ToList();
            long resultTokens = tools.Sum(t => t.ResultTokens ?? 0), resultCarried = tools.Sum(t => t.CarriedTokens);
            result.Add(new McpServerStats(
                server,
                logged ? loadedNames.Count : null,
                tools.Where(t => t.Loaded && t.Calls == 0).Select(t => t.Tool).ToList(),
                perCall, carried, carrying,
                logged && carried > 0 && priced ? (low, point, high) : null,
                tools, resultTokens, resultCarried,
                totalInput == 0 ? 0 : (double)((carried ?? 0) + resultCarried) / totalInput,
                loadedBy.ToList(),
                mine.Select(t => t.Agent).Distinct().Order(StringComparer.Ordinal).ToList()));
        }

        long? allDefs = !logged && calls.Any(c => c.ToolDefinitionTokens is not null) ? calls.Sum(c => c.ToolDefinitionTokens ?? 0) : null;
        return new McpResult(result.OrderByDescending(r => (r.DefinitionTokensCarried ?? 0) + r.ResultCarried).ThenByDescending(r => r.Calls).ToList(),
            logged, allDefs, totalInput);
    }

    /// <summary>Chat transcripts: tool calls only, no sizes or definitions.</summary>
    static List<McpServerStats> ToolsOnly(SessionData s, McpMap? map) =>
        s.Tools.Select(t => (Tool: t, Server: McpNames.ServerOf(t.Name, map))).Where(x => x.Server is not null)
            .GroupBy(x => x.Server!, StringComparer.OrdinalIgnoreCase)
            .Select(g => new McpServerStats(g.Key, null, [], null, null, 0, null,
                g.GroupBy(x => x.Tool.Name).Select(t => new McpToolStats(t.Key, false, t.Count(), 0, t.Count(x => !x.Tool.Success), null, 0,
                    t.Select(x => x.Tool.Agent).Distinct().ToList())).ToList(),
                0, 0, 0, [], g.Select(x => x.Tool.Agent).Distinct().ToList()))
            .ToList();
}
