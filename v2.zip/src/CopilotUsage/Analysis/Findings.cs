using System.Globalization;
using CopilotUsage.Model;

namespace CopilotUsage.Analysis;

public enum FindingTopic { Driver, Cause, Growth, Model, LongContext, Cache, Overhead, Mcp, Budget, Measuring, Data }

/// <summary>A rule-based statement with numbers. AtStake (credits) ranks it.</summary>
public sealed record Finding(FindingTopic Topic, string Text, double AtStake);

/// <summary>
/// The report's findings (spec: "rule-based statements with numbers, ranked by credits at stake"). Each rule answers
/// one of the report's three questions: which part cost the most, why, and what grew the context.
/// </summary>
public static class Findings
{
    public static IReadOnlyList<Finding> For(SessionData s, ContextGrowthResult growth, McpResult? mcp = null, IReadOnlyList<CacheExpiryRow>? expiries = null)
    {
        var calls = s.SuccessfulCalls.ToList();
        var list = new List<Finding>();
        double total = calls.Sum(c => c.Cost.Credits);
        if (calls.Count == 0) return [new Finding(FindingTopic.Data, "No model calls were logged in this session.", 0)];
        if (total <= 0) list.Add(new Finding(FindingTopic.Data, "No credits could be priced: no billed values and no known model prices.", 0));
        if (s.PerRequest)
            list.Add(new Finding(FindingTopic.Data,
                "This chat was read from VS Code's chat transcript: credits are billed per request and per sub-agent run, but tokens per model call are not recorded, " +
                "so the cost cannot be split by cause and context growth is not shown.", 0));

        // Which part cost the most: the top agent run (or the top phase, when phases exist).
        var runs = Breakdown.By(s, Dimension.AgentRun);
        if (runs.Count > 1)
        {
            var top = runs[0];
            var label = top.Key == AgentRun.MainName ? "The main agent" : $"Sub-agent run {top.Key}";
            list.Add(new Finding(FindingTopic.Driver,
                $"{label} took {Pct(top.Share)} of credits ({Cr(top.Credits)} of {Cr(total)}){(s.PerRequest ? "" : $" in {top.Calls} calls")}.", top.Credits));
            double sub = runs.Where(r => r.Key != AgentRun.MainName).Sum(r => r.Credits);
            if (sub > 0 && runs.Count > 2)
                list.Add(new Finding(FindingTopic.Driver,
                    $"Sub-agents together took {Pct(sub / total)} of credits ({Cr(sub)}) over {runs.Count - 1} runs.", sub > runs[0].Credits ? sub : sub * 0.5));
        }
        var phases = Breakdown.By(s, Dimension.Phase).Where(r => r.Key != Breakdown.NoPhase).ToList();
        if (phases.Count > 0)
            list.Add(new Finding(FindingTopic.Driver,
                $"Phase {phases[0].Key} cost the most: {Cr(phases[0].Credits)} ({Pct(phases[0].Share)}).", phases[0].Credits));

        // Why: the largest cost cause, and cache behaviour.
        var split = calls.Aggregate(CostSplit.Zero, (a, c) => a + c.Cost.Split);
        if (split.Total - split.Unsplit > 0)
        {
            var causes = new (string Name, double Credits, string Why)[]
            {
                ("output", split.Output, "output tokens are the most expensive per token; long answers, reasoning and tool-call arguments add up"),
                ("cache writes", split.CacheWrite, "new context is written to the cache at a premium; it pays off only if later calls reuse it"),
                ("cache reads", split.CacheRead, "context carried from call to call; it grows with every tool result kept in the conversation"),
                ("fresh input", split.FreshInput, "input not served from the cache; a changing prompt start or a model without caching causes it"),
            };
            var top = causes.MaxBy(c => c.Credits);
            list.Add(new Finding(FindingTopic.Cause,
                $"{Cap(top.Name)} {(top.Name.EndsWith('s') ? "were" : "was")} the largest cost: {Pct(top.Credits / split.Total)} ({Cr(top.Credits)}). Why it matters: {top.Why}.",
                top.Credits));
        }
        long input = calls.Sum(c => c.Input), read = calls.Sum(c => c.CacheRead);
        double cachedShare = input == 0 ? 0 : (double)read / input;
        if (input > 0 && cachedShare < 0.5 && !s.PerRequest)
            list.Add(new Finding(FindingTopic.Cache,
                $"Only {Pct(cachedShare)} of input was served from the cache, so most input was paid at the full rate ({Cr(split.FreshInput + split.CacheWrite)}).",
                split.FreshInput + split.CacheWrite));
        foreach (var model in calls.GroupBy(c => c.Model).Where(g => g.Count() >= 3 && g.Sum(c => c.CacheWrite) == 0 && g.Sum(c => c.Cost.Split.FreshInput) > 0.15 * total))
            list.Add(new Finding(FindingTopic.Cache,
                $"{model.Key} wrote nothing to the cache: its fresh input cost {Cr(model.Sum(c => c.Cost.Split.FreshInput))}.",
                model.Sum(c => c.Cost.Split.FreshInput)));

        // Long context.
        var longCalls = calls.Where(c => c.Cost.LongContext).ToList();
        if (longCalls.Count > 0)
        {
            var limits = string.Join(", ", longCalls.Select(c => c.Cost.LongContextThreshold).OfType<long>().Distinct().Order().Select(t => Tok(t)));
            var premium = longCalls.Where(c => c.Cost.LongContextPremium is not null).Sum(c => c.Cost.LongContextPremium!.Value);
            list.Add(new Finding(FindingTopic.LongContext,
                longCalls.Any(c => c.Cost.LongContextPremium is not null)
                    ? $"{longCalls.Count} calls went over the long-context threshold ({limits}) and paid {Cr(premium)} of long-context premium."
                    : $"{longCalls.Count} calls went over the long-context threshold ({limits}; the premium cannot be priced for {string.Join(", ", longCalls.Select(c => c.Model).Distinct())}).",
                Math.Max(premium, longCalls.Sum(c => c.Cost.Credits) * 0.3)));
        }

        // Model mix: a model that costs much more per call than the others.
        var models = calls.GroupBy(c => c.Model).Select(g => (Model: g.Key, Calls: g.Count(), PerCall: g.Average(c => c.Cost.Credits), Total: g.Sum(c => c.Cost.Credits)))
            .Where(m => m.Calls >= 3).OrderByDescending(m => m.PerCall).ToList();
        if (models.Count >= 2 && models[0].PerCall >= 1.5 * models[^1].PerCall)
            list.Add(new Finding(FindingTopic.Model,
                $"{models[0].Model} averaged {Cr(models[0].PerCall)} credits per call, {models[0].PerCall / models[^1].PerCall:0.0}× {models[^1].Model} ({Cr(models[^1].PerCall)}).",
                models[0].Total - models[0].Calls * models[^1].PerCall));

        // What grew the context.
        var topTool = growth.Tools.FirstOrDefault(t => t.InferredGrowth > 0);
        if (topTool is not null)
        {
            var measured = topTool.MeasuredTokens is long m && topTool.MeasuredCalls == topTool.Calls ? $"; its results measured {Tok(m)} tokens" : "";
            double growthShare = growth.Tools.Sum(t => t.InferredGrowth) is var all && all > 0 ? topTool.InferredGrowth / all : 0;
            list.Add(new Finding(FindingTopic.Growth,
                $"{topTool.Tool} preceded {Tok(topTool.InferredGrowth)} tokens of context growth ({Pct(growthShare)} of tool growth, {topTool.Calls} calls{measured}).",
                CarryCost(s, topTool.InferredGrowth)));
            foreach (var t in growth.Tools.Where(t => t.MeasuredTokens is long mt && t.MeasuredCalls == t.Calls && t.InferredGrowth > 2000 && mt < t.InferredGrowth * 0.2))
                list.Add(new Finding(FindingTopic.Growth,
                    $"{t.Tool} is credited {Tok(t.InferredGrowth)} tokens of growth but returned only {Tok(t.MeasuredTokens!.Value)}: the growth is the model's own tool-call arguments (e.g. the patch it wrote).",
                    CarryCost(s, t.InferredGrowth) * 0.5));
        }
        if (growth.Resets > 0)
            list.Add(new Finding(FindingTopic.Growth, $"Context dropped {Times(growth.Resets)} ({Tok(growth.ResetTokens)} tokens): compactions or resets.", 0));

        // Fixed overhead per run.
        var mainFirst = growth.FixedOverhead.FirstOrDefault(o => o.Agent == AgentRun.MainName);
        if (mainFirst.FirstCallInput > 0)
        {
            int mainCalls = calls.Count(c => c.AgentRunId == AgentRun.MainId);
            list.Add(new Finding(FindingTopic.Overhead,
                $"The main agent starts from {Tok(mainFirst.FirstCallInput)} tokens before any work (instructions, tools, skills); every one of its {mainCalls} calls carries them.",
                CarryCost(s, mainFirst.FirstCallInput) * mainCalls / Math.Max(1, calls.Count)));
        }

        // Cache expiries: a pause longer than the cache lifetime made the next call pay to cache its context again.
        if (expiries is { Count: > 0 })
        {
            var longest = expiries.MaxBy(e => e.PauseMinutes)!;
            double extra = expiries.Sum(e => e.ExtraCredits ?? 0);
            string who = longest.Run == AgentRun.MainName ? "the main agent" : longest.Run;
            string life = $"Copilot keeps it {longest.TtlMinutes} minutes{(longest.TtlAssumed ? ", its usual lifetime" : "")} after the last call";
            string cost = extra > 0 ? $", about {Cr(extra)} credits more than reading {(expiries.Count == 1 ? "them" : "it all")} from the cache" : "";
            list.Add(new Finding(FindingTopic.Cache, expiries.Count == 1
                ? $"After a {longest.PauseMinutes:0}-minute pause at {longest.Start.ToLocalTime():HH:mm}, {who}'s cache had expired ({life}): the next call sent {Tok(longest.LostTokens)} tokens again{cost}."
                : $"{expiries.Count} pauses outlasted the cache ({life}): the calls after them sent {Tok(expiries.Sum(e => e.LostTokens))} tokens again{cost}. The longest was {longest.PauseMinutes:0} minutes at {longest.Start.ToLocalTime():HH:mm} in {who}.",
                extra));
        }

        // Context headroom: a run that came near the prompt size its model allows (window minus the output reservation).
        foreach (var r in Headroom.By(s).Where(r => r.Share >= 0.8))
            list.Add(new Finding(FindingTopic.Growth,
                $"{(r.Run == AgentRun.MainName ? "The main agent" : "Run " + r.Run)} reached {Pct(r.Share!.Value)} of its usable context ({Tok(r.Peak)} of {Tok(r.Usable!.Value)} tokens on {r.Model})" +
                (r.Drops > 0 ? $"; its context dropped {Times(r.Drops)}" : "") + ": near the limit Copilot compacts, and until then every call carries the full context.",
                r.Credits * 0.5));

        // MCP servers (FR-21): definitions that ride along unused, results carried, servers loaded where they are not used.
        foreach (var sv in mcp?.Servers ?? [])
        {
            if (sv.ToolsLoaded is int loaded && sv.DefinitionTokensCarried is long defCarried && defCarried > 0 && sv.ToolsUsed < loaded)
            {
                var cost = sv.DefinitionCost is { } dc ? $", {Cr(dc.Low)} to {Cr(dc.High)} credits depending on caching" : "";
                list.Add(new Finding(FindingTopic.Mcp,
                    $"Server {sv.Server} loads {loaded} tools and used {sv.ToolsUsed}. Its definitions add about {Tok(sv.DefinitionTokensPerCall ?? 0)} tokens to {sv.CallsCarrying} calls: {Tok(defCarried)} tokens{cost}.",
                    sv.DefinitionCost?.Point ?? CarryCost(s, defCarried) / Math.Max(1, s.SuccessfulCalls.Count() / 2.0)));
            }
            if (sv.LoadedBy.Count >= 2 && sv.CalledBy.Count == 1)
                list.Add(new Finding(FindingTopic.Mcp,
                    $"Server {sv.Server} is loaded by {sv.LoadedBy.Count} agents but called only by {sv.CalledBy[0]}: restrict it to that agent with the custom agent's tools list.",
                    (sv.DefinitionCost?.Point ?? 0) * 0.5));
        }
        var topMcpTool = (mcp?.Servers ?? []).SelectMany(sv => sv.Tools).Where(t => t.CarriedTokens > 0 && t.ResultTokens > 0).MaxBy(t => t.CarriedTokens);
        if (topMcpTool is not null)
            list.Add(new Finding(FindingTopic.Mcp,
                $"Tool {topMcpTool.Tool} returned {topMcpTool.Calls} result{(topMcpTool.Calls == 1 ? "" : "s")} averaging {Tok((double)topMcpTool.ResultTokens!.Value / topMcpTool.Calls)} tokens; later calls carried them for {Tok(topMcpTool.CarriedTokens)} tokens.",
                CarryCost(s, topMcpTool.CarriedTokens) / Math.Max(1, s.SuccessfulCalls.Count() / 2.0)));

        // Budget stops the hook gave (FR-19).
        foreach (var stop in s.BudgetStops)
            list.Add(new Finding(FindingTopic.Budget, stop.Budget switch
            {
                "soft" => $"The soft budget of {Cr(stop.Limit ?? 0)} credits was reached at {stop.Time.ToLocalTime():HH:mm} ({Cr(stop.Credits ?? 0)} used): the next tool call was blocked so the agent would wrap up.",
                "hard" => $"The hard budget of {Cr(stop.Limit ?? 0)} credits was reached at {stop.Time.ToLocalTime():HH:mm} ({Cr(stop.Credits ?? 0)} used): the session was stopped.",
                _ => $"The budget check failed at {stop.Time.ToLocalTime():HH:mm} and is set to fail closed: the session was stopped.",
            }, total));

        // The cost of measuring.
        var measuring = calls.Where(c => c.Skill == "workflow-cost").ToList();
        if (measuring.Count > 0)
            list.Add(new Finding(FindingTopic.Measuring,
                $"Measuring (the workflow-cost skill) cost {Cr(measuring.Sum(c => c.Cost.Credits))} ({Pct(measuring.Sum(c => c.Cost.Credits) / Math.Max(1e-9, total))}) in {measuring.Count} calls.",
                measuring.Sum(c => c.Cost.Credits)));

        // Data quality.
        var unpriced = s.Calls.Count(c => c.Cost.Source == CostSource.Unpriced);
        if (unpriced > 0)
            list.Add(new Finding(FindingTopic.Data, $"{unpriced} calls could not be priced ({string.Join(", ", s.Diagnostics.UnpricedModels)}): totals are low by their cost.", total));
        double estimated = s.EstimatedCredits;
        if (estimated > 0)
            list.Add(new Finding(FindingTopic.Data, $"{Pct(estimated / Math.Max(1e-9, total))} of credits are estimated, not billed ({Cr(estimated)}).", estimated * 0.2));

        return list.OrderByDescending(f => f.AtStake).ThenBy(f => f.Topic).ToList();
    }

    /// <summary>Credits a block of tokens costs by being carried in the calls after it, at the session's average cache-read rate.</summary>
    static double CarryCost(SessionData s, double tokens)
    {
        var calls = s.SuccessfulCalls.Where(c => c.CacheRead > 0 && c.Cost.Split.CacheRead > 0).ToList();
        double rate = calls.Count == 0 ? 0 : calls.Sum(c => c.Cost.Split.CacheRead) / calls.Sum(c => c.CacheRead);
        return tokens * rate * Math.Max(1, s.SuccessfulCalls.Count() / 2.0);
    }

    internal static string Times(int n) => n == 1 ? "once" : n == 2 ? "twice" : $"{n} times";

    static string Cap(string s) => char.ToUpperInvariant(s[0]) + s[1..];
    internal static string Pct(double share) => (share * 100).ToString("0", CultureInfo.InvariantCulture) + "%";
    internal static string Cr(double c) => c == 0 ? "0" : c.ToString(Math.Abs(c) >= 100 ? "N1" : Math.Abs(c) >= 0.01 ? "N2" : "N4", CultureInfo.InvariantCulture);

    internal static string Tok(double n) => n switch
    {
        >= 1e6 => (n / 1e6).ToString("0.0", CultureInfo.InvariantCulture) + "M",
        >= 1e4 => (n / 1e3).ToString("0", CultureInfo.InvariantCulture) + "K",
        >= 1e3 => (n / 1e3).ToString("0.0", CultureInfo.InvariantCulture) + "K",
        _ => n.ToString("0", CultureInfo.InvariantCulture),
    };
}
