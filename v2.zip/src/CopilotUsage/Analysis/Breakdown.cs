using CopilotUsage.Model;

namespace CopilotUsage.Analysis;

public enum Dimension { Phase, AgentRun, Agent, Turn, Skill, Model, Kind }

public sealed record BreakdownRow(
    string Key,
    int Calls,
    long Input,
    long CacheRead,
    long CacheWrite,
    long Output,
    double Credits,
    double BilledCredits,
    CostSplit Split,
    double Share)
{
    /// <summary>Share of input served from the cache.</summary>
    public double CachedShare => Input == 0 ? 0 : (double)CacheRead / Input;
    public double EstimatedCredits => Credits - BilledCredits;
}

/// <summary>Cost attributed to phase, agent run, agent, skill, model and call kind (FR-07).</summary>
public static class Breakdown
{
    public const string NoPhase = "(no phase)";
    public const string NoSkill = "(no skill)";

    public static IReadOnlyList<BreakdownRow> By(SessionData session, Dimension dimension)
    {
        var runs = session.Runs;
        string Key(ModelCall c) => dimension switch
        {
            Dimension.Phase => c.Phase ?? NoPhase,
            Dimension.AgentRun => runs.TryGetValue(c.AgentRunId, out var r) ? RunLabel(session, r) : c.AgentRunId,
            Dimension.Agent => c.Agent,
            Dimension.Turn => c.Turn is int t && t <= session.TurnStarts.Count ? $"turn {t} ({session.TurnStarts[t - 1].ToLocalTime():HH:mm})" : "(before first prompt)",
            Dimension.Skill => c.Skill ?? NoSkill,
            Dimension.Model => c.Model,
            Dimension.Kind => c.Kind.ToString().ToLowerInvariant(),
            _ => "?",
        };

        var calls = session.SuccessfulCalls.ToList();
        double total = calls.Sum(c => c.Cost.Credits);
        return calls
            .GroupBy(Key)
            .Select(g => new BreakdownRow(
                g.Key,
                // A chat-transcript record counts the model calls it sums; a sub-agent run with an unknown count counts one.
                g.Sum(c => Math.Max(1, c.Rounds ?? 1)),
                g.Sum(c => c.Input),
                g.Sum(c => c.CacheRead),
                g.Sum(c => c.CacheWrite),
                g.Sum(c => c.Output),
                g.Sum(c => c.Cost.Credits),
                g.Where(c => c.Cost.Source == CostSource.Billed).Sum(c => c.Cost.Credits),
                g.Aggregate(CostSplit.Zero, (s, c) => s + c.Cost.Split),
                total == 0 ? 0 : g.Sum(c => c.Cost.Credits) / total))
            .OrderByDescending(r => r.Credits)
            .ThenBy(r => r.Key, StringComparer.Ordinal)
            .ToList();
    }

    /// <summary>"main", or "explore #2 (10:42)" for the second run of a sub-agent, so repeated runs stay apart.</summary>
    public static string RunLabel(SessionData session, AgentRun run)
    {
        if (run.IsMain) return run.Name;
        var same = session.Runs.Values.Where(r => !r.IsMain && r.Name == run.Name)
            .OrderBy(r => r.Start ?? DateTimeOffset.MaxValue).ThenBy(r => r.Id, StringComparer.Ordinal).ToList();
        int n = same.IndexOf(run) + 1;
        var when = run.Start is { } s ? $" ({s.ToLocalTime():HH:mm})" : "";
        return same.Count > 1 ? $"{run.Name} #{n}{when}" : run.Name + when;
    }
}
