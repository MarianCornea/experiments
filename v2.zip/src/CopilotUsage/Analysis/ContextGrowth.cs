using CopilotUsage.Model;

namespace CopilotUsage.Analysis;

public sealed record ToolGrowthRow(
    string Tool,
    int Calls,
    double DurationMs,
    double InferredGrowth,
    long? MeasuredTokens,
    int MeasuredCalls,
    /// <summary>Result tokens × the later calls that still carried them, up to the next reset (measured size, else inferred).</summary>
    long CarriedTokens)
{
    public double GrowthPerCall => Calls == 0 ? 0 : InferredGrowth / Calls;
}

public sealed record ContextGrowthResult(
    IReadOnlyList<ToolGrowthRow> Tools,
    /// <summary>Growth with no tool call between two model calls: user messages and the model's own turns.</summary>
    double ModelTurnGrowth,
    /// <summary>Drops in context: compactions or resets.</summary>
    int Resets,
    long ResetTokens,
    /// <summary>First call's input per agent run: the fixed overhead (instructions, tools, skills) before any work.</summary>
    IReadOnlyList<(string Run, string Agent, long FirstCallInput)> FixedOverhead);

/// <summary>
/// Context growth attributed to tools (FR-08). Within one agent run, delta = this call's input minus the previous
/// call's. A positive delta is shared equally by the tool calls that ran between the two calls; with no tool call it
/// goes to "model turn / user message". A negative delta marks a compaction or reset.
/// </summary>
public static class ContextGrowth
{
    public const string ModelTurn = "(model turn / user message)";

    public static ContextGrowthResult Analyze(SessionData session)
    {
        var growth = new Dictionary<string, double>(StringComparer.Ordinal);
        double modelTurn = 0;
        int resets = 0;
        long resetTokens = 0;
        var overhead = new List<(string, string, long)>();

        foreach (var t in session.Tools) { t.InferredTokens = null; t.CarriedTokens = 0; }
        var toolsByRun = session.Tools.GroupBy(t => t.AgentRunId).ToDictionary(g => g.Key, g => g.OrderBy(t => t.Start).ToList());
        // Records that sum several calls (chat transcript) hold only the last prompt's size: no growth can be inferred from them.
        foreach (var run in session.SuccessfulCalls.Where(c => c.Kind != CallKind.Title && c.Rounds is null).GroupBy(c => c.AgentRunId))
        {
            var calls = run.OrderBy(c => c.Start).ToList();
            var runInfo = session.Runs.GetValueOrDefault(run.Key);
            overhead.Add((runInfo is null ? run.Key : Breakdown.RunLabel(session, runInfo), calls[0].Agent, calls[0].Input));
            var tools = toolsByRun.GetValueOrDefault(run.Key) ?? [];
            for (int i = 1; i < calls.Count; i++)
            {
                var prev = calls[i - 1];
                var cur = calls[i];
                long delta = cur.Input - prev.Input;
                if (delta < 0)
                {
                    resets++;
                    resetTokens += -delta;
                    continue;
                }
                if (delta == 0) continue;
                // Tools that started after the previous call began and before this call started fed this call's context.
                var between = tools.Where(t => t.Start >= prev.Start && t.Start < cur.Start).ToList();
                if (between.Count == 0)
                {
                    modelTurn += delta;
                    continue;
                }
                double each = (double)delta / between.Count;
                foreach (var t in between)
                {
                    growth[t.Name] = growth.GetValueOrDefault(t.Name) + each;
                    t.InferredTokens = (t.InferredTokens ?? 0) + each;
                }
            }
            Carry(calls, tools);
        }

        var rows = session.Tools
            .GroupBy(t => t.Name)
            .Select(g =>
            {
                var measured = g.Where(t => t.ResultTokens is not null).ToList();
                return new ToolGrowthRow(
                    g.Key,
                    g.Count(),
                    g.Sum(t => (t.End - t.Start).TotalMilliseconds),
                    growth.GetValueOrDefault(g.Key),
                    measured.Count > 0 ? measured.Sum(t => t.ResultTokens!.Value) : null,
                    measured.Count,
                    g.Sum(t => t.CarriedTokens));
            })
            .OrderByDescending(r => r.InferredGrowth)
            .ThenByDescending(r => r.CarriedTokens)
            .ThenByDescending(r => r.Calls)
            .ThenBy(r => r.Tool, StringComparer.Ordinal)
            .ToList();
        return new ContextGrowthResult(rows, modelTurn, resets, resetTokens, overhead);
    }

    /// <summary>
    /// A tool result stays in the context of every later call of the same agent run until the context drops
    /// (a compaction or reset): carried tokens = its size × those calls, counting the call that first read it.
    /// </summary>
    static void Carry(List<ModelCall> calls, List<ToolCall> tools)
    {
        foreach (var t in tools)
        {
            if (t.SizeTokens is not long size || size <= 0) continue;
            int first = calls.FindIndex(c => c.Start >= t.Start);
            if (first < 0) continue;
            int stop = first + 1;
            while (stop < calls.Count && calls[stop].Input >= calls[stop - 1].Input) stop++;
            t.CarriedTokens = size * (stop - first);
        }
    }
}
